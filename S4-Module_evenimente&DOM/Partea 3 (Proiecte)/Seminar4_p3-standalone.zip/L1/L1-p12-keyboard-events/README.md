# L1-p12-keyboard-events

**Learning goals:** Activează cardul la Enter/Space; focus management minimal.

**Spec:** Keyboard (Enter/Space) pe carduri.

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** Activează cardul la Enter/Space; focus management minimal.

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
