# L1-p08-dataset-attrs

**Learning goals:** Folosește data-id/data-club pe carduri, validează prezența.

**Spec:** data-* (dataset) cu validare.

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** Folosește data-id/data-club pe carduri, validează prezența.

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
