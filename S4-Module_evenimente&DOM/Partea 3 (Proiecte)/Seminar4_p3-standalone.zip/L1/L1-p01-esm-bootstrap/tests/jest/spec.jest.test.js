import { describe, it, expect, beforeEach } from '@jest/globals';
import * as M from '../src/main.js';
import { qs } from '../src/dom.js';

describe('bootstrap & DOM basics', () => {
  beforeEach(()=>{ document.body.innerHTML=`<div id="app"><input id='q'><button id='clear'></button><ul id='list'></ul></div>`; });
  it('exports bootstrap', ()=>{ expect(typeof M.bootstrap).toBe('function'); });
  it('has module script in HTML (static file check skipped in jsdom) — smoke', ()=>{ expect(true).toBe(true); });
});
