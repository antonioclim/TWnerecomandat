export function filterItems(items,q){
  const s=String(q||'').trim().toLowerCase(); if(!s) return items;
  return items.filter(it=> (it.title||'').toLowerCase().includes(s) || (it.club||'').toLowerCase().includes(s));
}
