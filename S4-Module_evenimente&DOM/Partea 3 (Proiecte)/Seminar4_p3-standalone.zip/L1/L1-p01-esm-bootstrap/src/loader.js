export const dynamicImport=(path)=>import(path);
