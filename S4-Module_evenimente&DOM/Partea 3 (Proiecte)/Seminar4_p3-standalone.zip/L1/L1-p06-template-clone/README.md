# L1-p06-template-clone

**Learning goals:** Generează carduri folosind <template id='card-tpl'>.

**Spec:** <template> + cloneNode pentru carduri.

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** Generează carduri folosind <template id='card-tpl'>.

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
