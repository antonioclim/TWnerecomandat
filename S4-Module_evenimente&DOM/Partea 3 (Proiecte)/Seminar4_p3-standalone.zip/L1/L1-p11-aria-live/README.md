# L1-p11-aria-live

**Learning goals:** Anunță numărul de rezultate în aria-live='polite'.

**Spec:** ARIA live region.

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** Anunță numărul de rezultate în aria-live='polite'.

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
