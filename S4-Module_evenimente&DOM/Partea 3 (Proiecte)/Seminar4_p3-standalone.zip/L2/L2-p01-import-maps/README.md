# L2-p01-import-maps

**Learning goals:** Definește <script type='importmap'> și un exemplu cu lodash-es; testul scanează doar importmap în HTML.

**Spec:** Import maps (CDN ESM) — demonstrație HTML.

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** Definește <script type='importmap'> și un exemplu cu lodash-es; testul scanează doar importmap în HTML.

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
