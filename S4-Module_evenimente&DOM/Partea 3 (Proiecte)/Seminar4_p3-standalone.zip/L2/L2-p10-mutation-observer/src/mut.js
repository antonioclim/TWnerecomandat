export function observeList(list, badge){
  const mo = new MutationObserver(()=>{
    requestAnimationFrame(()=>{ badge.textContent = String(list.children.length); });
  });
  mo.observe(list,{childList:true});
  return ()=>mo.disconnect();
}
