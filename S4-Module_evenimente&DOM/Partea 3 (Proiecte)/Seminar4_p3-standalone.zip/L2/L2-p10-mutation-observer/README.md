# L2-p10-mutation-observer

**Learning goals:** Actualizează un badge când #list se schimbă.

**Spec:** MutationObserver pentru badge rezultate.

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** Actualizează un badge când #list se schimbă.

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
