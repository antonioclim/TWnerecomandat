# L2-p08-csp-scan

**Learning goals:** Test care scanează HTML pentru on\w+=; README despre CSP.

**Spec:** Igienă CSP: fără on*=.

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** Test care scanează HTML pentru on\w+=; README despre CSP.

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
