# L2-p04-reexports

**Learning goals:** Re-exportă loadEvents; main.js importă exclusiv din index.

**Spec:** Re-exports (services/index.js).

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** Re-exportă loadEvents; main.js importă exclusiv din index.

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
