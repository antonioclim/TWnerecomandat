# L2-p05-tree-shaking

**Learning goals:** README explică; testele verifică existența câmpului în package.json.

**Spec:** sideEffects:false (demonstrație teoretică).

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** README explică; testele verifică existența câmpului în package.json.

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
