# L2-p13-import-conditions-doc

**Learning goals:** README + fișier demo (nu rulează în browser).

**Spec:** Import conditions (Node) — explicații.

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** README + fișier demo (nu rulează în browser).

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
