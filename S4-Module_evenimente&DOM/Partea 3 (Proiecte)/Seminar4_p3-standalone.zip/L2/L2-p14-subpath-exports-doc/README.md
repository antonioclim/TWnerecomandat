# L2-p14-subpath-exports-doc

**Learning goals:** README + fișiere exemplu; consum în monorepo.

**Spec:** Subpath exports — concept.

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** README + fișiere exemplu; consum în monorepo.

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
