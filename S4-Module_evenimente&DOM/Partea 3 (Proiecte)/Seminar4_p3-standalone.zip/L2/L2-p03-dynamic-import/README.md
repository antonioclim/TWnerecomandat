# L2-p03-dynamic-import

**Learning goals:** Încarcă /src/filters.js la primul input pe #q (lazy).

**Spec:** Import dinamic pentru filtrare.

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** Încarcă /src/filters.js la primul input pe #q (lazy).

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
