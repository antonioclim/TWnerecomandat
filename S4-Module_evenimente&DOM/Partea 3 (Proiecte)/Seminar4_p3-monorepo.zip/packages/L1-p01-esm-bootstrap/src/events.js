export function on(container,type,selector,handler,options){
  const listener=(ev)=>{const t=ev.target.closest(selector); if(!t||!container.contains(t)) return; handler(ev,t)};
  container.addEventListener(type,listener,options); return ()=>container.removeEventListener(type,listener,options);
}
export function listenWithSignal(el,type,cb,signal,options){ el.addEventListener(type,cb,{...options,signal}); }
