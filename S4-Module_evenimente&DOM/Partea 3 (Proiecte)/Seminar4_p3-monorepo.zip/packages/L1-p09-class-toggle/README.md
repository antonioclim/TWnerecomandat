# L1-p09-class-toggle

**Learning goals:** La click setează .active și aria-pressed corespunzător.

**Spec:** Toggling de clase + ARIA.

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** La click setează .active și aria-pressed corespunzător.

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
