export const feature=()=> 'feature-ok';
