# L1-p13-target-currentTarget

**Learning goals:** Exemplu clar cu event.target vs event.currentTarget.

**Spec:** target vs currentTarget.

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** Exemplu clar cu event.target vs event.currentTarget.

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
