# L2-p11-throttle-input

**Learning goals:** Aplică throttle(fn, 80ms) pe inputul de căutare.

**Spec:** Throttling pentru input.

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** Aplică throttle(fn, 80ms) pe inputul de căutare.

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
