export const throttle=(fn,ms=80)=>{ let last=0; return (...args)=>{ const now=Date.now(); if(now-last>=ms){ last=now; fn(...args);} }; };
