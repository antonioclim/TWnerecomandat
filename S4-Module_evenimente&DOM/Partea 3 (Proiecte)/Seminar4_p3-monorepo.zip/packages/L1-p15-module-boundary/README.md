# L1-p15-module-boundary

**Learning goals:** Consumă datele numai prin services/index.js pentru decuplare.

**Spec:** Boundary minim între ui/ și services/.

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** Consumă datele numai prin services/index.js pentru decuplare.

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
