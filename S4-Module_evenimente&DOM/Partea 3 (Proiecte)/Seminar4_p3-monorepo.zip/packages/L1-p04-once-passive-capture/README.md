# L1-p04-once-passive-capture

**Learning goals:** Demonstrează {once:true}, {passive:true}, {capture:true} pe butoane dedicate.

**Spec:** Opțiuni addEventListener (once/passive/capture).

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** Demonstrează {once:true}, {passive:true}, {capture:true} pe butoane dedicate.

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
