# L1-p02-dom-helpers

**Learning goals:** Expune utilitare qs/qsa care aruncă pentru lipsă selector și returnează array pentru liste.

**Spec:** DOM helpers cu invariante (qs/qsa).

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** Expune utilitare qs/qsa care aruncă pentru lipsă selector și returnează array pentru liste.

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
