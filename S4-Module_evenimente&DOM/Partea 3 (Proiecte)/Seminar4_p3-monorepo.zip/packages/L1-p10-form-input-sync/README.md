# L1-p10-form-input-sync

**Learning goals:** Sincronizează input#q cu textul filtrat (fără import lazy).

**Spec:** Form input binding.

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** Sincronizează input#q cu textul filtrat (fără import lazy).

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
