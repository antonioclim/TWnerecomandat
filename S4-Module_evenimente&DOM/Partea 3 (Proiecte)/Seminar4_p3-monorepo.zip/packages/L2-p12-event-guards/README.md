# L2-p12-event-guards

**Learning goals:** Validează tipul evenimentului înainte de handler.

**Spec:** Assert/guards pentru evenimente.

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** Validează tipul evenimentului înainte de handler.

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
