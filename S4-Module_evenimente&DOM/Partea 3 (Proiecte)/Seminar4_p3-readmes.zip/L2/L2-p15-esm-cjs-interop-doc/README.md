# L2-p15-esm-cjs-interop-doc

**Learning goals:** README + script Node minim (exemplu)

**Spec:** Interop ESM↔CJS — concept.

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** README + script Node minim (exemplu)

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
