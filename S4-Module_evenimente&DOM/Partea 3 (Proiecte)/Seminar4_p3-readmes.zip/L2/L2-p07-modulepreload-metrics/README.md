# L2-p07-modulepreload-metrics

**Learning goals:** Adaugă <link rel='modulepreload'> și marchează cu performance.now().

**Spec:** modulepreload + notițe performanță.

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** Adaugă <link rel='modulepreload'> și marchează cu performance.now().

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
