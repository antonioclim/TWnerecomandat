# L2-p06-code-splitting

**Learning goals:** La click pe #feature-load, importă secundary.js și execută.

**Spec:** Buton care încarcă un modul secundar cu import().

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** La click pe #feature-load, importă secundary.js și execută.

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
