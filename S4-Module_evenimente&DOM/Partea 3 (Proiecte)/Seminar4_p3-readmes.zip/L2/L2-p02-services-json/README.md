# L2-p02-services-json

**Learning goals:** Încarcă /public/data/events.json, normalizează {id,title,when(ISO),club}.

**Spec:** Strat servicii: loadEvents() + normalizare.

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** Încarcă /public/data/events.json, normalizează {id,title,when(ISO),club}.

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
