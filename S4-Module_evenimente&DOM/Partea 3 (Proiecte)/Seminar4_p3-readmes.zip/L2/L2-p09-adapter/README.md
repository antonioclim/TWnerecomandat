# L2-p09-adapter

**Learning goals:** Mapează doar câmpurile permise, ignoră restul.

**Spec:** Adapter/whitelisting pentru JSON.

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** Mapează doar câmpurile permise, ignoră restul.

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
