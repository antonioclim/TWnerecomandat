# L1-p07-fragment-render

**Learning goals:** Construiește lista într-un fragment și atașează o singură dată.

**Spec:** DocumentFragment pentru randare eficientă.

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** Construiește lista într-un fragment și atașează o singură dată.

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
