# L1-p03-delegation-click

**Learning goals:** Atașează un singur listener pe #list și folosește .closest('li.card') pentru click.

**Spec:** Delegare evenimente pe listă.

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** Atașează un singur listener pe #list și folosește .closest('li.card') pentru click.

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
