# L1-p05-custom-event-basics

**Learning goals:** Emite hub:ping cu detail și ascultă pe document.

**Spec:** CustomEvent: emit/ascultă.

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** Emite hub:ping cu detail și ascultă pe document.

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
