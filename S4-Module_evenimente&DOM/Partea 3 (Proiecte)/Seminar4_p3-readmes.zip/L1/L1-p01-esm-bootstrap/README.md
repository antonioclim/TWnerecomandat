# L1-p01-esm-bootstrap

**Learning goals:** Initializează aplicația cu ES modules; conectează /src/main.js din /public/index.html și exportă bootstrap(document).

**Spec:** Bootstrap ESM: <script type="module">.

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** Initializează aplicația cu ES modules; conectează /src/main.js din /public/index.html și exportă bootstrap(document).

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
