# L1-p14-cleanup-abort

**Learning goals:** Returnează dispose() din bootstrap care abort() subscrierile.

**Spec:** AbortController pentru cleanup.

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** Returnează dispose() din bootstrap care abort() subscrierile.

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
