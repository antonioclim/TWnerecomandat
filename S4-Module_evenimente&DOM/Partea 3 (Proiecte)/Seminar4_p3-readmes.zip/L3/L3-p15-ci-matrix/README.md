# L3-p15-ci-matrix

**Learning goals:** Explică workflows separate și criterii de rulare.

**Spec:** CI matrix (doc + workflows monorepo).

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** Explică workflows separate și criterii de rulare.

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
