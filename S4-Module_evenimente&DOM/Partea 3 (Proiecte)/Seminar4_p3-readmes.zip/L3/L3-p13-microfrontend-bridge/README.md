# L3-p13-microfrontend-bridge

**Learning goals:** Pod între iFrame și document; demo + README.

**Spec:** iFrame + postMessage ↔ CustomEvent.

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** Pod între iFrame și document; demo + README.

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
