# L3-p01-bus-namespaced

**Learning goals:** Emit/ascultă evenimente pe canale hub:*; unsubscribe ușor.

**Spec:** Event bus namespaced (hub:*).

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** Emit/ascultă evenimente pe canale hub:*; unsubscribe ușor.

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
