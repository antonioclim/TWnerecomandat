# L3-p02-timeout-signal

**Learning goals:** Wrapper care emulează AbortSignal.timeout(ms) dacă nu există.

**Spec:** AbortSignal timeout wrapper.

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** Wrapper care emulează AbortSignal.timeout(ms) dacă nu există.

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
