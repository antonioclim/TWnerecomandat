# L3-p12-feature-toggles

**Learning goals:** Rulează modul opțional doar când toggle activ.

**Spec:** Feature toggles cu import() condițional.

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** Rulează modul opțional doar când toggle activ.

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
