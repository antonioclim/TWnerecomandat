# L3-p11-module-graph

**Learning goals:** Traversează importurile din src/ și listează graful.

**Spec:** Module graph vizualiser (dev script).

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** Traversează importurile din src/ și listează graful.

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
