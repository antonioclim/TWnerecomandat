# L3-p03-intersection-observer

**Learning goals:** Încarcă detalii pentru carduri abia când devin vizibile.

**Spec:** IntersectionObserver pentru lazy UI.

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** Încarcă detalii pentru carduri abia când devin vizibile.

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
