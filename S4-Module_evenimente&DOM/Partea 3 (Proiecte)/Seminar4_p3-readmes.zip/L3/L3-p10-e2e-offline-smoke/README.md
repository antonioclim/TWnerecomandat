# L3-p10-e2e-offline-smoke

**Learning goals:** Playwright verifică că pagina funcționează după SW.

**Spec:** E2E offline smoke (concept).

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** Playwright verifică că pagina funcționează după SW.

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
