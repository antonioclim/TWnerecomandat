# L3-p09-pwa-workbox

**Learning goals:** generateSW cu workbox-build + test smoke pe sw.js.

**Spec:** Workbox PWA: precache public/*.

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** generateSW cu workbox-build + test smoke pe sw.js.

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
