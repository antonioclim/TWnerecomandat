# L3-p04-mutation-raf-batch

**Learning goals:** Batch de actualizări într-un rAF pentru fluiditate.

**Spec:** MutationObserver + rAF (batch vizual).

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** Batch de actualizări într-un rAF pentru fluiditate.

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
