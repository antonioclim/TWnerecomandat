# L3-p14-perf-budget

**Learning goals:** Măsoară timpi și eșuează peste prag; doc + test simplu.

**Spec:** Performance budget (marks & asserts).

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** Măsoară timpi și eșuează peste prag; doc + test simplu.

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
