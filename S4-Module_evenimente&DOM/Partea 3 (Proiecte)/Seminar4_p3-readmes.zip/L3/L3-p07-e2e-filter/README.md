# L3-p07-e2e-filter

**Learning goals:** E2E verifică fluxul input→filtrare (webServer).

**Spec:** Playwright E2E: filtrare listă.

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** E2E verifică fluxul input→filtrare (webServer).

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
