# L3-p05-composed-events

**Learning goals:** Explică composed:true peste shadow boundary; demo simplu.

**Spec:** CustomEvent composed (concept & demo).

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** Explică composed:true peste shadow boundary; demo simplu.

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
