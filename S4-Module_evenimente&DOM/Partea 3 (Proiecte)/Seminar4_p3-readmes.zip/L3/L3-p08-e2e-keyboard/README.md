# L3-p08-e2e-keyboard

**Learning goals:** E2E verifică Enter/Space/Arrow pe carduri.

**Spec:** Playwright E2E: navigare tastatură.

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** E2E verifică Enter/Space/Arrow pe carduri.

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
