# L3-p06-event-replay

**Learning goals:** Păstrează ultimele N evenimente și le livrează noilor abonați.

**Spec:** Event replay buffer.

**Run:**
```bash
npm i
npm run test
npm run serve
```

**Spec detaliat:** Păstrează ultimele N evenimente și le livrează noilor abonați.

**Fișiere:** public/index.html, src/*.js, tests/ (Vitest/Jest).
