import { describe, it, expect } from '@jest/globals';

describe('CSP hygiene (no inline handlers)', () => {
  it('index.html contains no inline on* handlers', async () => {
    const fs = await import('fs');
    const html = fs.readFileSync('public/index.html','utf-8');
    expect(/on\w+=/i.test(html)).toBe(false);
  });
});
