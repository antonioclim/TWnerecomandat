import { describe, it, expect, beforeEach } from '@jest/globals';
import { qs, qsa } from '../../src/dom.js';

describe('dom helpers', () => {
  beforeEach(() => { document.body.innerHTML = '<div id="app"><span class="x"></span></div>'; });
  it('qs throws for missing', () => {
    expect(() => qs('#missing')).toThrow();
  });
  it('qs finds', () => {
    expect(qs('#app').id).toBe('app');
  });
  it('qsa returns array', () => {
    expect(Array.isArray(qsa('.x'))).toBe(true);
  });
});
