import { describe, it, expect } from '@jest/globals';
import { emit, onEvent } from '../../src/bus.js';

describe('CustomEvent bus', () => {
  it('dispatches detail', () => {
    const div = document.createElement('div');
    let detail = null;
    const off = onEvent(div, 'hub:test', (ev) => detail = ev.detail);
    emit(div, 'hub:test', {a:1});
    off();
    expect(detail).toEqual({a:1});
  });
});
