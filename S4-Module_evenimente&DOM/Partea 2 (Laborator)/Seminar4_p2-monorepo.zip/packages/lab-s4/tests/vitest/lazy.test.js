import { describe, it, expect, vi, beforeEach } from 'vitest';

describe('lazy import via loader.dynamicImport', () => {
  beforeEach(() => {
    document.body.innerHTML = `
      <input id="q"><button id="clear"></button><ul id="list"></ul>
    `;
    // mock fetch for loadEvents
    globalThis.fetch = vi.fn(async () => ({
      ok: true,
      json: async () => ([{id:'e1', title:'A', when:new Date().toISOString(), club:'X'}])
    }));
  });

  it('does not import filters at bootstrap, but imports on input', async () => {
    const loader = await import('../../src/loader.js');
    const spy = vi.spyOn(loader, 'dynamicImport');
    const mod = await import('../../src/main.js');
    await mod.bootstrap(document);
    expect(spy).not.toHaveBeenCalled(); // no lazy at bootstrap
    const q = document.querySelector('#q');
    q.value = 'a'; q.dispatchEvent(new Event('input'));
    // Wait a microtask
    await Promise.resolve();
    expect(spy).toHaveBeenCalledOnce();
  });
});
