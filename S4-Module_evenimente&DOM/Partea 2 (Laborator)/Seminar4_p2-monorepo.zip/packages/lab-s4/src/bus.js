export function emit(target, name, detail){
  target.dispatchEvent(new CustomEvent(name, { detail, bubbles:true }));
}
export function onEvent(target, name, handler, options){
  target.addEventListener(name, handler, options);
  return () => target.removeEventListener(name, handler, options);
}
