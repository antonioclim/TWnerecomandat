import { qs } from './dom.js';
import { on, listenWithSignal } from './events.js';
import { renderList } from './ui/list.js';
import { loadEvents } from './services/data.js';
import { dynamicImport } from './loader.js';

export async function bootstrap(root = document){
  const ctrl = new AbortController();
  const list = qs('#list', root);
  const q    = qs('#q', root);
  const clear= qs('#clear', root);

  const data = await loadEvents();
  renderList(list, data);

  // Delegare pe listă — click pe card emite eveniment (ex. în P2 extins)
  on(list, 'click', 'li.card', (ev, el) => {
    el.classList.toggle('active');
  });

  // Căutare cu import lazy al filtrului
  let mod = null;
  listenWithSignal(q, 'input', async () => {
    if(!mod) mod = await dynamicImport('/src/filters.js');
    const filtered = mod.filterItems(data, q.value);
    renderList(list, filtered);
  }, ctrl.signal, { passive: true });

  listenWithSignal(clear, 'click', () => {
    q.value='';
    renderList(list, data);
  }, ctrl.signal);

  return () => ctrl.abort();
}

// Auto-bootstrap când rulează în browser
if (typeof window !== 'undefined' && window.document) {
  bootstrap(document);
}
