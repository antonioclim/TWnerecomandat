// Wrapper pentru import dinamic — ușor de spionat în teste
export const dynamicImport = (path) => import(path);
