export const qs = (sel, root=document) => {
  const el = root.querySelector(sel);
  if (!el) throw new Error(`Missing element: ${sel}`);
  return el;
};
export const qsa = (sel, root=document) => Array.from(root.querySelectorAll(sel));
