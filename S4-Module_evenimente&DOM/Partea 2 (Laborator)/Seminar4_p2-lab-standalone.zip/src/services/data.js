export async function loadEvents(){
  try{
    const r = await fetch('/public/data/events.json');
    if(!r.ok) throw new Error(`HTTP ${r.status}`);
    const arr = await r.json();
    return arr.map(x => ({
      id: String(x.id),
      title: String(x.title || ''),
      when: new Date(x.when).toISOString(),
      club: String(x.club || '')
    }));
  }catch(e){
    return [];
  }
}
