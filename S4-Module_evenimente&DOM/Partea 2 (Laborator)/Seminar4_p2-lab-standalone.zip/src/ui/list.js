export function renderList(container, items){
  const frag = document.createDocumentFragment();
  for (const it of items){
    const li = document.createElement('li');
    li.className = 'card';
    const art = document.createElement('article');
    const h3 = document.createElement('h3'); h3.className = 'title'; h3.textContent = it.title;
    const p  = document.createElement('p');  p.className  = 'meta';  p.textContent  = new Date(it.when).toLocaleString();
    art.append(h3, p);
    li.appendChild(art);
    li.dataset.id = it.id;
    frag.appendChild(li);
  }
  container.innerHTML='';
  container.appendChild(frag);
}
