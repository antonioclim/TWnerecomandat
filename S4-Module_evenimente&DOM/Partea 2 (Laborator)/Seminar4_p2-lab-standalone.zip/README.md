# Seminarul 4 — Partea 2 (Laborator)
Comenzi uzuale:
```bash
npm i
npm run test       # Vitest + Jest
npm run serve      # http://localhost:5173/public/index.html
```
Structură: `src/` (module ESM), `public/` (HTML/CSS/JSON), `tests/` (Vitest/Jest).
