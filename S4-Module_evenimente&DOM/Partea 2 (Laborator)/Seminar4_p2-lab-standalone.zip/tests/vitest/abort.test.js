import { describe, it, expect } from 'vitest';
import { listenWithSignal } from '../../src/events.js';

describe('AbortController cleanup', () => {
  it('stops receiving after abort', () => {
    const ctrl = new AbortController();
    const btn = document.createElement('button');
    let n = 0;
    listenWithSignal(btn, 'click', () => n++, ctrl.signal);
    btn.click(); // 1
    ctrl.abort();
    btn.click(); // should not increment
    expect(n).toBe(1);
  });
});
