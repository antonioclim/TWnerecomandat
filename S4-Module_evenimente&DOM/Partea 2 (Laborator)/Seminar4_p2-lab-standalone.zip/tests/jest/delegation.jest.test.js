import { describe, it, expect, beforeEach } from '@jest/globals';
import { on } from '../../src/events.js';

describe('delegation', () => {
  let ul, dispose;
  beforeEach(() => {
    document.body.innerHTML = '<ul id="list"><li class="card"><button class="btn">x</button></li></ul>';
    ul = document.querySelector('#list');
  });
  it('fires handler when selector matches', () => {
    let fired = false;
    dispose = on(ul, 'click', 'li.card', () => { fired = true; });
    ul.querySelector('.btn').click();
    expect(fired).toBe(true);
    dispose();
  });
});
