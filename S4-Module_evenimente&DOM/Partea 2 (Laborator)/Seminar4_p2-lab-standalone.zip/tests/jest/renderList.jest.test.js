import { describe, it, expect, beforeEach } from '@jest/globals';
import { renderList } from '../../src/ui/list.js';

describe('renderList', () => {
  let ul;
  beforeEach(() => {
    document.body.innerHTML = '<ul id="list"></ul>';
    ul = document.querySelector('#list');
  });
  it('renders items', () => {
    renderList(ul, [{id:'e1', title:'A', when:new Date().toISOString(), club:'X'}]);
    expect(ul.querySelectorAll('li.card').length).toBe(1);
  });
});
