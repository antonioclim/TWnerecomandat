module.exports={ testEnvironment:'node', transform:{'^.+\\.js$':'babel-jest'}, extensionsToTreatAsEsm:['.js'] };
