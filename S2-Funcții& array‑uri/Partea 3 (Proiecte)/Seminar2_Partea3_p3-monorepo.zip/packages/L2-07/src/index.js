export function buildPredicate(...args) { throw new Error('not implemented'); }
