import { describe, it, expect } from '@jest/globals'
import { sort3 } from '../../starter/src/index.js'
describe('sort3',()=>{ it('works',()=>{ const s=sort3([{k:1,a:'b'},{k:1,a:'a'}], (x,y)=>y.k-x.k, (x,y)=>x.a.localeCompare(y.a), ()=>0); expect(s[0].a).toBe('a') }) })
