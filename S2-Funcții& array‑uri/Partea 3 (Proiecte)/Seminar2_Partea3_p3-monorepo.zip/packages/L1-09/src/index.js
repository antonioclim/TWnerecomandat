export function flattenInterests(...args) { return []; }
