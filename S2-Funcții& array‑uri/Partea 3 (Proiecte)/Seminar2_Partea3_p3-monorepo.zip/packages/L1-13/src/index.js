export function compactDefined(...args) { return arr; }
