import { describe, it, expect } from '@jest/globals'
import { windows } from '../../starter/src/index.js'
describe('windows',()=>{ it('works',()=>{ expect(windows([1,2,3,4],3)).toEqual([[1,2,3],[2,3,4]]) }) })
