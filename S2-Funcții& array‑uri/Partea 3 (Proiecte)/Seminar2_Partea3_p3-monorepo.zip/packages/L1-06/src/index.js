export function setOpsByEmail(...args) { return {difference: rowsA ?? [], intersection: []}; }
