export function partitionValid(...args) { return {valid:[], invalid: rows}; }
