import { describe, it, expect } from 'vitest'
import { noop } from '../../starter/src/index.js'
describe('noop',()=>{ it('ok',()=>{ expect(1).toBe(1) }) })
