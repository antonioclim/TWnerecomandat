import { describe, it, expect } from '@jest/globals'
import { partitionBy } from '../../starter/src/index.js'
describe('partitionBy',()=>{ it('works',()=>{ const [t,f]=partitionBy([1,2,3,4], x=>x%2===0); expect(t).toEqual([2,4]) }) })
