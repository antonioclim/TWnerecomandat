export function deepFlatten(...args) { throw new Error('not implemented'); }
