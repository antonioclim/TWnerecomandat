export function lazyConcept(...args) { throw new Error('not implemented'); }
