export function randomCases(...args) { throw new Error('not implemented'); }
