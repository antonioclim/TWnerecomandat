export function flattenInterests(rows){ const out=[]; for(const r of rows){ for(const it of (r.interests||[])){ const v=String(it).trim(); if(v) out.push(v) } } return out }
