# L3-12 — Soluție
Contractele sunt păstrate; testele sunt identice (trebuie să fie verzi).
