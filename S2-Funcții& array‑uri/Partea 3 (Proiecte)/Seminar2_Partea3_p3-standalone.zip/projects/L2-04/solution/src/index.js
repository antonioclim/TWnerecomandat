export function differenceByProj(a,b,proj)=>{ const sb=new Set(b.map(proj)); return a.filter(x=>!sb.has(proj(x))) }
