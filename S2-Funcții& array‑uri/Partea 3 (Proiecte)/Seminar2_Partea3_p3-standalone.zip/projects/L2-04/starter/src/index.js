export function differenceByProj(...args) { throw new Error('not implemented'); }
