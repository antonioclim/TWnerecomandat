import { describe, it, expect } from '@jest/globals'
import { differenceByProj } from '../../starter/src/index.js'
describe('differenceByProj',()=>{ it('works',()=>{ expect(differenceByProj([{x:1},{x:2}],[{x:2}], o=>o.x)).toEqual([{x:1}]) }) })
