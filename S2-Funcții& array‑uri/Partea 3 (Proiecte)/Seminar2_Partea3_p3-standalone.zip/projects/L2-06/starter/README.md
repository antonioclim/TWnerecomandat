# L2-06 — zip & merge (aliniere și combinare câmpuri)
API: `zipMerge(a,b, key) → merged[]`

**Learning goals**: declarativ pe array‑uri, teste în oglindă, contracte clare.
