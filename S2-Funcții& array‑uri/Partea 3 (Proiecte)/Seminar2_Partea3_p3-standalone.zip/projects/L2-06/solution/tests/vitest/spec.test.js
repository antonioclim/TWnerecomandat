import { describe, it, expect } from 'vitest'
import { zipMerge } from '../../solution/src/index.js'
describe('zipMerge',()=>{ it('works',()=>{ expect(zipMerge([{id:1,v:1}], [{id:1,w:2}], 'id')[0].w).toBe(2) }) })
