# L1-14 — Sortare cu Intl.Collator pentru text
API: `sortAlphaRO(arr) → arr`

**Learning goals**: declarativ pe array‑uri, teste în oglindă, contracte clare.
