import { describe, it, expect } from '@jest/globals'
import { sortAlphaRO } from '../../starter/src/index.js'
describe('sortAlphaRO',()=>{ it('orders',()=>{ expect(sortAlphaRO(['șarpe','alb'])).toEqual(['alb','șarpe']) }) })
