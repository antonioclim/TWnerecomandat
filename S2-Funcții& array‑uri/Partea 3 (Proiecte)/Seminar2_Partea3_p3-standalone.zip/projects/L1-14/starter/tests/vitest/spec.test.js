import { describe, it, expect } from 'vitest'
import { sortAlphaRO } from '../../starter/src/index.js'
describe('sortAlphaRO',()=>{ it('orders',()=>{ expect(sortAlphaRO(['șarpe','alb'])).toEqual(['alb','șarpe']) }) })
