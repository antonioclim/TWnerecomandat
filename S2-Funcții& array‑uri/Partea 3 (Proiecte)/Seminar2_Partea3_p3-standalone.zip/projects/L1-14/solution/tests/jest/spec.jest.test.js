import { describe, it, expect } from '@jest/globals'
import { sortAlphaRO } from '../../solution/src/index.js'
describe('sortAlphaRO',()=>{ it('orders',()=>{ expect(sortAlphaRO(['șarpe','alb'])).toEqual(['alb','șarpe']) }) })
