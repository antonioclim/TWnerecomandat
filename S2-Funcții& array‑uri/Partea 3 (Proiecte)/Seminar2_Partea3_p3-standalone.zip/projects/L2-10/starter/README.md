# L2-10 — flatten profund (nested)
API: `deepFlatten(arr) → flat[]`

**Learning goals**: declarativ pe array‑uri, teste în oglindă, contracte clare.
