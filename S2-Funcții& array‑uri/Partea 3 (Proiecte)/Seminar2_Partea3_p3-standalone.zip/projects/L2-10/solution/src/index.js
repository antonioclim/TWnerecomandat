export function deepFlatten(arr)=>{ const out=[]; const go=(x)=> Array.isArray(x)? x.forEach(go): out.push(x); go(arr); return out }
