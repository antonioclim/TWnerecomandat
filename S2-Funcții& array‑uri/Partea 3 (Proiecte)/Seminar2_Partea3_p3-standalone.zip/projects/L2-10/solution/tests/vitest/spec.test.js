import { describe, it, expect } from 'vitest'
import { deepFlatten } from '../../solution/src/index.js'
describe('deepFlatten',()=>{ it('works',()=>{ expect(deepFlatten([1,[2,[3]]])).toEqual([1,2,3]) }) })
