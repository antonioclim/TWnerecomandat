import { describe, it, expect } from 'vitest'
import { uniqByEmailCanon } from '../../solution/src/index.js'
describe('uniqByEmailCanon',()=>{ it('works',()=>{ expect(uniqByEmailCanon([{email:'A@x.org'},{email:'a@x.org'}]).length).toBe(1) }) })
