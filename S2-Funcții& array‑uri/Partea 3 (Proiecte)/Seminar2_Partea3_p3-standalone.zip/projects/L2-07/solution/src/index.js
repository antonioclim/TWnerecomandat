export function buildPredicate(opts)=>{ const arr=[]; if(opts.min) arr.push(r=>r>=opts.min); if(opts.max) arr.push(r=>r<=opts.max); return (x)=> arr.every(p=>p(x)) }
