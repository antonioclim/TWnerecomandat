import { describe, it, expect } from 'vitest'
import { buildPredicate } from '../../starter/src/index.js'
describe('buildPredicate',()=>{ it('works',()=>{ const p=buildPredicate({min:2,max:3}); expect([1,2,3,4].filter(p)).toEqual([2,3]) }) })
