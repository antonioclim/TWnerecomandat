import { describe, it, expect } from '@jest/globals'
import { compactDefined } from '../../starter/src/index.js'
describe('compactDefined',()=>{ it('removes null/undefined',()=>{ expect(compactDefined([0,null,undefined,2])).toEqual([0,2]) }) })
