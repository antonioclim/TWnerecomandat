import { describe, it, expect } from 'vitest'
import { compactDefined } from '../../solution/src/index.js'
describe('compactDefined',()=>{ it('removes null/undefined',()=>{ expect(compactDefined([0,null,undefined,2])).toEqual([0,2]) }) })
