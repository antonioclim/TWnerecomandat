export function compactDefined(arr){ return arr.filter(x=> x!==null && x!==undefined) }
