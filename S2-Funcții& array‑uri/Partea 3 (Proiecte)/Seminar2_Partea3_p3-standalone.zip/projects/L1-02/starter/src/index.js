export function countByFaculty(...args) { return {}; }
