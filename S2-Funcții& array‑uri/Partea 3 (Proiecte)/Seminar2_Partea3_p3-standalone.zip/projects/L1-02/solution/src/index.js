export function countByFaculty(rows){ const out={}; for(const r of rows){ const f=String(r.faculty||'').toUpperCase(); out[f]=(out[f]||0)+1 } return out }
