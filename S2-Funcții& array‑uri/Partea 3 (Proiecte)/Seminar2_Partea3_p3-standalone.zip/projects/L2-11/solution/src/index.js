export function keyByUnique(arr,keyFn)=>{ const out={}; for(const x of arr){ const k=keyFn(x); if(k in out) throw new Error('collision'); out[k]=x } return out }
