import { describe, it, expect } from 'vitest'
import { keyByUnique } from '../../starter/src/index.js'
describe('keyByUnique',()=>{ it('works',()=>{ expect(()=>keyByUnique([{id:1},{id:1}], x=>x.id)).toThrow() }) })
