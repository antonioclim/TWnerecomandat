export function keyByUnique(...args) { throw new Error('not implemented'); }
