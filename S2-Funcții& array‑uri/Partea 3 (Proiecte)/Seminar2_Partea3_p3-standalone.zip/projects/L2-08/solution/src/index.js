export function sort3(arr,a,b,c)=>{ return [...arr].sort((x,y)=> a(x,y)||b(x,y)||c(x,y)) }
