# L2-08 — comparator compus (primar/ secundar/ terțiar)
API: `sort3(arr, a,b,c) → sorted`

**Learning goals**: declarativ pe array‑uri, teste în oglindă, contracte clare.
