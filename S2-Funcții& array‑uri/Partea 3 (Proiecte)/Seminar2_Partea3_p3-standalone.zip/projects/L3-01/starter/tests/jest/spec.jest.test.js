import { describe, it, expect } from '@jest/globals'
import { noop } from '../../starter/src/index.js'
describe('noop',()=>{ it('ok',()=>{ expect(1).toBe(1) }) })
