# L3-07 — Soluție
Contractele sunt păstrate; testele sunt identice (trebuie să fie verzi).
