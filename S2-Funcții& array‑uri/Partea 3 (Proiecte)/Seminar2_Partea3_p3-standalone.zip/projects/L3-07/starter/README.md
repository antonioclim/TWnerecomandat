# L3-07 — Viewer web static (raport JSON → tabel)
API: `web/index.html + script.js`

**Learning goals**: declarativ pe array‑uri, teste în oglindă, contracte clare.
