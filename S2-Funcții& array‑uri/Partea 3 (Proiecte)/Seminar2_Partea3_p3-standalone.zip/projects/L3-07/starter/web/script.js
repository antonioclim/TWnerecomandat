fetch('./report.json').then(r=>r.json()).then(d=>{ document.getElementById('out').textContent=JSON.stringify(d,null,2) }).catch(()=>{ document.getElementById('out').textContent='no data' })
