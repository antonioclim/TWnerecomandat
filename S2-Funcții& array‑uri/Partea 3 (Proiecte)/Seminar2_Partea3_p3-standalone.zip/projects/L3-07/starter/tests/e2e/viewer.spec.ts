import { test, expect } from '@playwright/test'
test('viewer loads', async ({ page }) => {
  await page.goto('/projects/L3-07/starter/web/index.html')
  await expect(page.getByText('Report Viewer L3-07')).toBeVisible()
  await expect(page.getByText('topInterests')).toBeVisible()
})
