# L1-12 — Pipeline parametric (filters facultate/interes)
API: `filterRows(rows,{faculty,interest}) → rows`

**Learning goals**: declarativ pe array‑uri, teste în oglindă, contracte clare.
