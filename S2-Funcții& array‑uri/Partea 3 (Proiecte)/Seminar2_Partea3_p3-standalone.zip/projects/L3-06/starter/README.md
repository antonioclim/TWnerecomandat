# L3-06 — Mini‑lib publicabil (API fațadă)
API: `index.js + exports`

**Learning goals**: declarativ pe array‑uri, teste în oglindă, contracte clare.
