# L3-10 — Config mediu (ENV) pentru CLI/Viewer
API: `env handling`

**Learning goals**: declarativ pe array‑uri, teste în oglindă, contracte clare.
