# L3-14 — PWA offline (ultimul raport)
API: `cache report.json`

**Learning goals**: declarativ pe array‑uri, teste în oglindă, contracte clare.
