# L2-09 — Soluție
Contractele sunt păstrate; testele sunt identice (trebuie să fie verzi).
