import { describe, it, expect } from 'vitest'
import { auditPipeline } from '../../solution/src/index.js'
describe('auditPipeline',()=>{ it('works',()=>{ const a=auditPipeline([1,2,3],[ xs=>{expect(xs.length).toBe(3); return xs.filter(n=>n>1)} ]); expect(a).toEqual([2,3]) }) })
