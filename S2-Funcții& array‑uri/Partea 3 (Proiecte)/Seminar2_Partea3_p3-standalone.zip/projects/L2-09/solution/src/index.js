export function auditPipeline(rows, taps=[])=>{ let cur=rows; for(const t of taps){ cur=t(cur) } return cur }
