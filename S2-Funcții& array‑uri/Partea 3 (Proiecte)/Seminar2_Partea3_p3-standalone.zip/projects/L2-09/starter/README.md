# L2-09 — tap/peek audit (dimensiuni intermediare)
API: `auditPipeline(rows, taps[]) → rows`

**Learning goals**: declarativ pe array‑uri, teste în oglindă, contracte clare.
