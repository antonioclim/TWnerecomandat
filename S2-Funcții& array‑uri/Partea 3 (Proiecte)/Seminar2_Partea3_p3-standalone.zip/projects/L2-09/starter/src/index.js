export function auditPipeline(...args) { throw new Error('not implemented'); }
