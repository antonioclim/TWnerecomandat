export function randomCases(n,gen)=>{ const arr=[]; for(let i=0;i<n;i++) arr.push(gen(i)); return arr }
