import { describe, it, expect } from 'vitest'
import { randomCases } from '../../solution/src/index.js'
describe('randomCases',()=>{ it('works',()=>{ const xs=randomCases(3,i=>i*2); expect(xs).toEqual([0,2,4]) }) })
