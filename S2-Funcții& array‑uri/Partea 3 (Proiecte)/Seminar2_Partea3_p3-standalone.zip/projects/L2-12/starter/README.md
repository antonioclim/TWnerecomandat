# L2-12 — property‑based ideas fără lib (random cases)
API: `randomCases(n, gen) → cases`

**Learning goals**: declarativ pe array‑uri, teste în oglindă, contracte clare.
