# L3-15 — Pachetarea artefactelor (zip outputs)
API: `archive reports`

**Learning goals**: declarativ pe array‑uri, teste în oglindă, contracte clare.
