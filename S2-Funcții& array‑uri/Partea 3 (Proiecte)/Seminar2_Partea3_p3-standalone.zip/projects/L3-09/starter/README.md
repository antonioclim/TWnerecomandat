# L3-09 — Workbox precache (generateSW)
API: `workbox-build config`

**Learning goals**: declarativ pe array‑uri, teste în oglindă, contracte clare.
