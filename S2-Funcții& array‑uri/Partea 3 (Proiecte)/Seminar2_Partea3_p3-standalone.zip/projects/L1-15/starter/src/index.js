export function pipelineSummary(...args) { return {topK:[], total: rows?.length||0}; }
