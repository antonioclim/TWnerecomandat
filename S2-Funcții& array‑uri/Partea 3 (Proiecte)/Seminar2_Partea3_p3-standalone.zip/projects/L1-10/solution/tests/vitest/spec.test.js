import { describe, it, expect } from 'vitest'
import { sortByCountThenAlpha } from '../../solution/src/index.js'
describe('sortByCountThenAlpha',()=>{ it('stable tie-break',()=>{ const s=sortByCountThenAlpha([['Web',2],['AI',2],['Data',3]]); expect(s[0][0]).toBe('Data'); expect(s[1][0]).toBe('AI') }) })
