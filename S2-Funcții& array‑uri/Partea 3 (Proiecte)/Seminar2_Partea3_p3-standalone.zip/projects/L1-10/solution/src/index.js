export function sortByCountThenAlpha(entries){ const arr=[...entries]; arr.sort((a,b)=> b[1]-a[1] || String(a[0]).localeCompare(String(b[0]),'ro')); return arr }
