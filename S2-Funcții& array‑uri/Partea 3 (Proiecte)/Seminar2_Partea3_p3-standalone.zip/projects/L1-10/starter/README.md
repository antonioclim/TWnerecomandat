# L1-10 — Comparator determinist pentru frecvențe
API: `sortByCountThenAlpha(entries) → sorted`

**Learning goals**: declarativ pe array‑uri, teste în oglindă, contracte clare.
