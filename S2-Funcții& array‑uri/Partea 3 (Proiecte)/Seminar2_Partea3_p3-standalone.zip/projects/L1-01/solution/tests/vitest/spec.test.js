import { describe, it, expect } from 'vitest'
import { topKInterests } from '../../solution/src/index.js'
describe('topKInterests',()=>{
  const rows = [{"name": "Ana", "email": "ana@x.org", "faculty": "CSIE", "year": 1, "interests": ["AI", "Web"]}, {"name": "Mihai", "email": "mihai@x.org", "faculty": "REI", "year": 2, "interests": ["Finance", "Web"]}, {"name": "Ioana", "email": "ioana@x.org", "faculty": "CSIE", "year": 1, "interests": ["Web", "UX"]}, {"name": "Elena", "email": "elena@x.org", "faculty": "CSIE", "year": 3, "interests": ["AI", "Data"]}, {"name": "Radu", "email": "radu@x.org", "faculty": "FABBV", "year": 2, "interests": ["Audit", "Finance"]}];
  it('returns top 2',()=>{
    const out = topKInterests(rows,2)
    expect(out.length).toBe(2)
    expect(out[0].key).toBe('web')
  })
})
