# L3-05 — Micro‑profilare a pașilor
API: `profile(fn, x) → {result,ms}`

**Learning goals**: declarativ pe array‑uri, teste în oglindă, contracte clare.
