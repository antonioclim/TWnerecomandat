# L2-15 — Soluție
Include analiza complexității și 12 edge‑cases.
