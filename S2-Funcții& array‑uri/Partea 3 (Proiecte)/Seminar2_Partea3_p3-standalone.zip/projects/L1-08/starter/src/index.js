export function zipAlign(...args) { return []; }

export function unzipPairs(pairs){ const a=[],b=[]; for(const [x,y] of pairs){a.push(x);b.push(y)} return [a,b] }
