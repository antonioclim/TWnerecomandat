export function zipAlign(a,b){ const m=Math.min(a.length,b.length); const out=[]; for(let i=0;i<m;i++) out.push([a[i],b[i]]); return out }

export function unzipPairs(pairs){ const a=[],b=[]; for(const [x,y] of pairs){a.push(x);b.push(y)} return [a,b] }
