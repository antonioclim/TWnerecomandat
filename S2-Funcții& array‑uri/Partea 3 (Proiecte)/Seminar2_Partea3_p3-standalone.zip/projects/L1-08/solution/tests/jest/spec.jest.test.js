import { describe, it, expect } from '@jest/globals'
import { zipAlign } from '../../solution/src/index.js'
describe('zip/unzip',()=>{ it('pairs',()=>{ const pairs=zipAlign([1,2,3],[4,5,6]); expect(pairs).toEqual([[1,4],[2,5],[3,6]]) }) })
