# L3-08 — Playwright e2e (smoke UI)
API: `tests/e2e.spec.ts`

**Learning goals**: declarativ pe array‑uri, teste în oglindă, contracte clare.
