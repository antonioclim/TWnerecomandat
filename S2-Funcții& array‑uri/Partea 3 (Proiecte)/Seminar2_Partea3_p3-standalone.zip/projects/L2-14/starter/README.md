# L2-14 — „lazy ideas” pe iterabile (wrapper simplu)
API: `lazyMap/ lazyFilter (concept)`

**Learning goals**: declarativ pe array‑uri, teste în oglindă, contracte clare.
