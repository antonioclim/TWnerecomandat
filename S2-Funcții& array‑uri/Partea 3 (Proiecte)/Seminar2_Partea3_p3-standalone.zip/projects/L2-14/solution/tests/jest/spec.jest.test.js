import { describe, it, expect } from '@jest/globals'
import { lazyConcept } from '../../solution/src/index.js'
describe('lazyConcept',()=>{ it('works',()=>{ expect(lazyConcept()).toBe('see README') }) })
