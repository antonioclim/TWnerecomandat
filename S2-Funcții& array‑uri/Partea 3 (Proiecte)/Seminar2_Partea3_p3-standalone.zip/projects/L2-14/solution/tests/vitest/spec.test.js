import { describe, it, expect } from 'vitest'
import { lazyConcept } from '../../solution/src/index.js'
describe('lazyConcept',()=>{ it('works',()=>{ expect(lazyConcept()).toBe('see README') }) })
