# L3-02 — Procesare linie‑cu‑linie (simulare)
API: `readLinesSim(text) → iterator`

**Learning goals**: declarativ pe array‑uri, teste în oglindă, contracte clare.
