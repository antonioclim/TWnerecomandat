# L2-01 — groupBy multi‑cheie + agregare (count)
API: `groupCount(rows, keysFn) → Record<key,count>`

**Learning goals**: declarativ pe array‑uri, teste în oglindă, contracte clare.
