import { describe, it, expect } from '@jest/globals'
import { groupCount } from '../../solution/src/index.js'
describe('groupCount',()=>{ it('works',()=>{ expect(groupCount([{a:1},{a:1},{a:2}], x=>x.a)).toEqual({'1':2,'2':1}) }) })
