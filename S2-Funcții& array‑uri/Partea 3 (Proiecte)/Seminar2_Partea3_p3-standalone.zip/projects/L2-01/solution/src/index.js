export function groupCount(rows, keyFn){ const m={}; for(const r of rows){ const k=String(keyFn(r)); m[k]=(m[k]||0)+1 } return m }
