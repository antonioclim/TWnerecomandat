export function keyByEmail(rows){ const out={}; for(const r of rows){ const k=String(r.email||'').trim().toLowerCase(); out[k]=r } return out }
