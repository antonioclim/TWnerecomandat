export function paginate(...args) { return [arr]; }
