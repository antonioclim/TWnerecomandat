import { describe, it, expect } from 'vitest'
import { paginate } from '../../solution/src/index.js'
describe('paginate',()=>{ it('chunks',()=>{ expect(paginate([1,2,3,4,5],2)).toEqual([[1,2],[3,4],[5]]) }) })
