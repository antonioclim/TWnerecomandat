export function partitionBy(rows,p)=>{ const a=[],b=[]; for(const r of rows){ (p(r)?a:b).push(r)} return [a,b] }
