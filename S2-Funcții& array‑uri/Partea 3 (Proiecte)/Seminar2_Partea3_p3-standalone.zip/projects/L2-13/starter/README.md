# L2-13 — chunk progresiv (ferestre)
API: `windows(arr, n) → T[][]`

**Learning goals**: declarativ pe array‑uri, teste în oglindă, contracte clare.
