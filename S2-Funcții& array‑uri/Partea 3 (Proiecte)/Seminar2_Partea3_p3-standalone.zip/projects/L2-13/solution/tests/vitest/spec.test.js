import { describe, it, expect } from 'vitest'
import { windows } from '../../solution/src/index.js'
describe('windows',()=>{ it('works',()=>{ expect(windows([1,2,3,4],3)).toEqual([[1,2,3],[2,3,4]]) }) })
