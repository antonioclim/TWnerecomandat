import { describe, it, expect } from '@jest/globals'
import { stats } from '../../solution/src/index.js'
describe('stats',()=>{ it('works',()=>{ expect(stats([1,2,3])).toEqual({sum:6,min:1,max:3,count:3}) }) })
