export function stats(nums)=>{ let sum=0,min=Infinity,max=-Infinity,count=0; for(const n of nums){ sum+=n; if(n<min)min=n; if(n>max)max=n; count++ } return {sum,min,max,count} }
