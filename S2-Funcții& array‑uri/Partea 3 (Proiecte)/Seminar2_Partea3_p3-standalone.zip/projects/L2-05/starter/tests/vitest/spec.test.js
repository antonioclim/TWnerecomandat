import { describe, it, expect } from 'vitest'
import { stats } from '../../starter/src/index.js'
describe('stats',()=>{ it('works',()=>{ expect(stats([1,2,3])).toEqual({sum:6,min:1,max:3,count:3}) }) })
