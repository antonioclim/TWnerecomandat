# L3-04 — Clasificarea erorilor + mesaje prietenoase
API: `friendlyError(e) → string`

**Learning goals**: declarativ pe array‑uri, teste în oglindă, contracte clare.
