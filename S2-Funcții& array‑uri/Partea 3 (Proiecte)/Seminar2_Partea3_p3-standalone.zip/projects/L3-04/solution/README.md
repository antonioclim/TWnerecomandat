# L3-04 — Soluție
Contractele sunt păstrate; testele sunt identice (trebuie să fie verzi).
