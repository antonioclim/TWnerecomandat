export function groupByFacultyYear(rows){ const out={}; for(const r of rows){ const k = String(r.faculty||'').toUpperCase() + '|' + (r.year||0); (out[k]??=([])).push(r) } return out }
