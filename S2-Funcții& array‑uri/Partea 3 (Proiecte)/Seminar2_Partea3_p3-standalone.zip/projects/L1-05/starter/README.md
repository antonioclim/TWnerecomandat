# L1-05 — GroupBy (faculty,year) cu cheie compusă
API: `groupByFacultyYear(rows) → Record<'FAC|YEAR',rows[]>`

**Learning goals**: declarativ pe array‑uri, teste în oglindă, contracte clare.
