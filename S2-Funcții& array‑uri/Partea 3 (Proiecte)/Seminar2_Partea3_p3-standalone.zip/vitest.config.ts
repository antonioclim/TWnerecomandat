import { defineConfig } from 'vitest/config'
export default defineConfig({ test:{ environment:'node', include:['projects/**/starter/tests/vitest/**/*.test.js','projects/**/solution/tests/vitest/**/*.test.js'] } })
