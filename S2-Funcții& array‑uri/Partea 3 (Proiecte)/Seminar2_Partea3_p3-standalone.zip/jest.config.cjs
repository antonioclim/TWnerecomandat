module.exports={ testEnvironment:'node', testMatch:['**/projects/**/{starter,solution}/tests/jest/**/*.jest.test.js'], transform:{'^.+\\.js$':'babel-jest'}, extensionsToTreatAsEsm:['.js'] };
