# Seminarul 2 — Partea 3 (Standalone)
Rulare: `npm i && npm test` (Vitest+Jest), `npm run serve` (server static la http://localhost:8080). E2E (L3): `npm run e2e`. Workbox: `npm run workbox`.
