
import http from 'http'
import { readFile, stat } from 'fs/promises'
import path from 'path'
import { fileURLToPath } from 'url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const PORT = process.env.PORT || 8080
const ROOT = __dirname

const server = http.createServer(async (req, res) => {
  try {
    const urlPath = decodeURIComponent((req.url || '/').split('?')[0])
    let p = path.join(ROOT, urlPath)
    if (p.endsWith(path.sep)) p = path.join(p, 'index.html')
    try { await stat(p) } catch { res.writeHead(404); res.end('Not found'); return }
    const data = await readFile(p)
    res.writeHead(200)
    res.end(data)
  } catch (e) {
    res.writeHead(500)
    res.end(String(e?.message || 'error'))
  }
})

server.listen(PORT, () => console.log('Static server on http://localhost:' + PORT))
