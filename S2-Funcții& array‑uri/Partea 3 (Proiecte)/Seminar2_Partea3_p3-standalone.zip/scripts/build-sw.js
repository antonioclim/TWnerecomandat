import { generateSW } from 'workbox-build';
import { readdirSync } from 'fs';
try {
  const L3dirs = readdirSync('projects').filter(n=>n.startsWith('L3-'));
  for(const d of L3dirs){
    const dir = `projects/${d}/starter/web`;
    await generateSW({
      globDirectory: dir,
      globPatterns: ['**/*.{html,js,css,json}'],
      swDest: `${dir}/sw.js`,
      clientsClaim: true,
      skipWaiting: true
    });
    console.log('Generated SW for', dir);
  }
} catch(e) {
  console.error('Workbox build failed:', e?.message || e)
}
