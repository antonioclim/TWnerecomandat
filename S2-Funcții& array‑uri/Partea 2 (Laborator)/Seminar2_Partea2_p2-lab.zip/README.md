# Seminarul 2 — Laborator (map/filter/reduce, utilitare, chaining)
Acesta este proiectul *starter* pentru Partea 2: implementarea de utilitare pe array‑uri, compunerea într‑un pipeline declarativ și testarea **Vitest & Jest** în oglindă.

## Pași rapizi
```bash
npm i
npm test
npm run dev
```

## Scopuri de învățare (Learning goals)
- Să implementezi funcții *pure* (`groupBy`, `countBy`, `keyBy`, `partition`, `uniqBy`, `difference`, `intersection`, `chunk`, `zip`, `unzip`, `flatten`, `compact`, `pipe`, `tap`).
- Să compui transformări `map/filter/reduce` într‑un pipeline lizibil și testabil.
- Să rulezi suite **Vitest** și **Jest** cu aceleași contracte de test.
