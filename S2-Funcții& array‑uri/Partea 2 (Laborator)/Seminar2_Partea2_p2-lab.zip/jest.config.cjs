module.exports = { testEnvironment:'node', transform:{ '^.+\\.(js|mjs)$': 'babel-jest' }, extensionsToTreatAsEsm:['.js','.mjs'] };
