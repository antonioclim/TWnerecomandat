import fs from 'fs/promises'
import path from 'path'
import { normalizeRecord, parseCSV, parseJSON } from './lib/normalize.js'
import { groupBy, countBy, uniqBy, compact, flatten, pipe, tap } from './lib/collect.js'
import { byFaculty, hasInterest, isValidRecord, andP } from './lib/predicates.js'
import { byCountThenAlpha } from './lib/sorters.js'

function makeIO () {
  return {
    readFile: (p) => fs.readFile(p, 'utf-8'),
    writeOut: (s) => process.stdout.write(s + '\n'),
    writeErr: (s) => process.stderr.write(s + '\n')
  }
}

export async function run (argv, io = makeIO()) {
  const { readFile, writeOut, writeErr } = io
  if (!argv || argv.length < 1) {
    writeErr('Usage: s2-report <file.(csv|json)> [--limit K] [--format table|json] [--faculty NAME] [--has-interest LABEL]')
    return 1
  }
  const opts = parseArgs(argv)
  const filePath = opts._[0]
  let text
  try {
    text = await readFile(filePath)
  } catch (e) {
    writeErr('Cannot read input file: ' + filePath)
    return 1
  }
  const ext = path.extname(filePath).toLowerCase()
  let rows
  try {
    rows = (ext === '.csv') ? parseCSV(text) : parseJSON(text)
  } catch (e) {
    writeErr('Invalid input format: ' + e.message)
    return 1
  }

  // Normalize + validate
  const normalized = rows.map(normalizeRecord)
  const valid = normalized.filter(isValidRecord)

  // Optional filters
  const preds = []
  if (opts.faculty) preds.push(byFaculty(opts.faculty))
  if (opts.hasInterest) preds.push(hasInterest(opts.hasInterest))
  const predicate = preds.length ? preds.reduce(andP) : (() => true)
  const filtered = valid.filter(predicate)

  // Build top-K interests via pipeline
  const interests = pipe(
    (xs) => xs.map(r => r.interests || []),
    flatten,
    compact,
    (xs) => xs.map(x => x.toLowerCase().trim()).filter(Boolean),
    (xs) => Object.entries(countBy(xs, x => x)),
    (entries) => entries.map(([key, count]) => ({ key, count })),
    (arr) => arr.sort(byCountThenAlpha),
    (arr) => arr.slice(0, opts.limit ?? 5),
    tap(() => {}) // hook for debugging dacă e nevoie
  )(filtered)

  const byFac = countBy(filtered, r => r.faculty)

  const report = { total: filtered.length, byFaculty: byFac, topInterests: interests }
  if (opts.format === 'json') {
    writeOut(JSON.stringify(report, null, 2))
  } else {
    const lines = []
    lines.push('=== S2 Report ===')
    lines.push('Total: ' + report.total)
    lines.push('By faculty:')
    for (const [k, v] of Object.entries(report.byFaculty)) lines.push(`  - ${k}: ${v}`)
    lines.push('Top interests:')
    for (const e of report.topInterests) lines.push(`  - ${e.key}: ${e.count}`)
    writeOut(lines.join('\n'))
  }
  return 0
}

function parseArgs (argv) {
  const out = { _: [], format: 'table', limit: 5, faculty: null, hasInterest: null }
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i]
    if (a.startsWith('--')) {
      const [k, v] = a.split('=')
      switch (k) {
        case '--limit': out.limit = Number(v ?? argv[++i]); break
        case '--format': out.format = String(v ?? argv[++i]); break
        case '--faculty': out.faculty = String(v ?? argv[++i]); break
        case '--has-interest': out.hasInterest = String(v ?? argv[++i]); break
      }
    } else {
      out._.push(a)
    }
  }
  return out
}
