import { describe, it, expect } from '@jest/globals'
import { run } from '../../src/cli-runner.js'

function memIO (files = {}) {
  const out = { out:'', err:'' }
  return {
    readFile: async (p) => { if (!(p in files)) throw new Error('nf'); return files[p] },
    writeOut: (s) => { out.out += s + '\n' },
    writeErr: (s) => { out.err += s + '\n' },
    out
  }
}

describe('cli-runner', () => {
  it('usage on missing args', async () => {
    const io = memIO()
    const code = await run([], io)
    expect(code).toBe(1)
    expect(io.out.err).toContain('Usage')
  })
  it('csv -> table report', async () => {
    const csv = 'name,email,faculty,year,interests\nAna,ana@x.org,CSIE,1,AI|Web'
    const io = memIO({ 'data.csv': csv })
    const code = await run(['data.csv','--limit','5','--format','table'], io)
    expect(code).toBe(0)
    expect(io.out.out).toContain('Top interests')
    expect(io.out.out).toContain('AI')
  })
  it('json -> json report', async () => {
    const js = '[{\"name\":\"Ana\",\"email\":\"ana@x.org\",\"faculty\":\"CSIE\",\"year\":1,\"interests\":[\"AI\"]}]'
    const io = memIO({ 'data.json': js })
    const code = await run(['data.json','--limit','3','--format','json'], io)
    expect(code).toBe(0)
    const obj = JSON.parse(io.out.out)
    expect(obj).toHaveProperty('total', 1)
    expect(obj.topInterests[0]).toHaveProperty('key')
  })
})
