import { describe, it, expect } from 'vitest'
import { emailCanon, facultyCanon, interestsNormalize, normalizeRecord, parseCSV, parseJSON } from '../../src/lib/normalize.js'

describe('normalize', () => {
  it('emailCanon', () => {
    expect(emailCanon('  Ana@Example.ORG  ')).toBe('ana@example.org')
  })
  it('facultyCanon', () => {
    expect(facultyCanon('csie')).toBe('CSIE')
    expect(facultyCanon('unknown')).toBe('UNKNOWN')
  })
  it('interestsNormalize', () => {
    expect(interestsNormalize('AI|Web , UX')).toEqual(['AI','Web','UX'])
  })
  it('normalizeRecord', () => {
    const r = normalizeRecord({ name:' Ana ', email:' ANA@x.org ', faculty:'csie', year:'1', interests:'AI|Web' })
    expect(r.faculty).toBe('CSIE'); expect(r.email).toBe('ana@x.org'); expect(r.interests).toEqual(['AI','Web'])
  })
  it('parseCSV/parseJSON', () => {
    const csv = 'name,email,faculty,year,interests\nAna,ana@x.org,CSIE,1,AI|Web'
    const rows = parseCSV(csv); expect(rows[0].name).toBe('Ana')
    const js = '[{\"name\":\"A\",\"email\":\"a@x.org\",\"faculty\":\"CSIE\",\"year\":1,\"interests\":[\"AI\"]}]'
    const rows2 = parseJSON(js); expect(rows2).toHaveLength(1)
  })
})
