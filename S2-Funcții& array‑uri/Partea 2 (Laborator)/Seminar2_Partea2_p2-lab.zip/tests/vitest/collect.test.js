import { describe, it, expect } from 'vitest'
import { groupBy, countBy, uniqBy, partition, differenceBy, intersectionBy, chunk, zip, unzip, flatten, compact } from '../../src/lib/collect.js'

describe('collect utilities', () => {
  it('groupBy basic', () => {
    const g = groupBy(['a','bb','c'], x => String(x).length)
    expect(Object.keys(g)).toEqual(['1','2'])
    expect(g['1']).toEqual(['a','c'])
  })
  it('countBy basic', () => {
    const c = countBy(['AI','Web','AI'], x => x)
    expect(c.AI).toBe(2); expect(c.Web).toBe(1)
  })
  it('uniqBy', () => {
    const u = uniqBy([{e:'a'},{e:'a'},{e:'b'}], x => x.e)
    expect(u).toHaveLength(2)
  })
  it('partition', () => {
    const [even, odd] = partition([1,2,3,4], x => x % 2 === 0)
    expect(even).toEqual([2,4]); expect(odd).toEqual([1,3])
  })
  it('difference/intersection', () => {
    const a = [{id:1},{id:2},{id:3}], b = [{id:2},{id:4}]
    const d = differenceBy(a, b, x => x.id)
    const i = intersectionBy(a, b, x => x.id)
    expect(d.map(x=>x.id)).toEqual([1,3])
    expect(i.map(x=>x.id)).toEqual([2])
  })
  it('chunk/zip/unzip/flatten/compact', () => {
    const ch = chunk([1,2,3,4,5], 2)
    expect(ch).toEqual([[1,2],[3,4],[5]])
    const z = zip([1,2,3],[4,5,6])
    expect(z).toEqual([[1,4],[2,5],[3,6]])
    const [a,b] = unzip(z); expect(a).toEqual([1,2,3]); expect(b).toEqual([4,5,6])
    const f = flatten([[1],[2,3],[],[4]]); expect(f).toEqual([1,2,3,4])
    const c = compact([0,null,undefined,2]); expect(c).toEqual([0,2])
  })
})
