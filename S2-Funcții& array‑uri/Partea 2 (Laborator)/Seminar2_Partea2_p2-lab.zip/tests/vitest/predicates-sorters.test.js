import { describe, it, expect } from 'vitest'
import { byFaculty, hasInterest, isValidRecord } from '../../src/lib/predicates.js'
import { byCountThenAlpha } from '../../src/lib/sorters.js'

describe('predicates & sorters', () => {
  it('byFaculty/hasInterest/isValidRecord', () => {
    const r = { name:'Ana', faculty:'CSIE', interests:['AI','Web'] }
    expect(byFaculty('csie')(r)).toBe(true)
    expect(hasInterest('web')(r)).toBe(true)
    expect(isValidRecord(r)).toBe(true)
  })
  it('byCountThenAlpha', () => {
    const arr = [{key:'Web',count:2},{key:'AI',count:2},{key:'Data',count:3}]
    const sorted = arr.sort(byCountThenAlpha)
    expect(sorted.map(x=>x.key)).toEqual(['Data','AI','Web']) // count desc, then alpha
  })
})
