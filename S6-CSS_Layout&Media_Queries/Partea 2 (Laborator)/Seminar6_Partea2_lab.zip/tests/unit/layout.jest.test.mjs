const fs = require('node:fs'); const path = require('node:path');
const root = path.resolve(__dirname, '..','..');
const read = f => fs.readFileSync(path.join(root, f), 'utf8');

const css = [
  'styles/base.css','styles/typography.css','styles/layout.css','styles/components.css','styles/utilities.css'
].map(read).join('\n');

const htmlIndex = read('public/index.html');
const htmlDetail = read('public/detail.html');

test('has at least three media queries (480, 768, 1200)', () => {
  expect(css).toMatch(/@media\s*\(min-width:\s*480px\)/);
  expect(css).toMatch(/@media\s*\(min-width:\s*768px\)/);
  expect(css).toMatch(/@media\s*\(min-width:\s*1200px\)/);
});
test('uses Grid with auto-fit/minmax for cards', () => {
  expect(css).toMatch(/display:\s*grid/);
  expect(css).toMatch(/grid-template-columns:\s*repeat\(auto-fit,\s*minmax\(/);
});
test('uses Flex with wrap and gap for nav/toolbars', () => {
  expect(css).toMatch(/display:\s*flex/);
  expect(css).toMatch(/flex-wrap:\s*wrap/);
  expect(css).toMatch(/gap:\s*\.?(5|75|1|1\.25|1\.5)rem/);
});
test('controls media ratio and cropping', () => {
  expect(css).toMatch(/aspect-ratio:/);
  expect(css).toMatch(/object-fit:\s*cover/);
});
test('has fluid typography via clamp()', () => {
  expect(css).toMatch(/clamp\(/);
});
test('defines grid-template-areas for the detail page layout', () => {
  expect(css).toMatch(/grid-template-areas/);
});

test('index has main#app and a cards list', () => {
  expect(htmlIndex).toMatch(/<main id="app"/);
  expect(htmlIndex).toMatch(/class="cards"/);
});
test('detail page exposes a .layout container with header/sidebar/main/footer', () => {
  expect(htmlDetail).toMatch(/class="layout"/);
  ['header','sidebar','main','footer'].forEach(area => {
    expect(htmlDetail).toMatch(new RegExp('class="'+area+'"'));
  });
});