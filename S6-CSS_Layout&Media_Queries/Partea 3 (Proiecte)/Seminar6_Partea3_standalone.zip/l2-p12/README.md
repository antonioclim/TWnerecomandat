# Auto‑fit cards + density tokens
**Nivel:** L2

## Learning goals
- Stăpânești alegerea Flex (1D) vs Grid (2D).
- Aplici media queries „content‑based”.
- Controlezi tipografia cu clamp() și imaginile cu aspect‑ratio+object-fit.
- Menții specificitatea redusă și folosești tokens.

## Run
```bash
npm i
npm run dev
npm test
```
