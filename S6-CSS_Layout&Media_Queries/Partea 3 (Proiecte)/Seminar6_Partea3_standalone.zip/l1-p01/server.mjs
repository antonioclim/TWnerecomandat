import express from 'express';
import path from 'path'; import { fileURLToPath } from 'url';
const __filename = fileURLToPath(import.meta.url); const __dirname = path.dirname(__filename);
const app = express(); const PORT = process.env.PORT || 5197;
app.use('/public', express.static(path.join(__dirname,'public')));
app.get('/', (_req,res)=>res.redirect('/public/index.html'));
app.listen(PORT, ()=>console.log(`Server http://localhost:${PORT}`));