const fs = require('node:fs'); const path = require('node:path');
const root = path.resolve(__dirname, '..','..');
const read = f => fs.readFileSync(path.join(root, f), 'utf8');
const cfg = JSON.parse(read('tests/config.json'));
const css = read('styles.css'); const html = read('public/index.html');

test('html contains required fragments', () => {
  (cfg.htmlAllOf || []).forEach(p => expect(html).toMatch(new RegExp(p)));
});
test('css contains all-of patterns', () => {
  (cfg.cssAllOf || []).forEach(p => expect(css).toMatch(new RegExp(p)));
});
test('css contains at least one any-of pattern', () => {
  const any = cfg.cssAnyOf || []; if(any.length===0){ expect(true).toBe(true); return; }
  const ok = any.some(p => new RegExp(p).test(css)); expect(ok).toBe(true);
});