import { initDb } from '../../src/db/index.js';
let db;
beforeAll(async () => { db = await initDb({ test: true, sync: true }); });
afterAll(async () => { await db.sequelize.close(); });

test('PRAGMA foreign_keys=ON', async () => {
  const r = await db.sequelize.query("PRAGMA foreign_keys;");
  expect(r[0][0].foreign_keys).toBe(1);
});

test('unique constraints & validation', async () => {
  await db.Club.create({ id:'c1', name:'Unique Club', category:'art' });
  await expect(db.Club.create({ id:'c2', name:'Unique Club', category:'art' })).rejects.toThrow();
  await db.Member.create({ id:'mem1', fullName:'Test', email:'t@t.ro' });
  await expect(db.Member.create({ id:'mem2', fullName:'X', email:'bad' })).rejects.toThrow();
});