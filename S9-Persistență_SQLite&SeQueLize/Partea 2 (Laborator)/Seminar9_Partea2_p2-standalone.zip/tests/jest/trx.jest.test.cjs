import { initDb } from '../../src/db/index.js';
import { enrollMember } from '../../src/db/services/enroll.js';
let db;
beforeAll(async()=>{ db = await initDb({ test:true, sync:true }); await db.Club.create({ id:'tech', name:'Tech', category:'tech' }); });
afterAll(async()=>{ await db.sequelize.close(); });

test('commit enrollment', async()=>{
  const out = await enrollMember(db, { clubId:'tech', member:{ fullName:'Ana', email:'ana@uni.ro' } });
  expect(out.memberCount).toBe(1);
  const c = await db.Club.findByPk('tech');
  expect(c.memberCount).toBe(1);
});

test('rollback on invalid email', async()=>{
  await expect(enrollMember(db, { clubId:'tech', member:{ fullName:'X', email:'bad' } })).rejects.toThrow();
  const c = await db.Club.findByPk('tech');
  expect(c.memberCount).toBe(1);
});