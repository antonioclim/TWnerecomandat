import { beforeAll, afterAll, test, expect, describe } from 'vitest';
import { initDb } from '../../src/db/index.js';

let db;
beforeAll(async () => { db = await initDb({ test: true, sync: true }); });
afterAll(async () => { await db.sequelize.close(); });

test('PRAGMA foreign_keys=ON', async () => {
  const r = await db.sequelize.query("PRAGMA foreign_keys;");
  expect(r[0][0].foreign_keys).toBe(1);
});

describe('validations & uniqueness', () => {
  test('unique Club.name', async () => {
    await db.Club.create({ id:'tech', name:'Tech & Coding', category:'technology' });
    await expect(db.Club.create({ id:'tech2', name:'Tech & Coding', category:'technology' })).rejects.toThrow();
  });
  test('Member.email is valid & unique', async () => {
    await db.Member.create({ id:'m1', fullName:'Ana Pop', email:'ana@uni.ro' });
    await expect(db.Member.create({ id:'m2', fullName:'Ion', email:'not-an-email' })).rejects.toThrow();
    await expect(db.Member.create({ id:'m3', fullName:'Ana2', email:'ana@uni.ro' })).rejects.toThrow();
  });
});