import { beforeAll, afterAll, test, expect } from 'vitest';
import { initDb } from '../../src/db/index.js';

let db, logs;
beforeAll(async () => {
  logs = [];
  db = await initDb({ test: true, sync: true, logging: (sql)=> logs.push(sql) });
  const { Club, Member, Registration, uuid } = db;
  const c1 = await Club.create({ id:'tech', name:'Tech', category:'tech' });
  const c2 = await Club.create({ id:'arts', name:'Arts', category:'arts' });
  const m1 = await Member.create({ id:'m1', fullName:'Ana', email:'ana@uni.ro' });
  const m2 = await Member.create({ id:'m2', fullName:'Dan', email:'dan@uni.ro' });
  await Registration.create({ id: uuid(), clubId:c1.id, memberId:m1.id, role:'volunteer' });
  await Registration.create({ id: uuid(), clubId:c1.id, memberId:m2.id, role:'member' });
  await Registration.create({ id: uuid(), clubId:c2.id, memberId:m2.id, role:'member' });
});
afterAll(async () => { await db.sequelize.close(); });

test('lazy vs eager', async () => {
  logs.length = 0;
  const clubs = await db.Club.findAll();
  const resLazy = [];
  for(const c of clubs){
    const members = await c.getMembers();
    resLazy.push({ id:c.id, members: members.map(m=>m.id) });
  }
  const lazyQueries = logs.length;

  logs.length = 0;
  const eager = await db.Club.findAll({ include: [{ association:'members', attributes:['id'] }], attributes:['id'] });
  const eagerQueries = logs.length;

  expect(eagerQueries).toBeLessThan(lazyQueries);
  expect(eager[0].members[0].id).toBeDefined();
});