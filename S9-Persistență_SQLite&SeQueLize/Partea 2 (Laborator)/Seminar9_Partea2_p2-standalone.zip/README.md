# Seminar 9 — Partea 2 (Laborator) — Starter

## Run
```bash
npm i
npm test        # Vitest + Jest (sqlite::memory:)
npm run dev     # http://localhost:5609  -> GET /health
```

## Folder structure
- `src/db/` — conexiune, modele, asocieri, servicii (tranzacții).
- `tests/` — suite Vitest/Jest side-by-side.
- `PRAGMA foreign_keys=ON` este activat în `src/db/connection.js`.

## Notă
- Pentru producție, folosește `sequelize-cli` pentru migrații/seeders.
- În test, DB rulează in-memory, izolată pe proces.
