import { makeApp } from './app.js';
const PORT = process.env.PORT || 5609;
makeApp().then(({ app }) => {
  app.listen(PORT, ()=> console.log(`Sem9 API on http://localhost:${PORT}`));
});