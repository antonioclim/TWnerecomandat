import express from 'express';
import cors from 'cors';
import { initDb } from './db/index.js';

export async function makeApp(){
  const db = await initDb({ test:false, sync:true });
  const app = express();
  app.use(cors());
  app.use(express.json());

  app.get('/health', async (req,res)=>{
    const fk = await db.sequelize.query('PRAGMA foreign_keys;');
    res.json({ ok:true, foreign_keys: fk[0][0].foreign_keys, now: new Date().toISOString() });
  });

  return { app, db };
}