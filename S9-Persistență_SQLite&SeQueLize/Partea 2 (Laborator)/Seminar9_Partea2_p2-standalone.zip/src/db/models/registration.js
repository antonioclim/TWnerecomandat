import { DataTypes, Model } from 'sequelize';
export function defineRegistration(sequelize) {
  class Registration extends Model {}
  Registration.init({
    id: { type: DataTypes.STRING, primaryKey: true },
    role: { type: DataTypes.STRING, allowNull: true }
  }, { sequelize, modelName: 'Registration', tableName: 'registrations' });
  return Registration;
}