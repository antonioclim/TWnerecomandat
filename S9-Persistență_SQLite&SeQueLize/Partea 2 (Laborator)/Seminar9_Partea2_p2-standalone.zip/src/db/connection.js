import { Sequelize } from 'sequelize';

export async function makeSequelize({ logging = false, test = false } = {}) {
  const storage = test ? ':memory:' : (process.env.SQLITE_STORAGE || 'db.sqlite');
  const sequelize = new Sequelize({
    dialect: 'sqlite',
    storage,
    logging
  });
  await sequelize.authenticate();
  await sequelize.query('PRAGMA foreign_keys = ON;');
  return sequelize;
}