export function setupAssociations(models){
  const { Club, Member, Registration, Event } = models;
  Club.hasMany(Event, { foreignKey: 'clubId', onDelete: 'CASCADE', as: 'events' });
  Event.belongsTo(Club, { foreignKey: 'clubId', as: 'club' });

  Club.belongsToMany(Member, { through: Registration, foreignKey: 'clubId', otherKey: 'memberId', onDelete: 'CASCADE', as: 'members' });
  Member.belongsToMany(Club, { through: Registration, foreignKey: 'memberId', otherKey: 'clubId', onDelete: 'CASCADE', as: 'clubs' });

  Registration.belongsTo(Club, { foreignKey: 'clubId' });
  Registration.belongsTo(Member, { foreignKey: 'memberId' });
  Club.hasMany(Registration, { foreignKey: 'clubId' });
  Member.hasMany(Registration, { foreignKey: 'memberId' });
}