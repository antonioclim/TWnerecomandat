import { DataTypes, Model } from 'sequelize';
export function defineRegistration(sequelize) {
  class Registration extends Model {}
  Registration.init({
    id: { type: DataTypes.STRING, primaryKey: true },
    role: { type: DataTypes.STRING, allowNull: true },
    clubId: { type: DataTypes.STRING, allowNull:false },
    memberId: { type: DataTypes.STRING, allowNull:false }
  }, {
    sequelize, modelName: 'Registration', tableName: 'registrations',
    indexes: [{ unique: true, fields: ['memberId','clubId'], name: 'registrations_member_club_uq' }]
  });
  return Registration;
}