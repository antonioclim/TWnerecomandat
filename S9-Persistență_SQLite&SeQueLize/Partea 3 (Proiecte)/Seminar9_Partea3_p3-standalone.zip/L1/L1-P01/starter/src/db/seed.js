export async function seedMinimal(db){
  const { Club, Member, Registration, uuid } = db;
  const c1 = await Club.create({ id:'tech', name:'Tech & Coding', category:'tech' });
  const c2 = await Club.create({ id:'arts', name:'Arts & Culture', category:'arts' });
  const m1 = await Member.create({ id:'m1', fullName:'Ana Pop', email:'ANA@UNI.RO' });
  const m2 = await Member.create({ id:'m2', fullName:'Dan Ionescu', email:'dan@uni.ro' });
  await Registration.create({ id: uuid(), clubId:c1.id, memberId:m1.id, role:'volunteer' });
  await Registration.create({ id: uuid(), clubId:c1.id, memberId:m2.id, role:'member' });
  await Registration.create({ id: uuid(), clubId:c2.id, memberId:m2.id, role:'member' });
  return { c1, c2, m1, m2 };
}