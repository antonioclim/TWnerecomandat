# L1-P09 — P09 — Index compus (memberId,clubId) (solution)

**Learning goals**
- modelsBasic, uniqueClub, emailValidation, assoc1N, assocMN, cascade, indexCompound

**Cum rulezi (starter)**
```bash
npm i
npm test          # Vitest + Jest
npm run dev       # http://localhost:5693  -> GET /health
```

**Observații**
- Testele se activează pe baza `tests/config.json` (features).
- DB de test: `sqlite::memory:`; în dev: `db.sqlite`.
