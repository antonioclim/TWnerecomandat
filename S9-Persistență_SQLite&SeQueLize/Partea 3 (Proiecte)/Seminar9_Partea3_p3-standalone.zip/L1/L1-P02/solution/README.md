# L1-P02 — P02 — UNIQUE pe Club.name (solution)

**Learning goals**
- modelsBasic, uniqueClub

**Cum rulezi (starter)**
```bash
npm i
npm test          # Vitest + Jest
npm run dev       # http://localhost:5693  -> GET /health
```

**Observații**
- Testele se activează pe baza `tests/config.json` (features).
- DB de test: `sqlite::memory:`; în dev: `db.sqlite`.
