# L1-P10 — P10 — Seed minimal deterministic (solution)

**Learning goals**
- modelsBasic, uniqueClub, emailValidation, assoc1N, assocMN, cascade, seeders

**Cum rulezi (starter)**
```bash
npm i
npm test          # Vitest + Jest
npm run dev       # http://localhost:5693  -> GET /health
```

**Observații**
- Testele se activează pe baza `tests/config.json` (features).
- DB de test: `sqlite::memory:`; în dev: `db.sqlite`.
