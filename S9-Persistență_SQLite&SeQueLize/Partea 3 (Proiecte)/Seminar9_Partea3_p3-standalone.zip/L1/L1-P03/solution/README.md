# L1-P03 — P03 — Validare email Member (solution)

**Learning goals**
- modelsBasic, uniqueClub, emailValidation

**Cum rulezi (starter)**
```bash
npm i
npm test          # Vitest + Jest
npm run dev       # http://localhost:5693  -> GET /health
```

**Observații**
- Testele se activează pe baza `tests/config.json` (features).
- DB de test: `sqlite::memory:`; în dev: `db.sqlite`.
