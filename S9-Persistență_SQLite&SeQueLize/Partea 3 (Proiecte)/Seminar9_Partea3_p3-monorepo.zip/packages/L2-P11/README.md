# L2-P11 — P11 — Hooks (lowercase email)

**Learning goals**
- modelsBasic, uniqueClub, emailValidation, assoc1N, cascade, eager, transaction, seeders, hooksScopes

**Cum rulezi (starter)**
```bash
npm i
npm test          # Vitest + Jest
npm run dev       # http://localhost:5693  -> GET /health
```

**Observații**
- Testele se activează pe baza `tests/config.json` (features).
- DB de test: `sqlite::memory:`; în dev: `db.sqlite`.
