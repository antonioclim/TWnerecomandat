import { DataTypes, Model } from 'sequelize';
export function defineClub(sequelize) {
  class Club extends Model {}
  Club.init({
    id: { type: DataTypes.STRING, primaryKey: true },
    name: { type: DataTypes.STRING, allowNull: false, unique: true, validate: { len: [3,255] } },
    category: { type: DataTypes.STRING, allowNull: false, defaultValue: 'general' },
    memberCount: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 },
    createdAt: { type: DataTypes.DATE, allowNull: false, defaultValue: DataTypes.NOW },
    updatedAt: { type: DataTypes.DATE, allowNull: false, defaultValue: DataTypes.NOW }
  }, { sequelize, modelName: 'Club', tableName: 'clubs' });
  return Club;
}