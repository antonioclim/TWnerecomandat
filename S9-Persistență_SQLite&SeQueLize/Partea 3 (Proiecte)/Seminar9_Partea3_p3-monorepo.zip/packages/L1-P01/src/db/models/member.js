import { DataTypes, Model } from 'sequelize';
export function defineMember(sequelize) {
  class Member extends Model {}
  Member.init({
    id: { type: DataTypes.STRING, primaryKey: true },
    fullName: { type: DataTypes.STRING, allowNull: false, validate: { len: [3,255] } },
    email: { type: DataTypes.STRING, allowNull: false, unique: true, validate: { isEmail: true } },
    active: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: true },
    createdAt: { type: DataTypes.DATE, allowNull: false, defaultValue: DataTypes.NOW },
    updatedAt: { type: DataTypes.DATE, allowNull: false, defaultValue: DataTypes.NOW }
  }, { sequelize, modelName: 'Member', tableName: 'members' });
  return Member;
}