import { DataTypes, Model } from 'sequelize';
export function defineEvent(sequelize) {
  class Event extends Model {}
  Event.init({
    id: { type: DataTypes.STRING, primaryKey: true },
    title: { type: DataTypes.STRING, allowNull: false },
    startsAt: { type: DataTypes.DATE, allowNull: false },
    location: { type: DataTypes.STRING, allowNull: true }
  }, { sequelize, modelName: 'Event', tableName: 'events' });
  return Event;
}