export async function enrollMember(db, { clubId, member }){
  return await db.sequelize.transaction(async (t)=>{
    const [m] = await db.Member.findOrCreate({
      where: { email: String(member.email).toLowerCase().trim() },
      defaults: { id: db.uuid(), fullName: member.fullName, email: String(member.email).toLowerCase().trim() },
      transaction: t
    });
    await db.Registration.create({ id: db.uuid(), clubId, memberId: m.id, role: member.role||'member' }, { transaction: t });
    const c = await db.Club.findByPk(clubId, { transaction: t });
    c.memberCount = (c.memberCount||0) + 1;
    await c.save({ transaction: t });
    return { clubId: c.id, memberId: m.id, memberCount: c.memberCount };
  });
}