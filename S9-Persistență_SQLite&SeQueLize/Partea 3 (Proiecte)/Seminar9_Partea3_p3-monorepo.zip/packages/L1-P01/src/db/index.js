import { makeSequelize } from './connection.js';
import { defineClub } from './models/club.js';
import { defineMember } from './models/member.js';
import { defineRegistration } from './models/registration.js';
import { defineEvent } from './models/event.js';
import { setupAssociations } from './associations.js';
import crypto from 'node:crypto';

export async function initDb({ logging = false, test = false, sync = true, solution = false } = {}) {
  const sequelize = await makeSequelize({ logging, test });
  const Club = defineClub(sequelize);
  const Member = defineMember(sequelize);
  const Registration = defineRegistration(sequelize);
  const Event = defineEvent(sequelize);
  setupAssociations({ Club, Member, Registration, Event });
  if(sync){ await sequelize.sync({ force: true }); }
  const uuid = () => crypto.randomUUID();
  return { sequelize, Club, Member, Registration, Event, uuid };
}