import { makeApp } from './app.js';
const PORT = process.env.PORT || 5693;
makeApp().then(({ app }) => app.listen(PORT, ()=> console.log(`Sem9 P3 API on http://localhost:${PORT}`)));