import { beforeAll, afterAll, test, expect, describe } from 'vitest';
import fs from 'node:fs'; import path from 'node:path';
import { initDb } from '../src/db/index.js';
import { seedMinimal } from '../src/db/seed.js';
import { enrollMember } from '../src/db/services/enroll.js';

const cfg = JSON.parse(fs.readFileSync(path.join(process.cwd(), 'tests', 'config.json'),'utf-8'));
let db, logs;
beforeAll(async () => {
  logs = [];
  db = await initDb({ test: true, sync: true, logging: (sql)=> logs.push(sql) });
});
afterAll(async () => { await db.sequelize.close(); });

test('foreign_keys=ON', async () => {
  const r = await db.sequelize.query("PRAGMA foreign_keys;");
  expect(r[0][0].foreign_keys).toBe(1);
});

if(cfg.features.modelsBasic){
  test('models exist & can create', async()=>{
    await db.Club.create({ id:'tech', name:'Tech', category:'tech' });
    const found = await db.Club.findByPk('tech'); expect(found).toBeTruthy();
  });
}

if(cfg.features.uniqueClub){
  test('unique Club.name', async()=>{
    await db.Club.create({ id:'c1', name:'UniqueC', category:'x' });
    await expect(db.Club.create({ id:'c2', name:'UniqueC', category:'y' })).rejects.toThrow();
  });
}

if(cfg.features.emailValidation){
  test('email validation', async()=>{
    await expect(db.Member.create({ id:'m1', fullName:'Ana', email:'bad' })).rejects.toThrow();
  });
}

if(cfg.features.assoc1N){
  test('1-N Club-Event', async()=>{
    const c = await db.Club.create({ id:'cE', name:'CE', category:'x' });
    await db.Event.create({ id:'e1', title:'Intro', startsAt:new Date(), clubId:c.id });
    const out = await db.Club.findByPk('cE', { include: [{ association:'events', attributes:['id','title'] }] });
    expect(out.events.length).toBe(1);
  });
}

if(cfg.features.assocMN){
  test('M-N Member-Club through Registration', async()=>{
    const c = await db.Club.create({ id:'cM', name:'CM', category:'x' });
    const m = await db.Member.create({ id:'mM', fullName:'M', email:'m@x.ro' });
    await db.Registration.create({ id: db.uuid(), clubId:c.id, memberId:m.id });
    const withMembers = await db.Club.findByPk('cM', { include:[{ association:'members', attributes:['id','email']}]});
    expect(withMembers.members[0].email).toBe('m@x.ro');
  });
}

if(cfg.features.cascade){
  test('CASCADE delete club removes registrations', async()=>{
    const c = await db.Club.create({ id:'delc', name:'DelC', category:'x' });
    const m = await db.Member.create({ id:'delm', fullName:'Del', email:'d@x.ro' });
    await db.Registration.create({ id: db.uuid(), clubId:c.id, memberId:m.id });
    await c.destroy();
    const left = await db.Registration.findAll({ where: { clubId:'delc' } });
    expect(left.length).toBe(0);
  });
}

if(cfg.features.eager){
  test('lazy vs eager queries', async()=>{
    await seedMinimal(db);
    logs.length = 0;
    const clubs = await db.Club.findAll();
    const resLazy = [];
    for(const c of clubs){
      const members = await c.getMembers();
      resLazy.push({ id:c.id, members: members.map(m=>m.id) });
    }
    const lazyCount = logs.length;

    logs.length = 0;
    const eager = await db.Club.findAll({ include:[{ association:'members', attributes:['id'] }], attributes:['id'] });
    const eagerCount = logs.length;

    expect(eagerCount).toBeLessThan(lazyCount);
    expect(eager[0].members.length).toBeGreaterThan(0);
  });
}

if(cfg.features.transaction){
  test('transaction enroll commit/rollback', async()=>{
    await db.Club.create({ id:'trx', name:'TRX', category:'x' });
    const out = await enrollMember(db, { clubId:'trx', member:{ fullName:'Ana', email:'ana@x.ro' } });
    expect(out.memberCount).toBe(1);
    await expect(enrollMember(db, { clubId:'trx', member:{ fullName:'Bad', email:'bad' } })).rejects.toThrow();
    const c = await db.Club.findByPk('trx'); expect(c.memberCount).toBe(1);
  });
}

if(cfg.features.indexCompound){
  test('composite unique on registrations(memberId,clubId)', async()=>{
    const c = await db.Club.create({ id:'ic', name:'IC', category:'x' });
    const m = await db.Member.create({ id:'im', fullName:'IM', email:'im@x.ro' });
    await db.Registration.create({ id: db.uuid(), clubId:c.id, memberId:m.id });
    await expect(db.Registration.create({ id: db.uuid(), clubId:c.id, memberId:m.id })).rejects.toThrow();
  });
}

if(cfg.features.seeders){
  test('seedMinimal inserts deterministic data', async()=>{
    const { c1, c2, m1, m2 } = await seedMinimal(db);
    expect(c1.id).toBe('tech'); expect(m1.email).toBe('ana@uni.ro'); // lowercased by hook in solution
  });
}

if(cfg.features.hooksScopes){
  test('hooks lower-case email + scope active', async()=>{
    const m = await db.Member.create({ id:'hx', fullName:'HX', email:'HX@UNI.RO' });
    expect(m.email).toBe(m.email.toLowerCase());
    const all = await db.Member.scope('all').findAll();
    const inactiveBefore = await db.Member.scope('inactive').findAll();
    m.active=false; await m.save();
    const inactiveAfter = await db.Member.scope('inactive').findAll();
    expect(inactiveAfter.length).toBeGreaterThan(inactiveBefore.length);
  });
}
