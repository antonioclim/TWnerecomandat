import fs from 'node:fs'; import path from 'node:path';
import { initDb } from '../src/db/index.js';
import { seedMinimal } from '../src/db/seed.js';
import { enrollMember } from '../src/db/services/enroll.js';

const cfg = JSON.parse(fs.readFileSync(path.join(process.cwd(), 'tests', 'config.json'),'utf-8'));
let db, logs;
beforeAll(async () => {
  logs = [];
  db = await initDb({ test: true, sync: true, logging: (sql)=> logs.push(sql) });
});
afterAll(async () => { await db.sequelize.close(); });

test('foreign_keys=ON', async () => {
  const r = await db.sequelize.query("PRAGMA foreign_keys;");
  expect(r[0][0].foreign_keys).toBe(1);
});

if(cfg.features.modelsBasic){
  test('models exist & can create', async()=>{
    await db.Club.create({ id:'t', name:'T', category:'x' });
    const found = await db.Club.findByPk('t'); expect(found).toBeTruthy();
  });
}

if(cfg.features.uniqueClub){
  test('unique Club.name', async()=>{
    await db.Club.create({ id:'u1', name:'UC', category:'x' });
    await expect(db.Club.create({ id:'u2', name:'UC', category:'y' })).rejects.toThrow();
  });
}

if(cfg.features.emailValidation){
  test('email validation', async()=>{
    await expect(db.Member.create({ id:'e1', fullName:'E', email:'bad' })).rejects.toThrow();
  });
}

if(cfg.features.assoc1N){
  test('1-N Club-Event', async()=>{
    const c = await db.Club.create({ id:'cx', name:'CX', category:'x' });
    await db.Event.create({ id:'ex', title:'Intro', startsAt:new Date(), clubId:c.id });
    const out = await db.Club.findByPk('cx', { include:[{ association:'events', attributes:['id'] }] });
    expect(out.events.length).toBe(1);
  });
}

if(cfg.features.assocMN){
  test('M-N Member-Club', async()=>{
    const c = await db.Club.create({ id:'cm', name:'CM', category:'x' });
    const m = await db.Member.create({ id:'mm', fullName:'MM', email:'mm@x.ro' });
    await db.Registration.create({ id: db.uuid(), clubId:c.id, memberId:m.id });
    const withMembers = await db.Club.findByPk('cm', { include:[{ association:'members', attributes:['id','email']}]});
    expect(withMembers.members[0].email).toBe('mm@x.ro');
  });
}

if(cfg.features.cascade){
  test('CASCADE delete club removes registrations', async()=>{
    const c = await db.Club.create({ id:'cd', name:'CD', category:'x' });
    const m = await db.Member.create({ id:'md', fullName:'MD', email:'md@x.ro' });
    await db.Registration.create({ id: db.uuid(), clubId:c.id, memberId:m.id });
    await c.destroy();
    const left = await db.Registration.findAll({ where: { clubId:'cd' } });
    expect(left.length).toBe(0);
  });
}

if(cfg.features.eager){
  test('lazy vs eager', async()=>{
    await seedMinimal(db);
    logs.length = 0;
    const clubs = await db.Club.findAll();
    for(const c of clubs){ await c.getMembers(); }
    const lazyCount = logs.length;
    logs.length = 0;
    const eager = await db.Club.findAll({ include:[{ association:'members', attributes:['id'] }], attributes:['id'] });
    const eagerCount = logs.length;
    expect(eagerCount).toBeLessThan(lazyCount);
    expect(eager[0].members.length).toBeGreaterThan(0);
  });
}

if(cfg.features.transaction){
  test('transaction commit/rollback', async()=>{
    await db.Club.create({ id:'tc', name:'TC', category:'x' });
    const out = await enrollMember(db, { clubId:'tc', member:{ fullName:'Ana', email:'ana@x.ro' } });
    expect(out.memberCount).toBe(1);
    await expect(enrollMember(db, { clubId:'tc', member:{ fullName:'Bad', email:'bad' } })).rejects.toThrow();
    const c = await db.Club.findByPk('tc'); expect(c.memberCount).toBe(1);
  });
}

if(cfg.features.indexCompound){
  test('composite unique registrations', async()=>{
    const c = await db.Club.create({ id:'ci', name:'CI', category:'x' });
    const m = await db.Member.create({ id:'mi', fullName:'MI', email:'mi@x.ro' });
    await db.Registration.create({ id: db.uuid(), clubId:c.id, memberId:m.id });
    await expect(db.Registration.create({ id: db.uuid(), clubId:c.id, memberId:m.id })).rejects.toThrow();
  });
}

if(cfg.features.seeders){
  test('seedMinimal', async()=>{
    const s = await seedMinimal(db);
    expect(s.c1.id).toBe('tech');
  });
}

if(cfg.features.hooksScopes){
  test('hooks & scopes', async()=>{
    const m = await db.Member.create({ id:'hs', fullName:'HS', email:'HS@UNI.RO' });
    expect(m.email).toBe('hs@uni.ro');
    const inactiveBefore = await db.Member.scope('inactive').findAll();
    m.active=false; await m.save();
    const inactiveAfter = await db.Member.scope('inactive').findAll();
    expect(inactiveAfter.length).toBeGreaterThan(inactiveBefore.length);
  });
}
