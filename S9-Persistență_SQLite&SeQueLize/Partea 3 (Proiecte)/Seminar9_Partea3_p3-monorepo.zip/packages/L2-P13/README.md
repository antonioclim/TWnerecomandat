# L2-P13 — P13 — Raport simplu (count members)

**Learning goals**
- modelsBasic, uniqueClub, emailValidation, assoc1N, assocMN, cascade, transaction, indexCompound, seeders, hooksScopes

**Cum rulezi (starter)**
```bash
npm i
npm test          # Vitest + Jest
npm run dev       # http://localhost:5693  -> GET /health
```

**Observații**
- Testele se activează pe baza `tests/config.json` (features).
- DB de test: `sqlite::memory:`; în dev: `db.sqlite`.
