export const evens=xs=>xs.filter(x=>x%2===0);
