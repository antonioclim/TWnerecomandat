Map/Filter/Reduce — `evens(xs)`.
