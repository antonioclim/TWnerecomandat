CLI: `node bin/cli.js 1 2 3` → `6`
