DOM & Events — `npx serve -s public -l 5174`.
