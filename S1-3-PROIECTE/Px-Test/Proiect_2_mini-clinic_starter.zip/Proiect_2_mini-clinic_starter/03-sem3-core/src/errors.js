export class AppError extends Error{} export class ValidationError extends AppError{}
