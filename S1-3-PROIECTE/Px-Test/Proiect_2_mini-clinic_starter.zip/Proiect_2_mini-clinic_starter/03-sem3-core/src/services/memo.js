export const memoize=fn=>{const c=new Map(); return (...a)=>{const k=JSON.stringify(a); if(c.has(k)) return c.get(k); const v=fn(...a); c.set(k,v); return v;}; };
