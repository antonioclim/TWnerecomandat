OOP, erori, memoizare — minimal.
