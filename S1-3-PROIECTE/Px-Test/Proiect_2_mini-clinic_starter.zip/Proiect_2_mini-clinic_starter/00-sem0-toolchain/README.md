npm i && npm run dev
