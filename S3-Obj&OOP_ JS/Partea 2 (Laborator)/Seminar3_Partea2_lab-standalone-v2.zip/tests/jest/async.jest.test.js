import { describe, it, expect } from '@jest/globals';
import { withTimeout, withRetry, makeSemaphore } from '../../src/services/concurrency.js';

describe('concurrency helpers (Jest)', () => {
  it('retry works', async () => {
    let n = 0;
    const fn = async () => { if (n++ < 1) throw new Error('fail'); return 7; };
    const val = await withRetry(fn, { retries: 2, baseMs: 1 });
    expect(val).toBe(7);
  });
});