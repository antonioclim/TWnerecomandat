import { describe, it, expect } from 'vitest';
import { ReportService } from '../../src/services/report.js';

describe('ReportService.topInterests (memo + determinism)', () => {
  it('cache-hit and deterministic order', () => {
    const students = [
      { interests: ['Web','AI'] }, { interests: [' Web ' ] }, { interests: ['UX'] }
    ];
    const r1 = ReportService.topInterests(students, 2);
    const r2 = ReportService.topInterests(students, 2);
    expect(r2).toBe(r1);      // cache hit: aceeași referință
    expect(r1[0].key).toBe('web'); // tie-break corect dacă egalități
  });
});