# Seminarul 3 — Partea 2 (Laborator) — StudentHub Core (v2)

Set de module ESM pentru entități (Student, Club, Event), erori tipizate, servicii asincrone (DirectoryService),
memoization (ReportService.topInterests) și utilitare de concurență (withTimeout, withRetry, makeSemaphore).
Include și memoizeWithTTL. Testele rulează în oglindă (Vitest + Jest).

## Rulare
```bash
npm i
npm run test
```
