import { memoize } from './memo.js';

function topInterestsImpl(students, k = 3) {
  const freq = new Map();
  for (const s of students || []) {
    for (const it of s.interests || []) {
      const key = String(it).toLowerCase().trim();
      if (!key) continue;
      freq.set(key, (freq.get(key) || 0) + 1);
    }
  }
  const arr = [...freq.entries()].map(([key, count]) => ({ key, count }));
  arr.sort((a, b) => b.count - a.count || a.key.localeCompare(b.key, 'ro'));
  return arr.slice(0, k);
}

export const ReportService = {
  topInterests: memoize(topInterestsImpl) // determinist + cache
};