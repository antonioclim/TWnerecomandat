export function memoize(fn) {
  const cache = new Map();
  return function (...args) {
    const key = JSON.stringify(args);
    if (cache.has(key)) return cache.get(key);
    const out = fn.apply(this, args);
    cache.set(key, out);
    return out;
  };
}

export function memoizeWeak(fn) {
  const cache = new WeakMap();
  return function (obj, ...rest) {
    if (obj && typeof obj === 'object') {
      if (cache.has(obj)) return cache.get(obj);
      const out = fn.call(this, obj, ...rest);
      cache.set(obj, out);
      return out;
    }
    return fn.call(this, obj, ...rest);
  };
}

export function memoizeWithTTL(fn, ttlMs = 60000) {
  const cache = new Map();
  return function (...args) {
    const now = Date.now();
    const key = JSON.stringify(args);
    const hit = cache.get(key);
    if (hit && (now - hit.t) < ttlMs) return hit.v;
    const v = fn.apply(this, args);
    cache.set(key, { v, t: now });
    return v;
  };
}