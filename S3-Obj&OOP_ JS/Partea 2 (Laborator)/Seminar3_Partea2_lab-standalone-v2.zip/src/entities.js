import { ValidationError } from './errors.js';

export class Student {
  constructor({ id, name, email, interests = [] } = {}) {
    if (!id || !name || !email) throw new ValidationError('Student fields required');
    this.id = String(id);
    this.name = String(name).trim();
    this.email = String(email).toLowerCase().trim();
    this.interests = Array.isArray(interests) ? interests.slice() : [];
    Object.freeze(this); // shallow immutability
  }
  toString() { return `[Student ${this.id}] ${this.name} <${this.email}>`; }
  get [Symbol.toStringTag]() { return 'Student'; }
}

export class Club {
  constructor({ id, title, tags = [] } = {}) {
    if (!id || !title) throw new ValidationError('Club fields required');
    this.id = String(id);
    this.title = String(title).trim();
    this.tags = Array.isArray(tags) ? tags.slice() : [];
    Object.freeze(this);
  }
  toString() { return `[Club ${this.id}] ${this.title}`; }
  get [Symbol.toStringTag]() { return 'Club'; }
}

export class Event {
  constructor({ id, label, when, clubId } = {}) {
    if (!id || !label || !when) throw new ValidationError('Event fields required');
    this.id = String(id);
    this.label = String(label).trim();
    this.when = new Date(when);
    this.clubId = clubId ? String(clubId) : null;
    Object.freeze(this);
  }
  toString() { return `[Event ${this.id}] ${this.label} @ ${this.when.toISOString()}`; }
  get [Symbol.toStringTag]() { return 'Event'; }
}