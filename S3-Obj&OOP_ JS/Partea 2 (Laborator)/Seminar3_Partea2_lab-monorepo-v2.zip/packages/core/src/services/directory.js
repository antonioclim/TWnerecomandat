import { Student, Club, Event } from '../entities.js';
import { TimeoutError } from '../errors.js';

const delay = (ms) => new Promise(r => setTimeout(r, ms));

async function fetchStudentsMock() {
  await delay(20);
  return [
    new Student({ id: 's1', name: 'Ana Pop', email: 'ana@x.org', interests: ['AI','Web'] }),
    new Student({ id: 's2', name: 'Mihai I.', email: 'mihai@x.org', interests: ['Finance','Web'] }),
    new Student({ id: 's3', name: 'Ioana T.', email: 'ioana@x.org', interests: ['Web','UX'] }),
  ];
}
async function fetchClubsMock() {
  await delay(10);
  return [
    new Club({ id: 'c1', title: 'AI Club', tags: ['AI','ML'] }),
    new Club({ id: 'c2', title: 'Web Club', tags: ['Web','UX'] }),
  ];
}
async function fetchEventsMock() {
  await delay(5);
  return [
    new Event({ id: 'e1', label: 'Hackathon', when: Date.now(), clubId: 'c2' }),
  ];
}

export const DirectoryService = {
  async loadAll({ signal } = {}) {
    const abortable = (p) => new Promise((resolve, reject) => {
      const onAbort = () => reject(new TimeoutError('Aborted'));
      signal?.addEventListener?.('abort', onAbort, { once: true });
      p.then(resolve, reject);
    });
    const results = await Promise.allSettled([
      abortable(fetchStudentsMock()),
      abortable(fetchClubsMock()),
      abortable(fetchEventsMock())
    ]);
    const [students, clubs, events] = results.map(r => r.status === 'fulfilled' ? r.value : []);
    return { students, clubs, events };
  }
};