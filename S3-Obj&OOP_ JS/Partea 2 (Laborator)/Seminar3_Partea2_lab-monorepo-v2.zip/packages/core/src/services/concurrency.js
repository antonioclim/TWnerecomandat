import { TimeoutError } from '../errors.js';

export function withTimeout(promise, ms) {
  return new Promise((resolve, reject) => {
    const t = setTimeout(() => reject(new TimeoutError(`Timeout after ${ms}ms`)), ms);
    promise.then(v => { clearTimeout(t); resolve(v); }, e => { clearTimeout(t); reject(e); });
  });
}

export async function withRetry(fn, { retries = 2, baseMs = 50, classify } = {}) {
  let lastErr;
  for (let i = 0; i <= retries; i++) {
    try {
      return await fn();
    } catch (e) {
      if (classify && classify(e) === 'non-retryable') throw e;
      lastErr = e;
      await new Promise(r => setTimeout(r, baseMs * (2 ** i)));
    }
  }
  throw lastErr;
}

export function makeSemaphore(max = 3) {
  let inFlight = 0;
  const queue = [];
  const runNext = () => {
    if (inFlight >= max || queue.length === 0) return;
    inFlight++;
    const { task, resolve, reject } = queue.shift();
    task().then(v => { inFlight--; resolve(v); runNext(); }, e => { inFlight--; reject(e); runNext(); });
  };
  return {
    schedule(task) {
      return new Promise((resolve, reject) => {
        queue.push({ task, resolve, reject });
        runNext();
      });
    }
  };
}