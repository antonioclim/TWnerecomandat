export class AppError extends Error {
  constructor(message, { cause } = {}) {
    super(message);
    this.name = this.constructor.name;
    if (cause) this.cause = cause;
    Error.captureStackTrace?.(this, this.constructor);
  }
}
export class ValidationError extends AppError {}
export class NotFoundError extends AppError {}
export class RemoteError extends AppError {}
export class TimeoutError extends AppError {}