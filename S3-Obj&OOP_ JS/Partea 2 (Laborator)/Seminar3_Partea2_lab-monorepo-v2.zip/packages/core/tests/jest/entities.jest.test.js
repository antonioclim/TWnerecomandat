import { describe, it, expect } from '@jest/globals';
import { Student } from '../src/entities.js';
import { ValidationError } from '../src/errors.js';

describe('Student entity (Jest)', () => {
  it('frozen + normalized', () => {
    const s = new Student({ id: 1, name: 'Ana', email: 'ANA@X.ORG', interests: ['Web'] });
    expect(Object.isFrozen(s)).toBe(true);
    expect(s.email).toBe('ana@x.org');
  });
  it('invalid → ValidationError', () => {
    expect(() => new Student({ name: 'x' })).toThrow(ValidationError);
  });
});