import { describe, it, expect } from 'vitest';
import { withTimeout, withRetry, makeSemaphore } from '../src/services/concurrency.js';

describe('concurrency helpers (L3)', () => {
  it('withRetry eventually succeeds (exponential backoff)', async () => {
    let n = 0;
    const fn = async () => { if (n++ < 1) throw new Error('fail'); return 42; };
    const val = await withRetry(fn, { retries: 2, baseMs: 1 });
    expect(val).toBe(42);
  });

  it('withTimeout rejects when slow', async () => {
    const slow = new Promise(r => setTimeout(() => r('late'), 30));
    await expect(withTimeout(slow, 5)).rejects.toBeInstanceOf(Error);
  });

  it('semaphore limits inflight', async () => {
    const sem = makeSemaphore(1);
    let concurrent = 0, maxSeen = 0;
    const task = () => new Promise(r => {
      concurrent++; maxSeen = Math.max(maxSeen, concurrent);
      setTimeout(() => { concurrent--; r(1); }, 5);
    });
    await Promise.all([sem.schedule(task), sem.schedule(task), sem.schedule(task)]);
    expect(maxSeen).toBe(1);
  });
});