import { describe, it, expect } from 'vitest';
import { memoizeWithTTL } from '../src/services/memo.js';

describe('memoizeWithTTL', () => {
  it('recomputes after TTL', async () => {
    let calls = 0;
    const fn = (x) => { calls++; return { v: x * 2 }; };
    const m = memoizeWithTTL(fn, 5);
    const a = m(2);
    const b = m(2);
    expect(b).toBe(a);      // cache hit
    await new Promise(r => setTimeout(r, 8));
    const c = m(2);
    expect(c).not.toBe(a);  // recalculat după TTL
    expect(c.v).toBe(4);
    expect(calls).toBe(2);
  });
});