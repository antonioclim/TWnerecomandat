# L3-p07-e2e-site: Playwright e2e — pagină statică StudentHub

## Learning goals
- Înțelegerea cerinței: Mic site static care afișează „Top interests”. Test E2E cu Playwright care verifică conținutul H1 și tabelul.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
