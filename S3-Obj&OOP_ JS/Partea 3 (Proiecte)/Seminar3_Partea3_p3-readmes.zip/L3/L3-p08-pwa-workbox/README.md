# L3-p08-pwa-workbox: PWA (Workbox) — precache „public/”

## Learning goals
- Înțelegerea cerinței: Generează un SW cu `workbox-build` pentru `public/*` și un test smoke că fișierul `sw.js` e generat.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
