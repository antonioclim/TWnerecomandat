# L3-p11-fault-injection: Fault injection pentru retry

## Learning goals
- Înțelegerea cerinței: `sometimesFail(p)` returnează o funcție care eșuează cu probabilitate p; testează `withRetry`.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
