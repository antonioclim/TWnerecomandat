# L3-p15-e2e-form: Playwright: mini‑formular validare

## Learning goals
- Înțelegerea cerinței: Pagină cu formular de email; test E2E care verifică mesajul „invalid email”.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
