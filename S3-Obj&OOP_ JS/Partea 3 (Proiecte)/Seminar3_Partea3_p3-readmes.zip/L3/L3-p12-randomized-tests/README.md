# L3-p12-randomized-tests: Teste randomizate controlate

## Learning goals
- Înțelegerea cerinței: Generator de date de test pentru `topInterests` cu semințe deterministe.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
