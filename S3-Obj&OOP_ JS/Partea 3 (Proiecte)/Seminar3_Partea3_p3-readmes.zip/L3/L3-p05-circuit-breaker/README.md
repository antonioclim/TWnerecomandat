# L3-p05-circuit-breaker: Circuit breaker minimal

## Learning goals
- Înțelegerea cerinței: `makeBreaker({failThreshold, coolMs})` care „deschide” circuitul după erori repetate și „închide” după o pauză.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
