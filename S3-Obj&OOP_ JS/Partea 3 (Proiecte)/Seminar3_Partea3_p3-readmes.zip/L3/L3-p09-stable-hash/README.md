# L3-p09-stable-hash: Hash stabil pentru chei de memo

## Learning goals
- Înțelegerea cerinței: `stableHash(x)` — serializare deterministă (chei sortate).
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
