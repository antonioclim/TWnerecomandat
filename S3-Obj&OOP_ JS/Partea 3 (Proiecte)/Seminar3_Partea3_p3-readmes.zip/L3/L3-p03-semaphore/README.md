# L3-p03-semaphore: Semafor pentru limitarea concurenței

## Learning goals
- Înțelegerea cerinței: `makeSemaphore(n)` cu `schedule(task)`.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
