# L3-p01-retry-backoff: Retry cu backoff și clasificare erori

## Learning goals
- Înțelegerea cerinței: `withRetry(fn, {retries, baseMs, classify})` care oprește pentru `non-retryable`.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
