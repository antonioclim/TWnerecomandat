# L3-p04-abort: AbortController în flux async

## Learning goals
- Înțelegerea cerinței: Funcție `abortable(promise, signal)` care respinge la `abort()`.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
