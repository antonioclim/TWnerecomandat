# L3-p14-e2e-table: Playwright: verifică tabel sortat

## Learning goals
- Înțelegerea cerinței: Test E2E care verifică ordinea alfabetică a intereselor într‑o pagină de demo.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
