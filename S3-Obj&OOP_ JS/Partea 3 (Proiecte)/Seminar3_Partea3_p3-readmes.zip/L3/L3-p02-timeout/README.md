# L3-p02-timeout: Timeout wrapper pentru promisiuni

## Learning goals
- Înțelegerea cerinței: `withTimeout(promise, ms)` aruncă `TimeoutError` la depășire.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
