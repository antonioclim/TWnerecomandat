# L1-p12-mixins: Mixins — Taggable

## Learning goals
- Înțelegerea cerinței: `Taggable(obj)` → adaugă `addTag/removeTag/listTags` pe un obiect (asumă câmpul `tags`).
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
