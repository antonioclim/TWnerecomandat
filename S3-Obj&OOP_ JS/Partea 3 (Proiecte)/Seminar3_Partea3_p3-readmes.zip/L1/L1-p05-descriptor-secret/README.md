# L1-p05-descriptor-secret: Descriptori — proprietate neenumerabilă

## Learning goals
- Înțelegerea cerinței: Scrie `defineSecret(obj, value)` care atașează `secret` **neenumerabil** (`enumerable:false`).
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
