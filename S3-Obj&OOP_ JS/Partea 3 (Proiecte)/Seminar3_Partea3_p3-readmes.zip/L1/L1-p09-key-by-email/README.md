# L1-p09-key-by-email: keyByEmail — mapare rapidă

## Learning goals
- Înțelegerea cerinței: `keyByEmail(list)` → `Map(email → obiect)` cu email normalizat.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
