# L1-p02-club-vo: Club VO — invariante și tags

## Learning goals
- Înțelegerea cerinței: Creează clasa `Club` cu câmpuri `id`, `title` și `tags` (array). Aplică `freeze`, branding și `toString()`.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
