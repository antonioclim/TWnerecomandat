# L1-p14-clone-shallow: cloneShallow — copiere superficială

## Learning goals
- Înțelegerea cerinței: `cloneShallow(o)` → copiază proprietăți proprii fără a duplica referințe interne.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
