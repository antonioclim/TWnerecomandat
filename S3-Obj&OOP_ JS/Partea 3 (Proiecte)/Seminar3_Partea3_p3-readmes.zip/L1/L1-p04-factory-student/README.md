# L1-p04-factory-student: Factory + Object.create + prototip

## Learning goals
- Înțelegerea cerinței: Scrie `makeStudent` care aplică invariante și setează prototipul `studentProto` via `Object.create`.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
