# L1-p06-branding-tag: Branding — Symbol.toStringTag utilitar

## Learning goals
- Înțelegerea cerinței: `brand(obj, tag)` setează `Symbol.toStringTag` pentru obiecte date.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
