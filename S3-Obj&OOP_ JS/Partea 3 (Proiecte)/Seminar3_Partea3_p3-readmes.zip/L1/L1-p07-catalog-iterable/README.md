# L1-p07-catalog-iterable: Catalog iterabil — Symbol.iterator

## Learning goals
- Înțelegerea cerinței: Construiți `Catalog` care iterează studenții în ordinea inserării.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
