# L2-p13-collator-sort: Sortare cu Intl.Collator('ro')

## Learning goals
- Înțelegerea cerinței: `sortAlphaRo(arr)` sortează alfabetizat, cu diacritice corect.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
