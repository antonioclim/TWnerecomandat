# L2-p06-adapter-dto: Adapter DTO din JSON cu whitelisting

## Learning goals
- Înțelegerea cerinței: `adaptStudent(json)` extrage doar câmpurile permise, ignorând `__proto__/constructor`.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
