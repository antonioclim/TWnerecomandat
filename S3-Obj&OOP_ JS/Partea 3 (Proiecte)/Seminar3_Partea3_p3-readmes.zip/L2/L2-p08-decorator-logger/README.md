# L2-p08-decorator-logger: Decorator funcțional de logging/timing

## Learning goals
- Înțelegerea cerinței: `timed(fn)` → întoarce o funcție care returnează `{ value, ms }`.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
