# L2-p14-deep-freeze: deepFreeze utilitar (simplu)

## Learning goals
- Înțelegerea cerinței: `deepFreeze(o)` care îngheață recursiv obiectele simple (evită cicluri).
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
