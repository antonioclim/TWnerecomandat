# L2-p02-memoize-weak: memoizeWeak pe obiect‑cheie

## Learning goals
- Înțelegerea cerinței: `memoizeWeak(fn)` → cache `WeakMap(obj→rezultat)`.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
