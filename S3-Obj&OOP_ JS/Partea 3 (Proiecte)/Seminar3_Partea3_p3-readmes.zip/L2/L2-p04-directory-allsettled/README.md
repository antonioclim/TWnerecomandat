# L2-p04-directory-allsettled: DirectoryService cu Promise.allSettled

## Learning goals
- Înțelegerea cerinței: Încarcă 3 surse mock în paralel; la eșec, întoarce liste goale în câmpul aferent.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
