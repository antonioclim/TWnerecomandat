# L2-p05-report-topk: ReportService.topInterests determinist

## Learning goals
- Înțelegerea cerinței: Calculează top‑K interese (insensibil la caz + whitespace) cu tie‑break alfabetic.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
