# L2-p15-memo-ttl: memoizeWithTTL

## Learning goals
- Înțelegerea cerinței: `memoizeWithTTL(fn, ttlMs)` ca în Partea 2.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
