# L2-p09-idempotent-add: Idempotent add în repo

## Learning goals
- Înțelegerea cerinței: `addOnce(repo, entity)` — nu adăuga dacă `id` există deja.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
