// tests/pwa.spec.ts
import fs from 'node:fs';
import path from 'node:path';
import { test, expect } from '@playwright/test';
test('sw exists after build', async () => {
  const sw = path.join(process.cwd(), 'public', 'sw.js');
  expect(fs.existsSync(sw)).toBe(true);
});