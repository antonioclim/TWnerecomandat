# L3-p13-async-queue: Coada asincronă cu ratelimiting

## Learning goals
- Înțelegerea cerinței: `makeQueue({concurrency, intervalMs})` execută taskurile cu un delay minim între starturi.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
