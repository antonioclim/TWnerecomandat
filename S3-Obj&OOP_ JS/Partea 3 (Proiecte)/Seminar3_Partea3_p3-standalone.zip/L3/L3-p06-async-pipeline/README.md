# L3-p06-async-pipeline: Pipeline asincron cu routing de erori

## Learning goals
- Înțelegerea cerinței: `runPipeline(steps)` unde fiecare step este `async (ctx) => ctx`. Erorile annotate cu `ctx.errors`.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
