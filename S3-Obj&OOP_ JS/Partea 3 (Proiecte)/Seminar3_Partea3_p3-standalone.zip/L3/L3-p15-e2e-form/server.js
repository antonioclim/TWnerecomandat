// server.js
import express from 'express';
const app = express();
app.use(express.static('public'));
const PORT = process.env.PORT || 4175;
app.listen(PORT, ()=> console.log('Server on http://localhost:'+PORT));