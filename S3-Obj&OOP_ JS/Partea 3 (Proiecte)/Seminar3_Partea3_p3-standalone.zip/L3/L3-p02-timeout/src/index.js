export class AppError extends Error {
  constructor(message, { cause } = {}) { super(message); this.name = this.constructor.name; if (cause) this.cause = cause; }
}
export class ValidationError extends AppError {}
export class NotFoundError extends AppError {}
export class TimeoutError extends AppError {}

export function withTimeout(promise, ms){ return new Promise((resolve,reject)=>{ const t=setTimeout(()=>reject(new TimeoutError('Timeout')), ms); promise.then(v=>{clearTimeout(t); resolve(v);},e=>{clearTimeout(t); reject(e);}); }); }
