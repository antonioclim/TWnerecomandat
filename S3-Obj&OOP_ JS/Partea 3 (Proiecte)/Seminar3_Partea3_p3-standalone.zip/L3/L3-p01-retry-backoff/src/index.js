export class AppError extends Error {
  constructor(message, { cause } = {}) { super(message); this.name = this.constructor.name; if (cause) this.cause = cause; }
}
export class ValidationError extends AppError {}
export class NotFoundError extends AppError {}
export class TimeoutError extends AppError {}

export async function withRetry(fn, { retries=2, baseMs=10, classify }={}) {
  let last;
  for(let i=0;i<=retries;i++){ try{ return await fn(); }catch(e){ if(classify && classify(e)==='non-retryable') throw e; last=e; await new Promise(r=>setTimeout(r, baseMs*(2**i))); } }
  throw last;
}
