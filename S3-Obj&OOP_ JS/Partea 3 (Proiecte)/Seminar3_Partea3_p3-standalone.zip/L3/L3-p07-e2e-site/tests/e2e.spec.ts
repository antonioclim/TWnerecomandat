// tests/e2e.spec.ts
import { test, expect } from '@playwright/test';
test('home has title and table', async ({ page }) => {
  await page.goto('http://localhost:4173');
  await expect(page.locator('h1')).toHaveText(/StudentHub/);
  await expect(page.locator('table tr')).toHaveCount(4);
});