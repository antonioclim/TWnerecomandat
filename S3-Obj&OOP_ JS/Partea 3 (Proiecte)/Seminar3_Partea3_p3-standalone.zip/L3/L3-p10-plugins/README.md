# L3-p10-plugins: Pluginuri pentru ReportService

## Learning goals
- Înțelegerea cerinței: `makeReportService(plugins)` unde pluginurile sunt funcții `(data)=>partial` combinate într‑un obiect rezultat.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
