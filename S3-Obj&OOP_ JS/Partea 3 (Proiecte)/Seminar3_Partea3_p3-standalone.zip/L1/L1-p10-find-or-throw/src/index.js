export class AppError extends Error {
  constructor(message, { cause } = {}) { super(message); this.name = this.constructor.name; if (cause) this.cause = cause; }
}
export class ValidationError extends AppError {}
export class NotFoundError extends AppError {}
export class TimeoutError extends AppError {}

export function findStudentById(list,id){const it=(list||[]).find(s=>String(s.id)===String(id)); if(!it) throw new NotFoundError('Student not found'); return it;}
