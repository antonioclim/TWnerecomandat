export class AppError extends Error {
  constructor(message, { cause } = {}) { super(message); this.name = this.constructor.name; if (cause) this.cause = cause; }
}
export class ValidationError extends AppError {}
export class NotFoundError extends AppError {}
export class TimeoutError extends AppError {}

export class Event {
  constructor({ id, label, when, clubId } = {}) {
    if (!id || !label || !when) throw new ValidationError('Event fields required');
    this.id = String(id);
    this.label = String(label).trim();
    this.when = new Date(when);
    this.clubId = clubId ? String(clubId) : null;
    Object.freeze(this);
  }
  toString() { return `[Event ${this.id}] ${this.label} @ ${this.when.toISOString()}`; }
  get [Symbol.toStringTag]() { return 'Event'; }
}
