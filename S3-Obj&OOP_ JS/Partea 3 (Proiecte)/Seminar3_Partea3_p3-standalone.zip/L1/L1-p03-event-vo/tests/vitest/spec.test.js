import { describe, it, expect } from 'vitest';
import { Event, ValidationError } from '../../src/index.js';
describe('Event', () => {
  it('iso toString', () => {
    const e = new Event({ id:1, label:'Hack', when: 0 });
    expect(e.toString()).toContain('1970-01-01');
  });
  it('throws', () => {
    expect(()=> new Event({ id:1, label:'x'})).toThrow(ValidationError);
  });
});