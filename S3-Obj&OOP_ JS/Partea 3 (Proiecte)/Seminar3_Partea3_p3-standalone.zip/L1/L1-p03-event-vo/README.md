# L1-p03-event-vo: Event VO — dată și toString()

## Learning goals
- Înțelegerea cerinței: Implementează `Event` cu `id`, `label`, `when` (Date), `clubId?`. `freeze`, branding și `toString()` ISO.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
