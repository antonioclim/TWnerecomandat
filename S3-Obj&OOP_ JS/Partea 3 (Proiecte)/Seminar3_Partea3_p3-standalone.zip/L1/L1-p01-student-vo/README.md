# L1-p01-student-vo: Student VO — invariante, freeze, branding

## Learning goals
- Înțelegerea cerinței: Creează clasa `Student` cu câmpuri obligatorii `id`, `name`, `email`, listă opțională `interests`.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
