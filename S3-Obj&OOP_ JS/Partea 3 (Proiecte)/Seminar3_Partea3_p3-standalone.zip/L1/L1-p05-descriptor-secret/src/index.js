export function defineSecret(obj, value) {
  Object.defineProperty(obj, 'secret', { value, enumerable:false, writable:false, configurable:false });
  return obj;
}
