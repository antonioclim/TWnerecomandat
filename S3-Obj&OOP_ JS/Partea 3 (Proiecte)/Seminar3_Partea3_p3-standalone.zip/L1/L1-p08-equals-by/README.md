# L1-p08-equals-by: equalsBy — egalitate pe câmpuri

## Learning goals
- Înțelegerea cerinței: `equalsBy(keys, a, b)` verifică egalitatea pe un set de chei.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
