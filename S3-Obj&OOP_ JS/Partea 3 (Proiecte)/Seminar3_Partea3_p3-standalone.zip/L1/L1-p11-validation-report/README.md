# L1-p11-validation-report: Raport de validare (Ok/Err)

## Learning goals
- Înțelegerea cerinței: `validateStudent(obj)` → `{ ok:true, value }` sau `{ ok:false, error:'...' }` fără a arunca.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
