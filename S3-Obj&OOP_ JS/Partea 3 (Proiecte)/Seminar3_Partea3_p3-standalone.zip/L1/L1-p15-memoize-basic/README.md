# L1-p15-memoize-basic: memoize — versiune de bază

## Learning goals
- Înțelegerea cerinței: `memoize(fn)` — cache pe cheie `JSON.stringify(args)`.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
