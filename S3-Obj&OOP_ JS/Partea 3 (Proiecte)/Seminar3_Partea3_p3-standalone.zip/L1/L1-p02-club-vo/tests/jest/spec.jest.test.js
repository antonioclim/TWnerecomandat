import { describe, it, expect } from '@jest/globals';
import { Club, ValidationError } from '../../src/index.js';
describe('Club (Jest)', () => {
  it('branding', () => {
    const c = new Club({ id:1, title:'AI Club'});
    expect(Object.prototype.toString.call(c)).toContain('Club');
  });
});