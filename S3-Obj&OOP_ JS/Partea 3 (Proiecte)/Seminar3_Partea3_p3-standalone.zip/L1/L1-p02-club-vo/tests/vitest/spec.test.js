import { describe, it, expect } from 'vitest';
import { Club, ValidationError } from '../../src/index.js';
describe('Club', () => {
  it('freeze + branding', () => {
    const c = new Club({ id:'c1', title:'Web Club', tags:['Web']});
    expect(Object.isFrozen(c)).toBe(true);
    expect(Object.prototype.toString.call(c)).toContain('Club');
  });
  it('throws on missing', () => {
    expect(()=> new Club({})).toThrow(ValidationError);
  });
});