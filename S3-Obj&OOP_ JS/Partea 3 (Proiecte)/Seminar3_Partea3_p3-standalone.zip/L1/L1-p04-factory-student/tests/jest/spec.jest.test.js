import { describe, it, expect } from '@jest/globals';
import { makeStudent } from '../../src/index.js';
describe('makeStudent (Jest)', () => {
  it('frozen', () => {
    const s = makeStudent({ id:1, name:'Ana', email:'a@a' });
    expect(Object.isFrozen(s)).toBe(true);
  });
});