import { describe, it, expect } from 'vitest';
import { makeStudent } from '../../src/index.js';
describe('makeStudent', () => {
  it('has prototype branding', () => {
    const s = makeStudent({ id:1, name:'Ana', email:'a@a' });
    expect(Object.prototype.toString.call(s)).toContain('Student');
  });
});