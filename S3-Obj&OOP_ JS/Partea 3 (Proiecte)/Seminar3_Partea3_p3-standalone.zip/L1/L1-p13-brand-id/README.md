# L1-p13-brand-id: Branding ID cu Symbol

## Learning goals
- Înțelegerea cerinței: `brandId(obj, ns)` atașează `Symbol('id:'+ns)` pentru a „marca” un obiect fără coliziuni.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
