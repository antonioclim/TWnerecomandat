# Seminarul 3 — Partea 3 — Standalone projects

Fiecare proiect este independent. Intrați în subdirector și rulați testele.
