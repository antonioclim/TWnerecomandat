# L2-p07-async-iterator: Async iterator peste evenimente (batchuri)

## Learning goals
- Înțelegerea cerinței: `makeAsyncEvents(batches)` → obiect cu `Symbol.asyncIterator` care produce evenimentele pe rând.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
