# L2-p03-errors-cause: Erori cu `cause` și mesaje prietenoase

## Learning goals
- Înțelegerea cerinței: Definește `AppError` + derivate și propagă `cause` în `wrap(fn)`.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
