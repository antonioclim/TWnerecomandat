# L2-p10-schema-check: Validator simplu de „schemă”

## Learning goals
- Înțelegerea cerinței: `validateShape(obj, shape)` — shape: `{ field: 'string'|'number'|'array' }`.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
