# L2-p12-hasinstance: Personalizează instanceof (Symbol.hasInstance)

## Learning goals
- Înțelegerea cerinței: Clasa `Email` să accepte stringuri `a@b` ca instanțe logice: `'a@b' instanceof Email` → true.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
