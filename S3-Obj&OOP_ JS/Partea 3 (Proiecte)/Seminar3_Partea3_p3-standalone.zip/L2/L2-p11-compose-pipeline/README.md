# L2-p11-compose-pipeline: Compose de funcții pure pentru agregare

## Learning goals
- Înțelegerea cerinței: `compose(...fns)` → `f(g(h(x)))`.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
