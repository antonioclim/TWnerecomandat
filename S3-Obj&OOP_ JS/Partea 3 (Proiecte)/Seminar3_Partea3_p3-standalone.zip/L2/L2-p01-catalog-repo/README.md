# L2-p01-catalog-repo: Catalog + repository în memorie

## Learning goals
- Înțelegerea cerinței: `CatalogRepo` cu `add(entity)` idempotent și `getById(id)`.
- Implementarea soluției propuse.
- Testare în oglindă (Vitest & Jest).

## Rulare
```bash
npm i
npm run test
```
