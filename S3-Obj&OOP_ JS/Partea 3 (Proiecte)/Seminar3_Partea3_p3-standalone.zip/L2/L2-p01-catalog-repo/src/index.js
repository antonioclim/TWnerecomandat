export class AppError extends Error {
  constructor(message, { cause } = {}) { super(message); this.name = this.constructor.name; if (cause) this.cause = cause; }
}
export class ValidationError extends AppError {}
export class NotFoundError extends AppError {}
export class TimeoutError extends AppError {}

export class CatalogRepo {
  constructor() { this.store=new Map(); }
  add(e) { this.store.set(String(e.id), e); return e; }
  getById(id) { const x=this.store.get(String(id)); if(!x) throw new NotFoundError('Not found'); return x; }
  list() { return [...this.store.values()]; }
}
