const delay=ms=>new Promise(r=>setTimeout(r,ms));
async function s(){await delay(5); return [{id:'s1'}];}
async function c(){await delay(5); return [{id:'c1'}];}
async function e(){await delay(5); return [{id:'e1'}];}
export async function loadAll(){ const res=await Promise.allSettled([s(),c(),e()]); return {students:res[0].status==='fulfilled'?res[0].value:[], clubs:res[1].status==='fulfilled'?res[1].value:[], events:res[2].status==='fulfilled'?res[2].value:[]}; }