# L2-p02-memoize-weak: memoizeWeak pe obiect‑cheie

## Learning goals
- `memoizeWeak(fn)` → cache `WeakMap(obj→rezultat)`.

## Rulare
```bash
pnpm i
pnpm -F @s3/L2-p02-memoize-weak exec vitest run --reporter verbose
pnpm -F @s3/L2-p02-memoize-weak exec jest --runInBand
```
