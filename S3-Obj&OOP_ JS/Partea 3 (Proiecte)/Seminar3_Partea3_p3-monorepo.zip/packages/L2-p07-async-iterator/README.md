# L2-p07-async-iterator: Async iterator peste evenimente (batchuri)

## Learning goals
- `makeAsyncEvents(batches)` → obiect cu `Symbol.asyncIterator` care produce evenimentele pe rând.

## Rulare
```bash
pnpm i
pnpm -F @s3/L2-p07-async-iterator exec vitest run --reporter verbose
pnpm -F @s3/L2-p07-async-iterator exec jest --runInBand
```
