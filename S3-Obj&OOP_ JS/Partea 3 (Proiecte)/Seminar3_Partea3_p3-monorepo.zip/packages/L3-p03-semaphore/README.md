# L3-p03-semaphore: Semafor pentru limitarea concurenței

## Learning goals
- `makeSemaphore(n)` cu `schedule(task)`.

## Rulare
```bash
pnpm i
pnpm -F @s3/L3-p03-semaphore exec vitest run --reporter verbose
pnpm -F @s3/L3-p03-semaphore exec jest --runInBand
```
