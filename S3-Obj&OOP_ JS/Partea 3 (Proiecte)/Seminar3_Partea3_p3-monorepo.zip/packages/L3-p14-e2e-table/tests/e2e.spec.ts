// tests/sort.spec.ts
import { test, expect } from '@playwright/test';
test('table sorted', async ({ page }) => {
  await page.goto('http://localhost:4174');
  const cells = await page.locator('table tr td:first-child').allTextContents();
  const sorted = [...cells].sort((a,b)=>a.localeCompare(b,'ro'));
  expect(cells).toEqual(sorted);
});