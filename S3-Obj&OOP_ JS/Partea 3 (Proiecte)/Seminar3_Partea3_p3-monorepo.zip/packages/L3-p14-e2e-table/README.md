# L3-p14-e2e-table: Playwright: verifică tabel sortat

## Learning goals
- Test E2E care verifică ordinea alfabetică a intereselor într‑o pagină de demo.

## Rulare
```bash
pnpm i
pnpm -F @s3/L3-p14-e2e-table exec vitest run --reporter verbose
pnpm -F @s3/L3-p14-e2e-table exec jest --runInBand
```
