# L2-p13-collator-sort: Sortare cu Intl.Collator('ro')

## Learning goals
- `sortAlphaRo(arr)` sortează alfabetizat, cu diacritice corect.

## Rulare
```bash
pnpm i
pnpm -F @s3/L2-p13-collator-sort exec vitest run --reporter verbose
pnpm -F @s3/L2-p13-collator-sort exec jest --runInBand
```
