# L1-p12-mixins: Mixins — Taggable

## Learning goals
- `Taggable(obj)` → adaugă `addTag/removeTag/listTags` pe un obiect (asumă câmpul `tags`).

## Rulare
```bash
pnpm i
pnpm -F @s3/L1-p12-mixins exec vitest run --reporter verbose
pnpm -F @s3/L1-p12-mixins exec jest --runInBand
```
