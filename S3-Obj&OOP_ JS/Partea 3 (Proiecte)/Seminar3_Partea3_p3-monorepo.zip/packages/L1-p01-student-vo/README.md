# L1-p01-student-vo: Student VO — invariante, freeze, branding

## Learning goals
- Creează clasa `Student` cu câmpuri obligatorii `id`, `name`, `email`, listă opțională `interests`.

## Rulare
```bash
pnpm i
pnpm -F @s3/L1-p01-student-vo exec vitest run --reporter verbose
pnpm -F @s3/L1-p01-student-vo exec jest --runInBand
```
