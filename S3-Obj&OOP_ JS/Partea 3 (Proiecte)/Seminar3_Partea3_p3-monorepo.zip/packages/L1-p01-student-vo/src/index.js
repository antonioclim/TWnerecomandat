export class AppError extends Error {
  constructor(message, { cause } = {}) { super(message); this.name = this.constructor.name; if (cause) this.cause = cause; }
}
export class ValidationError extends AppError {}
export class NotFoundError extends AppError {}
export class TimeoutError extends AppError {}

export class Student {
  constructor({ id, name, email, interests = [] } = {}) {
    if (!id || !name || !email) throw new ValidationError('Student fields required');
    this.id = String(id);
    this.name = String(name).trim();
    this.email = String(email).toLowerCase().trim();
    this.interests = Array.isArray(interests) ? interests.slice() : [];
    Object.freeze(this);
  }
  toString() { return `[Student ${this.id}] ${this.name} <${this.email}>`; }
  get [Symbol.toStringTag]() { return 'Student'; }
}
