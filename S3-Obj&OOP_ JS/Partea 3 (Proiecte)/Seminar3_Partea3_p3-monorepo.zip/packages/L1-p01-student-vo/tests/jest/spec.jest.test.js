import { describe, it, expect } from '@jest/globals';
import { Student, ValidationError } from '../../src/index.js';
describe('Student (Jest)', () => {
  it('freeze + normalize email', () => {
    const s = new Student({ id:1, name:'Ana', email:'ANA@X.ORG'});
    expect(Object.isFrozen(s)).toBe(true);
    expect(s.email).toBe('ana@x.org');
  });
  it('throws on missing', () => {
    expect(()=> new Student({ name:'x'})).toThrow(ValidationError);
  });
});