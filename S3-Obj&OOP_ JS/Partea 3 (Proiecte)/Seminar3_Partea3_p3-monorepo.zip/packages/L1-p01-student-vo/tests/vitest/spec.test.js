import { describe, it, expect } from 'vitest';
import { Student, ValidationError } from '../../src/index.js';
describe('Student', () => {
  it('freeze + normalize email', () => {
    const s = new Student({ id:1, name:'Ana', email:'ANA@X.ORG', interests:['Web']});
    expect(Object.isFrozen(s)).toBe(true);
    expect(s.email).toBe('ana@x.org');
  });
  it('throws on missing fields', () => {
    expect(()=> new Student({ name:'x'})).toThrow(ValidationError);
  });
});