# L1-p09-key-by-email: keyByEmail — mapare rapidă

## Learning goals
- `keyByEmail(list)` → `Map(email → obiect)` cu email normalizat.

## Rulare
```bash
pnpm i
pnpm -F @s3/L1-p09-key-by-email exec vitest run --reporter verbose
pnpm -F @s3/L1-p09-key-by-email exec jest --runInBand
```
