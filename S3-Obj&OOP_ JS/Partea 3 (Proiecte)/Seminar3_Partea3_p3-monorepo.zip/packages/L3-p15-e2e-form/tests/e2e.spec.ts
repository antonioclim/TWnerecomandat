// tests/form.spec.ts
import { test, expect } from '@playwright/test';
test('invalid email shows error', async ({ page }) => {
  await page.goto('http://localhost:4175');
  await page.fill('input[name=email]', 'invalid');
  await page.click('button[type=submit]');
  await expect(page.locator('#msg')).toHaveText(/invalid/i);
});