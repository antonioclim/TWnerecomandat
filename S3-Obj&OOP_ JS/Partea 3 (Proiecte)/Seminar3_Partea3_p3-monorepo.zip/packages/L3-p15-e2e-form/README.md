# L3-p15-e2e-form: Playwright: mini‑formular validare

## Learning goals
- Pagină cu formular de email; test E2E care verifică mesajul „invalid email”.

## Rulare
```bash
pnpm i
pnpm -F @s3/L3-p15-e2e-form exec vitest run --reporter verbose
pnpm -F @s3/L3-p15-e2e-form exec jest --runInBand
```
