import { describe, it, expect } from '@jest/globals'; import { stableHash } from '../../src/index.js';
describe('stableHash (Jest)', ()=>{ it('scalars', ()=>{ expect(stableHash(1)).toBe('1'); }); });