# L3-p09-stable-hash: Hash stabil pentru chei de memo

## Learning goals
- `stableHash(x)` — serializare deterministă (chei sortate).

## Rulare
```bash
pnpm i
pnpm -F @s3/L3-p09-stable-hash exec vitest run --reporter verbose
pnpm -F @s3/L3-p09-stable-hash exec jest --runInBand
```
