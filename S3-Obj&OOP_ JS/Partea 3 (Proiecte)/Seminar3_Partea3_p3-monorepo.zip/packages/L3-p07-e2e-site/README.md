# L3-p07-e2e-site: Playwright e2e — pagină statică StudentHub

## Learning goals
- Mic site static care afișează „Top interests”. Test E2E cu Playwright care verifică conținutul H1 și tabelul.

## Rulare
```bash
pnpm i
pnpm -F @s3/L3-p07-e2e-site exec vitest run --reporter verbose
pnpm -F @s3/L3-p07-e2e-site exec jest --runInBand
```
