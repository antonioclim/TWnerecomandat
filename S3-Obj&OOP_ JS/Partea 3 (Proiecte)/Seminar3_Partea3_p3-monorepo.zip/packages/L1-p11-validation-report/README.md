# L1-p11-validation-report: Raport de validare (Ok/Err)

## Learning goals
- `validateStudent(obj)` → `{ ok:true, value }` sau `{ ok:false, error:'...' }` fără a arunca.

## Rulare
```bash
pnpm i
pnpm -F @s3/L1-p11-validation-report exec vitest run --reporter verbose
pnpm -F @s3/L1-p11-validation-report exec jest --runInBand
```
