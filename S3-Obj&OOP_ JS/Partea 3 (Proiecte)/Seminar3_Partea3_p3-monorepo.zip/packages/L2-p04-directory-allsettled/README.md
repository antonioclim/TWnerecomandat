# L2-p04-directory-allsettled: DirectoryService cu Promise.allSettled

## Learning goals
- Încarcă 3 surse mock în paralel; la eșec, întoarce liste goale în câmpul aferent.

## Rulare
```bash
pnpm i
pnpm -F @s3/L2-p04-directory-allsettled exec vitest run --reporter verbose
pnpm -F @s3/L2-p04-directory-allsettled exec jest --runInBand
```
