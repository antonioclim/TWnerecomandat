# L3-p10-plugins: Pluginuri pentru ReportService

## Learning goals
- `makeReportService(plugins)` unde pluginurile sunt funcții `(data)=>partial` combinate într‑un obiect rezultat.

## Rulare
```bash
pnpm i
pnpm -F @s3/L3-p10-plugins exec vitest run --reporter verbose
pnpm -F @s3/L3-p10-plugins exec jest --runInBand
```
