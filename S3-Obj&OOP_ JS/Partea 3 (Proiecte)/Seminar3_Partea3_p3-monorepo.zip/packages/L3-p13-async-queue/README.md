# L3-p13-async-queue: Coada asincronă cu ratelimiting

## Learning goals
- `makeQueue({concurrency, intervalMs})` execută taskurile cu un delay minim între starturi.

## Rulare
```bash
pnpm i
pnpm -F @s3/L3-p13-async-queue exec vitest run --reporter verbose
pnpm -F @s3/L3-p13-async-queue exec jest --runInBand
```
