# L3-p08-pwa-workbox: PWA (Workbox) — precache „public/”

## Learning goals
- Generează un SW cu `workbox-build` pentru `public/*` și un test smoke că fișierul `sw.js` e generat.

## Rulare
```bash
pnpm i
pnpm -F @s3/L3-p08-pwa-workbox exec vitest run --reporter verbose
pnpm -F @s3/L3-p08-pwa-workbox exec jest --runInBand
```
