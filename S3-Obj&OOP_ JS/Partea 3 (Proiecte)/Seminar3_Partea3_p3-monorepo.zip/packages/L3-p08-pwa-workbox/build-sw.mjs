// build-sw.mjs
import {{ generateSW }} from 'workbox-build';
const { count, size, warnings } = await generateSW({{
  globDirectory: 'public',
  globPatterns: ['**/*.*'],
  swDest: 'public/sw.js',
  skipWaiting: true,
  clientsClaim: true
}});
console.log('SW', {count, size, warnings});