# L2-p01-catalog-repo: Catalog + repository în memorie

## Learning goals
- `CatalogRepo` cu `add(entity)` idempotent și `getById(id)`.

## Rulare
```bash
pnpm i
pnpm -F @s3/L2-p01-catalog-repo exec vitest run --reporter verbose
pnpm -F @s3/L2-p01-catalog-repo exec jest --runInBand
```
