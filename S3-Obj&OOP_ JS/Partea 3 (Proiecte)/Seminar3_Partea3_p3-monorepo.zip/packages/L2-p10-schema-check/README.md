# L2-p10-schema-check: Validator simplu de „schemă”

## Learning goals
- `validateShape(obj, shape)` — shape: `{ field: 'string'|'number'|'array' }`.

## Rulare
```bash
pnpm i
pnpm -F @s3/L2-p10-schema-check exec vitest run --reporter verbose
pnpm -F @s3/L2-p10-schema-check exec jest --runInBand
```
