import { describe, it, expect } from 'vitest'; import { compose } from '../../src/index.js';
describe('compose', ()=>{ it('works', ()=>{ const f=compose(x=>x+1, x=>x*2); expect(f(2)).toBe(5); }); });