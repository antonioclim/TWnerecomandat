# L2-p11-compose-pipeline: Compose de funcții pure pentru agregare

## Learning goals
- `compose(...fns)` → `f(g(h(x)))`.

## Rulare
```bash
pnpm i
pnpm -F @s3/L2-p11-compose-pipeline exec vitest run --reporter verbose
pnpm -F @s3/L2-p11-compose-pipeline exec jest --runInBand
```
