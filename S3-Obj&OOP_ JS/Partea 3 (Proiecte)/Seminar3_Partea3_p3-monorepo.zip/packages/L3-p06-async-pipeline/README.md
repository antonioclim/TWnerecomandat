# L3-p06-async-pipeline: Pipeline asincron cu routing de erori

## Learning goals
- `runPipeline(steps)` unde fiecare step este `async (ctx) => ctx`. Erorile annotate cu `ctx.errors`.

## Rulare
```bash
pnpm i
pnpm -F @s3/L3-p06-async-pipeline exec vitest run --reporter verbose
pnpm -F @s3/L3-p06-async-pipeline exec jest --runInBand
```
