# L3-p05-circuit-breaker: Circuit breaker minimal

## Learning goals
- `makeBreaker({failThreshold, coolMs})` care „deschide” circuitul după erori repetate și „închide” după o pauză.

## Rulare
```bash
pnpm i
pnpm -F @s3/L3-p05-circuit-breaker exec vitest run --reporter verbose
pnpm -F @s3/L3-p05-circuit-breaker exec jest --runInBand
```
