# L1-p06-branding-tag: Branding — Symbol.toStringTag utilitar

## Learning goals
- `brand(obj, tag)` setează `Symbol.toStringTag` pentru obiecte date.

## Rulare
```bash
pnpm i
pnpm -F @s3/L1-p06-branding-tag exec vitest run --reporter verbose
pnpm -F @s3/L1-p06-branding-tag exec jest --runInBand
```
