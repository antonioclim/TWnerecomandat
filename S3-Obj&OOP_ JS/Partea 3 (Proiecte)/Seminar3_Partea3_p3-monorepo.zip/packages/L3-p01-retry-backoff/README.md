# L3-p01-retry-backoff: Retry cu backoff și clasificare erori

## Learning goals
- `withRetry(fn, {retries, baseMs, classify})` care oprește pentru `non-retryable`.

## Rulare
```bash
pnpm i
pnpm -F @s3/L3-p01-retry-backoff exec vitest run --reporter verbose
pnpm -F @s3/L3-p01-retry-backoff exec jest --runInBand
```
