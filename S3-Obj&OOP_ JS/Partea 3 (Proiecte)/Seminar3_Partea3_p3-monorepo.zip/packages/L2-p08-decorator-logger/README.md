# L2-p08-decorator-logger: Decorator funcțional de logging/timing

## Learning goals
- `timed(fn)` → întoarce o funcție care returnează `{ value, ms }`.

## Rulare
```bash
pnpm i
pnpm -F @s3/L2-p08-decorator-logger exec vitest run --reporter verbose
pnpm -F @s3/L2-p08-decorator-logger exec jest --runInBand
```
