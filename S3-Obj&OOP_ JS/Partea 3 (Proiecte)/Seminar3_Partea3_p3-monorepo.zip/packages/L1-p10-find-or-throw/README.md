# L1-p10-find-or-throw: findStudentById — NotFoundError

## Learning goals
- `findStudentById(list, id)` → returnează studentul sau aruncă `NotFoundError`.

## Rulare
```bash
pnpm i
pnpm -F @s3/L1-p10-find-or-throw exec vitest run --reporter verbose
pnpm -F @s3/L1-p10-find-or-throw exec jest --runInBand
```
