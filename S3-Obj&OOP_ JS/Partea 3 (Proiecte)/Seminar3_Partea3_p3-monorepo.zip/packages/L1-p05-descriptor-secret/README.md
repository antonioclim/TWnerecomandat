# L1-p05-descriptor-secret: Descriptori — proprietate neenumerabilă

## Learning goals
- Scrie `defineSecret(obj, value)` care atașează `secret` **neenumerabil** (`enumerable:false`).

## Rulare
```bash
pnpm i
pnpm -F @s3/L1-p05-descriptor-secret exec vitest run --reporter verbose
pnpm -F @s3/L1-p05-descriptor-secret exec jest --runInBand
```
