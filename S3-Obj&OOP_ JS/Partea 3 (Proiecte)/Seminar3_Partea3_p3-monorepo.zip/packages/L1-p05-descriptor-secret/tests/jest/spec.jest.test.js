import { describe, it, expect } from '@jest/globals';
import { defineSecret } from '../../src/index.js';
describe('defineSecret (Jest)', () => {
  it('visible by direct access', () => {
    const o = defineSecret({}, 1);
    expect('secret' in o).toBe(true);
  });
});