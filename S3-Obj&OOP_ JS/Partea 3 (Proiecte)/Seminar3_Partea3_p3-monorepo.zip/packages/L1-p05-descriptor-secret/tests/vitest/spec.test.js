import { describe, it, expect } from 'vitest';
import { defineSecret } from '../../src/index.js';
describe('defineSecret', () => {
  it('non-enumerable', () => {
    const o = defineSecret({ a:1 }, 7);
    expect(Object.keys(o)).not.toContain('secret');
    expect(o.secret).toBe(7);
  });
});