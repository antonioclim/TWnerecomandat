# L3-p02-timeout: Timeout wrapper pentru promisiuni

## Learning goals
- `withTimeout(promise, ms)` aruncă `TimeoutError` la depășire.

## Rulare
```bash
pnpm i
pnpm -F @s3/L3-p02-timeout exec vitest run --reporter verbose
pnpm -F @s3/L3-p02-timeout exec jest --runInBand
```
