# L3-p11-fault-injection: Fault injection pentru retry

## Learning goals
- `sometimesFail(p)` returnează o funcție care eșuează cu probabilitate p; testează `withRetry`.

## Rulare
```bash
pnpm i
pnpm -F @s3/L3-p11-fault-injection exec vitest run --reporter verbose
pnpm -F @s3/L3-p11-fault-injection exec jest --runInBand
```
