# L1-p04-factory-student: Factory + Object.create + prototip

## Learning goals
- Scrie `makeStudent` care aplică invariante și setează prototipul `studentProto` via `Object.create`.

## Rulare
```bash
pnpm i
pnpm -F @s3/L1-p04-factory-student exec vitest run --reporter verbose
pnpm -F @s3/L1-p04-factory-student exec jest --runInBand
```
