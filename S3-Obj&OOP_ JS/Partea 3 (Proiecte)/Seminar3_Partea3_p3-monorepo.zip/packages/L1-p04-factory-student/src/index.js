export class AppError extends Error {
  constructor(message, { cause } = {}) { super(message); this.name = this.constructor.name; if (cause) this.cause = cause; }
}
export class ValidationError extends AppError {}
export class NotFoundError extends AppError {}
export class TimeoutError extends AppError {}

const studentProto = {
  toString() { return `[Student ${this.id}] ${this.name} <${this.email}>`; },
  get [Symbol.toStringTag]() { return 'Student'; }
};
export function makeStudent({ id, name, email, interests = [] } = {}) {
  if (!id || !name || !email) throw new ValidationError('Student fields required');
  const self = { id:String(id), name:String(name).trim(), email:String(email).toLowerCase().trim(), interests:Array.isArray(interests)?interests.slice():[] };
  Object.freeze(self);
  return Object.setPrototypeOf(self, studentProto);
}
