# L3-p12-randomized-tests: Teste randomizate controlate

## Learning goals
- Generator de date de test pentru `topInterests` cu semințe deterministe.

## Rulare
```bash
pnpm i
pnpm -F @s3/L3-p12-randomized-tests exec vitest run --reporter verbose
pnpm -F @s3/L3-p12-randomized-tests exec jest --runInBand
```
