# L2-p05-report-topk: ReportService.topInterests determinist

## Learning goals
- Calculează top‑K interese (insensibil la caz + whitespace) cu tie‑break alfabetic.

## Rulare
```bash
pnpm i
pnpm -F @s3/L2-p05-report-topk exec vitest run --reporter verbose
pnpm -F @s3/L2-p05-report-topk exec jest --runInBand
```
