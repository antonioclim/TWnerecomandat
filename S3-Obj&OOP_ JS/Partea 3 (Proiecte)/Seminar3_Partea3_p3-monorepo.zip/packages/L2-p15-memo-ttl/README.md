# L2-p15-memo-ttl: memoizeWithTTL

## Learning goals
- `memoizeWithTTL(fn, ttlMs)` ca în Partea 2.

## Rulare
```bash
pnpm i
pnpm -F @s3/L2-p15-memo-ttl exec vitest run --reporter verbose
pnpm -F @s3/L2-p15-memo-ttl exec jest --runInBand
```
