# L1-p13-brand-id: Branding ID cu Symbol

## Learning goals
- `brandId(obj, ns)` atașează `Symbol('id:'+ns)` pentru a „marca” un obiect fără coliziuni.

## Rulare
```bash
pnpm i
pnpm -F @s3/L1-p13-brand-id exec vitest run --reporter verbose
pnpm -F @s3/L1-p13-brand-id exec jest --runInBand
```
