# L2-p03-errors-cause: Erori cu `cause` și mesaje prietenoase

## Learning goals
- Definește `AppError` + derivate și propagă `cause` în `wrap(fn)`.

## Rulare
```bash
pnpm i
pnpm -F @s3/L2-p03-errors-cause exec vitest run --reporter verbose
pnpm -F @s3/L2-p03-errors-cause exec jest --runInBand
```
