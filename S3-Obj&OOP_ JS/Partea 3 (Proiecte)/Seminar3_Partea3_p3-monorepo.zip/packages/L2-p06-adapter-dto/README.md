# L2-p06-adapter-dto: Adapter DTO din JSON cu whitelisting

## Learning goals
- `adaptStudent(json)` extrage doar câmpurile permise, ignorând `__proto__/constructor`.

## Rulare
```bash
pnpm i
pnpm -F @s3/L2-p06-adapter-dto exec vitest run --reporter verbose
pnpm -F @s3/L2-p06-adapter-dto exec jest --runInBand
```
