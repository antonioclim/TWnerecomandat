# L1-p15-memoize-basic: memoize — versiune de bază

## Learning goals
- `memoize(fn)` — cache pe cheie `JSON.stringify(args)`.

## Rulare
```bash
pnpm i
pnpm -F @s3/L1-p15-memoize-basic exec vitest run --reporter verbose
pnpm -F @s3/L1-p15-memoize-basic exec jest --runInBand
```
