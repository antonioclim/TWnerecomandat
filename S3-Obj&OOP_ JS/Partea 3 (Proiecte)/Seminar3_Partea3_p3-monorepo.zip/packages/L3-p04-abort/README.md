# L3-p04-abort: AbortController în flux async

## Learning goals
- Funcție `abortable(promise, signal)` care respinge la `abort()`.

## Rulare
```bash
pnpm i
pnpm -F @s3/L3-p04-abort exec vitest run --reporter verbose
pnpm -F @s3/L3-p04-abort exec jest --runInBand
```
