# L1-p03-event-vo: Event VO — dată și toString()

## Learning goals
- Implementează `Event` cu `id`, `label`, `when` (Date), `clubId?`. `freeze`, branding și `toString()` ISO.

## Rulare
```bash
pnpm i
pnpm -F @s3/L1-p03-event-vo exec vitest run --reporter verbose
pnpm -F @s3/L1-p03-event-vo exec jest --runInBand
```
