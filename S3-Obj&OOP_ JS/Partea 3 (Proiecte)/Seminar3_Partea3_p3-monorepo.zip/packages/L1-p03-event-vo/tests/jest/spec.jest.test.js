import { describe, it, expect } from '@jest/globals';
import { Event } from '../../src/index.js';
describe('Event (Jest)', () => {
  it('branding', () => {
    const e = new Event({ id:1, label:'Hack', when:0 });
    expect(Object.prototype.toString.call(e)).toContain('Event');
  });
});