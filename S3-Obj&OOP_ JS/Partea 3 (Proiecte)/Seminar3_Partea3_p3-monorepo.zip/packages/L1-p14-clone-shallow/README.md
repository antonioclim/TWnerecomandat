# L1-p14-clone-shallow: cloneShallow — copiere superficială

## Learning goals
- `cloneShallow(o)` → copiază proprietăți proprii fără a duplica referințe interne.

## Rulare
```bash
pnpm i
pnpm -F @s3/L1-p14-clone-shallow exec vitest run --reporter verbose
pnpm -F @s3/L1-p14-clone-shallow exec jest --runInBand
```
