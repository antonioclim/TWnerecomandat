# L2-p12-hasinstance: Personalizează instanceof (Symbol.hasInstance)

## Learning goals
- Clasa `Email` să accepte stringuri `a@b` ca instanțe logice: `'a@b' instanceof Email` → true.

## Rulare
```bash
pnpm i
pnpm -F @s3/L2-p12-hasinstance exec vitest run --reporter verbose
pnpm -F @s3/L2-p12-hasinstance exec jest --runInBand
```
