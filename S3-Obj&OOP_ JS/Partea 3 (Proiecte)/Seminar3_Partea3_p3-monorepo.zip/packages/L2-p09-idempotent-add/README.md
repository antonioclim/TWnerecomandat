# L2-p09-idempotent-add: Idempotent add în repo

## Learning goals
- `addOnce(repo, entity)` — nu adăuga dacă `id` există deja.

## Rulare
```bash
pnpm i
pnpm -F @s3/L2-p09-idempotent-add exec vitest run --reporter verbose
pnpm -F @s3/L2-p09-idempotent-add exec jest --runInBand
```
