# L1-p08-equals-by: equalsBy — egalitate pe câmpuri

## Learning goals
- `equalsBy(keys, a, b)` verifică egalitatea pe un set de chei.

## Rulare
```bash
pnpm i
pnpm -F @s3/L1-p08-equals-by exec vitest run --reporter verbose
pnpm -F @s3/L1-p08-equals-by exec jest --runInBand
```
