# L2-p14-deep-freeze: deepFreeze utilitar (simplu)

## Learning goals
- `deepFreeze(o)` care îngheață recursiv obiectele simple (evită cicluri).

## Rulare
```bash
pnpm i
pnpm -F @s3/L2-p14-deep-freeze exec vitest run --reporter verbose
pnpm -F @s3/L2-p14-deep-freeze exec jest --runInBand
```
