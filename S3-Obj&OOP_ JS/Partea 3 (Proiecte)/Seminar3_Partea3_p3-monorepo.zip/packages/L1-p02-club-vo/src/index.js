export class AppError extends Error {
  constructor(message, { cause } = {}) { super(message); this.name = this.constructor.name; if (cause) this.cause = cause; }
}
export class ValidationError extends AppError {}
export class NotFoundError extends AppError {}
export class TimeoutError extends AppError {}

export class Club {
  constructor({ id, title, tags = [] } = {}) {
    if (!id || !title) throw new ValidationError('Club fields required');
    this.id = String(id);
    this.title = String(title).trim();
    this.tags = Array.isArray(tags) ? tags.slice() : [];
    Object.freeze(this);
  }
  toString() { return `[Club ${this.id}] ${this.title}`; }
  get [Symbol.toStringTag]() { return 'Club'; }
}
