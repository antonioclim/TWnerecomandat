# L1-p02-club-vo: Club VO — invariante și tags

## Learning goals
- Creează clasa `Club` cu câmpuri `id`, `title` și `tags` (array). Aplică `freeze`, branding și `toString()`.

## Rulare
```bash
pnpm i
pnpm -F @s3/L1-p02-club-vo exec vitest run --reporter verbose
pnpm -F @s3/L1-p02-club-vo exec jest --runInBand
```
