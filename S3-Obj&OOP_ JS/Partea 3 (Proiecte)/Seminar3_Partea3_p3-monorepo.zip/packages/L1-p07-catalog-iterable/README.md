# L1-p07-catalog-iterable: Catalog iterabil — Symbol.iterator

## Learning goals
- Construiți `Catalog` care iterează studenții în ordinea inserării.

## Rulare
```bash
pnpm i
pnpm -F @s3/L1-p07-catalog-iterable exec vitest run --reporter verbose
pnpm -F @s3/L1-p07-catalog-iterable exec jest --runInBand
```
