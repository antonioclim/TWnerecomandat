# Seminarul 3 — Partea 3 — Monorepo (PNPM)

Rulare: `pnpm i && pnpm run test`.
