# Seminarul 1 — Partea 2 (Laborator)
CLI pentru raport „StudentHub” — funcții pure, map/filter/reduce, teste (Vitest & Jest).

## Rulare
```bash
npm i
npm test
npm run dev
# Sau:
node bin/cli.js data/sample.csv --limit 5 --format json
```

## Structură
- `src/lib/` — funcții pure (parse, transform, filters, format)
- `src/cli-runner.js` — orchestrare CLI (injectabilă în teste)
- `bin/cli.js` — intrare CLI
- `tests/` — Vitest & Jest în oglindă
- `data/` — fișiere exemplu

## Learning goals
- Să scrii funcții pure și pipelines declarative.
- Să separi I/O (CLI) de logică.
- Să validezi cu teste duble (Vitest & Jest).
