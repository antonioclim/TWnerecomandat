import { describe, it, expect } from '@jest/globals'
import { groupBy, countBy, topK } from '../../src/lib/transform.js'

describe('transform', () => {
  const rows = [
    { faculty:'CSIE', interests:['AI','Web'] },
    { faculty:'REI', interests:['Finance','Web'] },
    { faculty:'CSIE', interests:['Web','UX'] }
  ]

  it('groupBy faculty', () => {
    const g = groupBy(rows, r => r.faculty)
    expect(Object.keys(g)).toEqual(['CSIE','REI'])
    expect(g.CSIE).toHaveLength(2)
  })

  it('countBy interest', () => {
    const c = countBy(rows.flatMap(r => r.interests), x => x)
    expect(c.Web).toBe(3)
  })

  it('topK', () => {
    const arr = [{k:'A',n:2},{k:'B',n:5},{k:'C',n:1}]
    const top = topK(arr, 2, e => e.n)
    expect(top.map(x => x.k)).toEqual(['B','A'])
  })
})
