import { describe, it, expect } from 'vitest'
import { run } from '../../src/cli-runner.js'

function makeMemIO (files = {}) {
  const out = { out:'', err:'' }
  return {
    out,
    readFile: async (p) => {
      if (!(p in files)) throw new Error('nf')
      return files[p]
    },
    writeOut: (s) => { out.out += s + '\n' },
    writeErr: (s) => { out.err += s + '\n' }
  }
}

describe('cli-runner', () => {
  it('usage on missing args', async () => {
    const io = makeMemIO()
    const code = await run([], io)
    expect(code).toBe(1)
    expect(io.out.out).toBe('')
    expect(io.err).toBeDefined()
  })

  it('csv happy path (table)', async () => {
    const io = makeMemIO({ 'data.csv': 'name,faculty,interests\nAna,CSIE,AI|Web' })
    const code = await run(['data.csv','--format','table','--limit','5'], io)
    expect(code).toBe(0)
    expect(io.out.out).toContain('Total entries: 1')
    expect(io.out.out).toContain('CSIE: 1')
  })

  it('json happy path (json)', async () => {
    const io = makeMemIO({ 'data.json': '[{\"name\":\"Ana\",\"faculty\":\"CSIE\",\"interests\":[\"AI\"]}]' })
    const code = await run(['data.json','--format','json','--limit','3'], io)
    expect(code).toBe(0)
    expect(JSON.parse(io.out.out)).toHaveProperty('total', 1)
  })
})
