# L2-P11 — P11 — Logging minimal (stderr) fără a polua stdout
**Nivel:** L2

## Learning goals
- Fixezi competența: P11 — Logging minimal (stderr) fără a polua stdout.
- Exersezi separarea **logică pură** vs. **I/O** în CLI.
- Scrii teste **Vitest & Jest** pe aceleași contracte.

## Cerințe (rezumat)
- Implementarea funcțiilor din `src/lib/*` astfel încât testele să devină verzi.
- Orchestrare în `src/cli-runner.js` conform opțiunilor CLI de laborator.
- Rulează `npm test` și apoi `npm run dev` pe `data/sample.csv`.

## Pași rapizi
```bash
npm i
npm test
npm run dev
```
