import { describe, it, expect } from 'vitest'
import { countBy, topK } from '../../src/lib/transform.js'
describe('transform', () => {
  it('countBy', () => {
    const c = countBy(['A','B','A','C','B','A'], x => x)
    expect(c.A).toBe(3); expect(c.B).toBe(2); expect(c.C).toBe(1)
  })
  it('topK', () => {
    const arr = [{k:'A',n:2},{k:'B',n:5},{k:'C',n:1}]
    const top = topK(arr, 2, e => e.n)
    expect(top.map(x => x.k)).toEqual(['B','A'])
  })
})
