import { describe, it, expect } from 'vitest'
import { parseCSV, parseJSON } from '../../src/lib/parse.js'
describe('parse', () => {
  it('CSV basic', () => {
    const csv = 'name,faculty,interests\nAna,CSIE,AI|Web'
    const rows = parseCSV(csv)
    expect(rows).toHaveLength(1)
    expect(rows[0].interests).toEqual(['AI','Web'])
  })
  it('JSON basic', () => {
    const json = '[{\"name\":\"Ana\",\"faculty\":\"CSIE\",\"interests\":[\"AI\"]}]'
    const rows = parseJSON(json)
    expect(rows[0].faculty).toBe('CSIE')
  })
})
