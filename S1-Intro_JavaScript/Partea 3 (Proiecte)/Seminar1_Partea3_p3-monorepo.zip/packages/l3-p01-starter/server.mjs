import http from 'http'
import { readFile } from 'fs/promises'
import { extname } from 'path'
const mime = { '.html':'text/html', '.js':'application/javascript', '.json':'application/json', '.css':'text/css' }
const server = http.createServer(async (req,res)=>{
  const url = req.url === '/' ? '/index.html' : req.url
  try {
    const data = await readFile(new URL('./public' + url, import.meta.url))
    res.setHeader('Content-Type', mime[extname(url)] || 'text/plain')
    res.end(data)
  } catch (e) {
    if (url === '/report.json') {
      res.setHeader('Content-Type','application/json'); res.end(JSON.stringify({ total: 1 })); return
    }
    res.statusCode = 404; res.end('Not found')
  }
})
const PORT = process.env.PORT || 4173
server.listen(PORT, ()=> console.log('Server on http://localhost:'+PORT))
