import { test, expect } from '@playwright/test'
test('viewer shows total', async ({ page }) => {
  await page.goto('/')
  await expect(page.locator('h1')).toHaveText(/Report Viewer/i)
  const pre = page.locator('#out')
  await expect(pre).toContainText('total')
})
