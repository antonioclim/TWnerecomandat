import { defineConfig } from '@playwright/test'
export default defineConfig({
  testDir: 'e2e',
  retries: process.env.CI ? 2 : 0,
  use: { baseURL: 'http://localhost:4173' },
  webServer: { command: 'node server.mjs', port: 4173, reuseExistingServer: !process.env.CI }
})
