import { generateSW } from 'workbox-build'
const { count, size } = await generateSW({
  globDirectory: 'public',
  globPatterns: ['**/*.{html,js,css,json}'],
  swDest: 'public/sw.js',
  clientsClaim: true,
  skipWaiting: true
})
console.log(`Generated sw.js for ${count} files (${size} bytes).`)
