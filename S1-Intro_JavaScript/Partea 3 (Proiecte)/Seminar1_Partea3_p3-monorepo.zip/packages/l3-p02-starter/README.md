# L3-P02 — P02 — Iterare linie‑cu‑linie (readline) asupra CSV mare
**Nivel:** L3

## Learning goals
- Fixezi competența: P02 — Iterare linie‑cu‑linie (readline) asupra CSV mare.
- Exersezi separarea **logică pură** vs. **I/O** în CLI.
- Scrii teste **Vitest & Jest** pe aceleași contracte.

## Cerințe (rezumat)
- Implementarea funcțiilor din `src/lib/*` astfel încât testele să devină verzi.
- Orchestrare în `src/cli-runner.js` conform opțiunilor CLI de laborator.
- Rulează `npm test` și apoi `npm run dev` pe `data/sample.csv`.

## Pași rapizi
```bash
npm i
npm test
npm run dev
```
