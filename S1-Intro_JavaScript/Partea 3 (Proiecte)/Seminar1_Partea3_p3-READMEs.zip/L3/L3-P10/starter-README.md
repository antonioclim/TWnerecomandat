# L3-P10 — P10 — Playwright e2e (smoke) pe interfață
**Nivel:** L3

## Learning goals
- Fixezi competența: P10 — Playwright e2e (smoke) pe interfață.
- Exersezi separarea **logică pură** vs. **I/O** în CLI.
- Scrii teste **Vitest & Jest** pe aceleași contracte.

## Cerințe (rezumat)
- Implementarea funcțiilor din `src/lib/*` astfel încât testele să devină verzi.
- Orchestrare în `src/cli-runner.js` conform opțiunilor CLI de laborator.
- Rulează `npm test` și apoi `npm run dev` pe `data/sample.csv`.

## Pași rapizi
```bash
npm i
npm test
npm run dev
```
