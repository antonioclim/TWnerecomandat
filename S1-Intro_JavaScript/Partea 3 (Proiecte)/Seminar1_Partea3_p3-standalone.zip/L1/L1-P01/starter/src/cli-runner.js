import { parseCSV, parseJSON } from './lib/parse.js'
import { countBy, topK } from './lib/transform.js'
import { filterNewMembers, byFaculty } from './lib/filters.js'
import { formatTable, toJSON } from './lib/format.js'
import fs from 'fs/promises'
import path from 'path'

function makeIO () {
  return {
    readFile: (p) => fs.readFile(p, 'utf-8'),
    writeOut: (s) => process.stdout.write(s + '\n'),
    writeErr: (s) => process.stderr.write(s + '\n')
  }
}

export async function run (argv, io = makeIO()) {
  const { writeOut, writeErr, readFile } = io
  if (!argv || argv.length < 1) {
    writeErr('Usage: studenthub-report <file.(csv|json)> [--limit N] [--format table|json] [--faculty CSIE] [--new-only] [--ref-date YYYY-MM-DD]')
    return 1
  }
  const opts = parseArgs(argv)
  const filePath = opts._[0]
  let text
  try {
    text = await readFile(filePath)
  } catch (e) {
    writeErr('Cannot read input file: ' + filePath)
    return 1
  }
  const ext = path.extname(filePath).toLowerCase()
  let rows
  try {
    rows = ext === '.csv' ? parseCSV(text) : parseJSON(text)
  } catch (e) {
    writeErr('Invalid input format: ' + e.message)
    return 1
  }

  if (opts.faculty) rows = rows.filter(byFaculty(opts.faculty))
  if (opts.newOnly) rows = rows.filter(filterNewMembers(opts.refDate))

  const total = rows.length
  const byFac = countBy(rows, r => (r.faculty ?? 'UNKNOWN'))
  const interests = topK(
    Object.entries(countBy(rows.flatMap(r => r.interests ?? []), x => x)).map(([k, v]) => ({ key: k, count: v })),
    opts.limit ?? 5,
    e => e.count
  )

  const report = { total, byFaculty: byFac, topInterests: interests }
  const out = (opts.format === 'json') ? toJSON(report) : formatTable(report)
  writeOut(out)
  return 0
}

function parseArgs (argv) {
  const out = { _: [], format: 'table', limit: 5, newOnly: false, faculty: null, refDate: new Date().toISOString().slice(0, 10) }
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i]
    if (a.startsWith('--')) {
      const [k, v] = a.split('=')
      switch (k) {
        case '--limit': out.limit = Number(v ?? argv[++i]); break
        case '--format': out.format = String(v ?? argv[++i]); break
        case '--faculty': out.faculty = String(v ?? argv[++i]); break
        case '--new-only': out.newOnly = true; break
        case '--ref-date': out.refDate = String(v ?? argv[++i]); break
      }
    } else {
      out._.push(a)
    }
  }
  return out
}
