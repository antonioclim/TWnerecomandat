import { generateSW } from 'workbox-build'
const { count, size, warnings } = await generateSW({
  globDirectory: 'public',
  globPatterns: ['**/*.{html,js,css,png,svg,ico,webmanifest}'],
  swDest: 'public/sw.js',
  clientsClaim: true,
  skipWaiting: true,
  runtimeCaching: [
    { urlPattern: ({request}) => request.destination === 'document', handler: 'NetworkFirst', options: { cacheName: 'pages' } },
    { urlPattern: ({request}) => ['style','script','worker'].includes(request.destination), handler: 'StaleWhileRevalidate', options: { cacheName: 'assets' } }
  ]
})
if (warnings.length) console.warn('Workbox warnings:', warnings)
console.log(`Generated sw.js with ${count} files (${size} bytes).`)
