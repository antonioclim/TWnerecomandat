import { describe, it, expect } from '@jest/globals'
import request from 'supertest'
import { createApp } from '../../src/app.js'
const app = createApp()

it('lint/unit matrix (smoke)', ()=>{ expect(1).toBe(1) })