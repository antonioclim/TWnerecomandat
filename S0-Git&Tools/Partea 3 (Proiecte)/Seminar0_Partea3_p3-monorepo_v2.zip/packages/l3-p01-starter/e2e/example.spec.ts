import { test, expect } from '@playwright/test'
test('home & ping', async ({ page }) => {
  await page.goto('/')
  await expect(page.locator('h1')).toHaveText(/StudentHub/i)
  const pong = await page.evaluate(async () => {
    const res = await fetch('/ping'); return res.ok && (await res.text())
  })
  expect(pong).toContain('pong')
})
