import { defineConfig } from '@playwright/test'
export default defineConfig({
  testDir: 'e2e',
  fullyParallel: false,
  retries: process.env.CI ? 2 : 0,
  use: { baseURL: 'http://localhost:3000' },
  webServer: { command: 'node src/index.js', port: 3000, reuseExistingServer: !process.env.CI }
})
