import { describe, it, expect } from '@jest/globals'
import request from 'supertest'
import { createApp } from '../../src/app.js'
const app = createApp()

it('error boundary exists (500)', async()=>{ const r=await request(app).get('/boom'); expect(r.status).toBe(500) })