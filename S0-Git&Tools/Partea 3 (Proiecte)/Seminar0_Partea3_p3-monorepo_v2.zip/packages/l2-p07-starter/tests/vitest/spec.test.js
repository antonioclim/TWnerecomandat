import { describe, it, expect } from 'vitest'
import request from 'supertest'
import { createApp } from '../../src/app.js'
const app = createApp()

it('register email', async()=>{ const ok=await request(app).post('/api/register').send({email:'a@b.com'}); expect(ok.status).toBe(200); const bad=await request(app).post('/api/register').send({email:'x'}); expect(bad.status).toBe(400) })