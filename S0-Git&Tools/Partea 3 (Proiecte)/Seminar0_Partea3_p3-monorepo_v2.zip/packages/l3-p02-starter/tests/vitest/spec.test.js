import { describe, it, expect } from 'vitest'
import request from 'supertest'
import { createApp } from '../../src/app.js'
const app = createApp()

it('e2e delegated to Playwright', ()=>{ expect(1).toBe(1) })