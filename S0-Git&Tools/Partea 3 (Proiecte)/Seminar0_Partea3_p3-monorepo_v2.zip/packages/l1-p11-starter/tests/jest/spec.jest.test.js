import { describe, it, expect } from '@jest/globals'
import request from 'supertest'
import { createApp } from '../../src/app.js'
const app = createApp()

it('X-Powered-By removed', async()=>{ const r=await request(app).get('/ping'); expect(r.headers['x-powered-by']).toBeUndefined() })