import { describe, it, expect } from 'vitest'
import request from 'supertest'
import { createApp } from '../../src/app.js'
const app = createApp()

it('env endpoint exists', async()=>{ const r=await request(app).get('/env'); expect(r.status).toBe(200) })