import { describe, it, expect } from '@jest/globals'
import request from 'supertest'
import { createApp } from '../../src/app.js'
const app = createApp()

it('ETag on /', async()=>{ const r=await request(app).get('/'); expect(r.headers.etag).toBeTruthy() })