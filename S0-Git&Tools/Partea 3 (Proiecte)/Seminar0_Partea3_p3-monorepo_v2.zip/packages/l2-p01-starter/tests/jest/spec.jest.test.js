import { describe, it, expect } from '@jest/globals'
import request from 'supertest'
import { createApp } from '../../src/app.js'
const app = createApp()

it('validateUser', async()=>{ const ok=await request(app).post('/api/validateUser').send({name:'Ana'}); expect(ok.status).toBe(200); const bad=await request(app).post('/api/validateUser').send({name:''}); expect(bad.status).toBe(400) })