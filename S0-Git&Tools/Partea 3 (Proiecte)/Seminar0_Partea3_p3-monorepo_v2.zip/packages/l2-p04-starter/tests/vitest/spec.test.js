import { describe, it, expect } from 'vitest'
import request from 'supertest'
import { createApp } from '../../src/app.js'
const app = createApp()

it('/api/v1/ping', async()=>{ const r=await request(app).get('/api/v1/ping'); expect(r.text).toContain('v1') })