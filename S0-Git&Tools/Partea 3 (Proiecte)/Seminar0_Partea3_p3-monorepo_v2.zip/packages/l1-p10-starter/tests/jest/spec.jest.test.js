import { describe, it, expect } from '@jest/globals'
import request from 'supertest'
import { createApp } from '../../src/app.js'
const app = createApp()

it('Cache-Control no-store', async()=>{ const r=await request(app).get('/api/time'); expect((r.headers['cache-control']||'').toLowerCase()).toContain('no-store') })