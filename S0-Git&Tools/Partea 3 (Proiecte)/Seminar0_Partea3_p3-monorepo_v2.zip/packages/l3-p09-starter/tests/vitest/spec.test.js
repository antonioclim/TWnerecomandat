import { describe, it, expect } from 'vitest'
import request from 'supertest'
import { createApp } from '../../src/app.js'
const app = createApp()

it('log header present', async()=>{ const r=await request(app).get('/ping'); expect(r.headers['x-request-id']).toBeTruthy() })