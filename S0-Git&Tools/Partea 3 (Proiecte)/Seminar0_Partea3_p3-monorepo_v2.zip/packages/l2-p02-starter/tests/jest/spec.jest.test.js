import { describe, it, expect } from '@jest/globals'
import request from 'supertest'
import { createApp } from '../../src/app.js'
const app = createApp()

it('/env reports NODE_ENV', async()=>{ const r=await request(app).get('/env'); expect(['development','test','production']).toContain(r.body.env) })