import { describe, it, expect } from '@jest/globals'
import request from 'supertest'
import { createApp } from '../../src/app.js'
const app = createApp()

it('POST /api/echo', async()=>{ const r=await request(app).post('/api/echo').send({a:1}); expect(r.status).toBe(200); expect(r.body.a).toBe(1) })