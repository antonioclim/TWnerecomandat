import { describe, it, expect } from '@jest/globals'
import request from 'supertest'
import { createApp } from '../../src/app.js'
const app = createApp()

it('CSP present', async()=>{ const r=await request(app).get('/'); expect(r.headers['content-security-policy']).toBeTruthy() })