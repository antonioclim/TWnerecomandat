import { describe, it, expect } from 'vitest'
import request from 'supertest'
import { createApp } from '../../src/app.js'
const app = createApp()

it('HEAD /api/time', async()=>{ const r=await request(app).head('/api/time'); expect([200,204]).toContain(r.status) })