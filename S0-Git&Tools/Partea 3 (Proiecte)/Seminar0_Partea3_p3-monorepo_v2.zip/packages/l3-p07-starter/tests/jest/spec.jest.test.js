import { describe, it, expect } from '@jest/globals'
import request from 'supertest'
import { createApp } from '../../src/app.js'
const app = createApp()

it('/metrics simulated (not implemented)', ()=>{ expect(true).toBe(true) })