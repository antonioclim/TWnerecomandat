import { describe, it, expect } from '@jest/globals'
import request from 'supertest'
import { createApp } from '../../src/app.js'
const app = createApp()

it('/readyz ready', async()=>{ const r=await request(app).get('/readyz'); expect(r.body.status).toBe('ready') })