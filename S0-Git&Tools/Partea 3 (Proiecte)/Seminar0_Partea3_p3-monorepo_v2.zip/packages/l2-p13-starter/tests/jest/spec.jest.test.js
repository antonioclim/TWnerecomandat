import { describe, it, expect } from '@jest/globals'
import request from 'supertest'
import { createApp } from '../../src/app.js'
const app = createApp()

it('rate limit simulated (placeholder)', ()=>{ expect(true).toBe(true) })