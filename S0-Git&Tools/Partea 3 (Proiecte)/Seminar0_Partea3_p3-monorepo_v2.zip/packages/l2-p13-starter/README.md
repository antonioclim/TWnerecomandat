# L2-P13 — P13 — Rate limit rudimentar (per proces)
**Nivel:** L2

## Learning goals
- Fixează conceptul: P13 — Rate limit rudimentar (per proces) într-un **server Express ESM**.
- Scrie **teste** (Vitest & Jest) pentru *contracte* (forma JSON, status, headere).
- Respectă separarea `createApp()` vs. `listen()` pentru testare ușoară.

## Cerințe
1. Rulează `npm test` în `starter/` — unele teste vor **pica** (TODO în `src/app.js`).
2. Completează implementarea până când toate testele devin **verzi**.
3. Compară cu `solution/` și notează diferențele.

## Rulare
```bash
npm i
npm test
npm run dev
```

## AI‑assist (VSL)
- „Implement **P13 — Rate limit rudimentar (per proces)** în `createApp()` (Express ESM). Scrie 3 teste edge-case.”
- „Adaugă un middleware pentru headere și validează-l cu un test.”
