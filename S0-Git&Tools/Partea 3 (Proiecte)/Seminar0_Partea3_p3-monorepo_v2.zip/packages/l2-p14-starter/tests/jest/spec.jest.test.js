import { describe, it, expect } from '@jest/globals'
import request from 'supertest'
import { createApp } from '../../src/app.js'
const app = createApp()

it('/api/json-type content-type', async()=>{ const r=await request(app).get('/api/time'); expect(r.headers['content-type']).toMatch(/json/) })