# L3-P10 — P10 — Graceful shutdown (SIGINT)
**Nivel:** L3

## Learning goals
- Fixează conceptul: P10 — Graceful shutdown (SIGINT) într-un **server Express ESM**.
- Scrie **teste** (Vitest & Jest) pentru *contracte* (forma JSON, status, headere).
- Respectă separarea `createApp()` vs. `listen()` pentru testare ușoară.

## Cerințe
1. Rulează `npm test` în `starter/` — unele teste vor **pica** (TODO în `src/app.js`).
2. Completează implementarea până când toate testele devin **verzi**.
3. Compară cu `solution/` și notează diferențele.

## Rulare
```bash
npm i
npm test
npm run dev
```

## AI‑assist (VSL)
- „Implement **P10 — Graceful shutdown (SIGINT)** în `createApp()` (Express ESM). Scrie 3 teste edge-case.”
- „Adaugă un middleware pentru headere și validează-l cu un test.”
