import { describe, it, expect } from '@jest/globals'
import request from 'supertest'
import { createApp } from '../../src/app.js'
const app = createApp()

it('graceful shutdown not tested here', ()=>{ expect(true).toBe(true) })