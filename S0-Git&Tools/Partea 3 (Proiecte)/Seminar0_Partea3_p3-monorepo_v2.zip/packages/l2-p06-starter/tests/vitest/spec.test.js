import { describe, it, expect } from 'vitest'
import request from 'supertest'
import { createApp } from '../../src/app.js'
const app = createApp()

it('/api/users/:id numeric', async()=>{ const ok=await request(app).get('/api/users/3'); expect(ok.status).toBe(200); const bad=await request(app).get('/api/users/abc'); expect(bad.status).toBe(400) })