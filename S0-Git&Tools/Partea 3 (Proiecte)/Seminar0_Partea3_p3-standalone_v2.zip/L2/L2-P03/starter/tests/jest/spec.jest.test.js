import { describe, it, expect } from '@jest/globals'
import request from 'supertest'
import { createApp } from '../../src/app.js'
const app = createApp()

it('/api/add', async()=>{ const r=await request(app).get('/api/add?a=1&b=2'); expect(r.body.sum).toBe(3) })