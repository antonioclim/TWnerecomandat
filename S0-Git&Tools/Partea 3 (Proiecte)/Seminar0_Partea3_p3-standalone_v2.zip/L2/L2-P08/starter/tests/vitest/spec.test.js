import { describe, it, expect } from 'vitest'
import request from 'supertest'
import { createApp } from '../../src/app.js'
const app = createApp()

it('sum values', async()=>{ const r=await request(app).post('/api/sum').send({values:[1,2,3]}); expect(r.body.sum).toBe(6) })