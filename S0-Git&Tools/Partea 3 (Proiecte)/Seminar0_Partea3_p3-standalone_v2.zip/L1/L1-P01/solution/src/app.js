import express from 'express'
import path from 'path'
import { fileURLToPath } from 'url'
import crypto from 'crypto'

export function createApp(){
  const app = express()
  app.disable('x-powered-by')
  const __filename = fileURLToPath(import.meta.url); const __dirname = path.dirname(__filename)

  // Security & request id
  app.use((req,res,next)=>{ res.set('X-Content-Type-Options','nosniff'); res.set('X-Request-Id', crypto.randomBytes(8).toString('hex')); next() })

  // JSON & static
  app.use(express.json())
  app.use(express.static(path.join(__dirname,'../public')))

  // Basic routes
  app.get('/ping', (req,res)=> res.send('pong'))
  app.head('/ping', (req,res)=> res.status(200).end())
  app.get('/api/time', (req,res)=> { res.set('Cache-Control','no-store'); res.json({ now: new Date().toISOString() }) })
  app.get('/api/hello', (req,res)=> res.send(`Hello, ${req.query.name||'World'}`))
  app.post('/api/echo', (req,res)=> res.json(req.body||{}))

  // CORS for /api/time
  app.use('/api/time', (req,res,next)=>{ res.set('Access-Control-Allow-Origin','*'); next() })

  // v1 router
  const v1 = express.Router()
  v1.get('/ping', (req,res)=> res.send('v1 pong'))
  app.use('/api/v1', v1)

  // Users id route
  app.get('/api/users/:id', (req,res)=> {
    const id = Number(req.params.id)
    if (!Number.isInteger(id) || id <= 0) return res.status(400).json({ error:'invalid id' })
    res.json({ id })
  })

  // Validations
  app.post('/api/validateUser', (req,res)=>{
    const { name } = req.body||{}
    if (typeof name !== 'string' || name.trim().length===0) return res.status(400).json({ error:'invalid name' })
    res.json({ ok:true })
  })
  app.post('/api/register', (req,res)=>{
    const { email } = req.body||{}
    const ok = typeof email==='string' && /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)
    if(!ok) return res.status(400).json({ error:'invalid email' })
    res.json({ ok:true })
  })
  app.post('/api/sum', (req,res)=>{
    const values = (req.body && Array.isArray(req.body.values)) ? req.body.values : null
    if(!values || !values.every(n=> typeof n==='number')) return res.status(400).json({ error:'invalid values' })
    const sum = values.reduce((a,b)=>a+b,0)
    res.json({ sum })
  })
  app.get('/api/add', (req,res)=>{
    const a = Number(req.query.a), b = Number(req.query.b)
    if(Number.isNaN(a)||Number.isNaN(b)) return res.status(400).json({ error:'invalid params' })
    res.json({ sum: a+b })
  })

  // Env & status
  app.get('/env', (req,res)=> res.json({ env: process.env.NODE_ENV || 'development' }))
  app.get('/api/status', (req,res)=>{
    const s = req.query.code ? Number(req.query.code) : 200
    res.status(!Number.isNaN(s)?s:200).json({ status: s })
  })

  // Health
  app.get('/healthz', (req,res)=> res.json({ status:'ok' }))
  app.get('/readyz', (req,res)=> res.json({ status:'ready' }))

  // Error route
  app.get('/boom', (req,res)=> { throw new Error('boom') })

  // CSP minimal
  app.use((req,res,next)=>{ res.set('Content-Security-Policy', "default-src 'self'; style-src 'self' 'unsafe-inline'"); next() })

  app.use((req,res)=> res.status(404).json({ error:'Not Found' }))
  app.use((err,req,res,next)=>{ console.error(err); res.status(500).json({ error:'Internal Error' }) })

  return app
}
