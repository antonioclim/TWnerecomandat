import { describe, it, expect } from '@jest/globals'
import request from 'supertest'
import { createApp } from '../../src/app.js'
const app = createApp()

it('GET /api/hello?name', async()=>{ const r=await request(app).get('/api/hello?name=Ana'); expect(r.text).toContain('Ana') })