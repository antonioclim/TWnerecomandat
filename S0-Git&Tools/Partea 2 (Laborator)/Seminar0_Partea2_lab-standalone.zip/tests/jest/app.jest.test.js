import { describe, it, expect } from '@jest/globals'
import request from 'supertest'
import { createApp } from '../../src/app.js'

const app = createApp()

describe('Seminar 0 — Express minimal (Vitest)', () => {
  it('GET /ping -> pong', async () => {
    const res = await request(app).get('/ping')
    expect(res.status).toBe(200)
    expect(res.text).toBe('pong')
  })

  it('GET /api/time -> { now: ISO }', async () => {
    const res = await request(app).get('/api/time')
    expect(res.status).toBe(200)
    expect(typeof res.body.now).toBe('string')
    expect(Number.isNaN(Date.parse(res.body.now))).toBe(false)
  })

  it('GET / -> serves index.html', async () => {
    const res = await request(app).get('/')
    expect(res.status).toBe(200)
    expect(res.text).toContain('<h1>StudentHub Minisite</h1>')
  })
})
