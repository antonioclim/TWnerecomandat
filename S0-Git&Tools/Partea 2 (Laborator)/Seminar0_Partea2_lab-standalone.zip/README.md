# Seminar 0 — Laborator (Standalone)

## Obiectiv
Inițializează un proiect Node (ESM), pornește un server Express minimal, servește `public/index.html`, expune rutele:
- `GET /ping` -> `pong`
- `GET /api/time` -> `{ now: ISO-8601 }`

Rulare teste **Vitest** & **Jest** (aceleași aserții, side-by-side).

## Pași rapizi
```bash
npm i
npm test           # rulează vitest + jest
npm run dev        # server cu nodemon
# sau:
npm start          # server fără watch
```
