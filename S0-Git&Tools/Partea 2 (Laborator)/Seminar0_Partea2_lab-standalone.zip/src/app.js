import express from 'express'
import path from 'path'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

export function createApp() {
  const app = express()
  app.use(express.json())
  app.use(express.static(path.join(__dirname, '../public')))

  app.get('/ping', (req, res) => res.send('pong'))
  app.get('/api/time', (req, res) => res.json({ now: new Date().toISOString() }))

  app.use((req, res) => res.status(404).json({ error: 'Not Found' }))
  app.use((err, req, res, next) => {  // eslint-disable-line no-unused-vars
    console.error(err)
    res.status(500).json({ error: 'Internal Error' })
  })

  return app
}
