import { configureStore } from '@reduxjs/toolkit'
import clubsReducer from '../features/clubs/clubsSlice'
export const store = configureStore({ reducer:{ clubs: clubsReducer }, devTools:true })
export type RootState = ReturnType<typeof store.getState>
export type AppDispatch = typeof store.dispatch
