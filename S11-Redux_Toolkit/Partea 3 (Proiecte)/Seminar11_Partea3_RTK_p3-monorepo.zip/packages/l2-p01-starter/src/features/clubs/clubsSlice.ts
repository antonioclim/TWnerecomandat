import { createSlice, createEntityAdapter, createSelector, createAsyncThunk } from '@reduxjs/toolkit'
import type { RootState } from '../../app/store'

export type Club = { id: string; name: string; category: string }

// TODO: implement real fetch; starter returns empty list -> test should fail until fixed
export const fetchClubs = createAsyncThunk<Club[]>('clubs/fetchClubs', async () => {
  return [] as Club[]
})

const adapter = createEntityAdapter<Club>({ sortComparer: (a,b)=>a.name.localeCompare(b.name) })
const initial = adapter.getInitialState({ status:'idle' as 'idle'|'loading'|'succeeded'|'failed', error:null as string|null, query:'', category:'all' as 'all'|'technology'|'arts'|'sports' })

const slice = createSlice({
  name: 'clubs',
  initialState: initial,
  reducers: { upsertMany: adapter.upsertMany, removeOne: adapter.removeOne, setQuery(state,a:{payload:string}){state.query=a.payload}, setCategory(state,a:{payload:'all'|'technology'|'arts'|'sports'}){state.category=a.payload} },
  extraReducers: (b)=>{
    b.addCase(fetchClubs.pending, (s)=>{ s.status='loading'; s.error=null })
     .addCase(fetchClubs.fulfilled, (s, a)=>{ s.status='succeeded'; adapter.setAll(s, a.payload) })
     .addCase(fetchClubs.rejected, (s, a)=>{ s.status='failed'; s.error=String(a.error.message||'error') })
  }
})
export default slice.reducer
export const { upsertMany, removeOne, setQuery, setCategory } = slice.actions

export const clubsSelectors = adapter.getSelectors<RootState>(s=>s.clubs)
export const selectQuery = (s:RootState)=>s.clubs.query
export const selectCategory = (s:RootState)=>s.clubs.category
export const selectStatus = (s:RootState)=>s.clubs.status
export const selectError = (s:RootState)=>s.clubs.error

export const selectVisibleClubs = createSelector([clubsSelectors.selectAll, selectQuery, selectCategory], (list,q,cat)=> list)
