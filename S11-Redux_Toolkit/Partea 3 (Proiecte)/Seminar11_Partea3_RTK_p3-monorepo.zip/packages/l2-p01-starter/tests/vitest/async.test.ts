import { configureStore } from '@reduxjs/toolkit'
import reducer, { fetchClubs } from '../../src/features/clubs/clubsSlice'
import { http, HttpResponse } from 'msw'
import { setupServer } from 'msw/node'

const server = setupServer(
  http.get('/api/clubs', () => HttpResponse.json([{ id:'t', name:'Tech & Coding', category:'technology' }]))
)

beforeAll(()=>server.listen())
afterEach(()=>server.resetHandlers())
afterAll(()=>server.close())

test('fetchClubs populates entities', async () => {
  const store = configureStore({ reducer: { clubs: reducer } })
  // @ts-ignore
  await store.dispatch(fetchClubs())
  const state = store.getState().clubs as any
  expect(state.status).toBe('succeeded')
  expect(Object.keys(state.entities).length).toBeGreaterThan(0)
})
