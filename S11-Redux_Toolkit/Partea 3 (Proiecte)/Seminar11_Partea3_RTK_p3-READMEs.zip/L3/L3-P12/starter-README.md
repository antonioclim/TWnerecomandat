# L3-P12 — Non‑serializable guard & serialization

**Nivel:** L3  
**Tema:** Non‑serializable guard & serialization — implementați comportamentul esențial folosind Redux Toolkit 2.x (TypeScript) și treceți testele Vitest & Jest.

## Learning goals
- Consolidarea principiilor RTK pe nivelul curent.
- Exersarea tipării stricte (TS) și a testării duale (Vitest/Jest).
- Aplicarea bunelor practici (entityAdapter, selectors, thunks/Query).

## Cerințe
1. Rulează testele (`npm test`). Observă ce eșuează în *starter*.
2. Completează logica din `src/features/clubs/clubsSlice.ts` conform temei.
3. Asigură-te că testele Vitest & Jest devin verzi.

## AI‑assist (VSL) — prompts
- „Create a Redux Toolkit slice with `createEntityAdapter` for {id,name,category} and implement filtered selector `selectVisibleClubs`.”
- „Write a `createAsyncThunk` `fetchClubs` and connect it via `extraReducers` (status + entities).”
- „Add an RTK Query `createApi` service and export hooks.”

## Pași
```bash
npm i
npm test
npm run dev
```
