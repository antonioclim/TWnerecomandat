import reducer, { upsertMany, setQuery, setCategory, selectVisibleClubs } from '../../src/features/clubs/clubsSlice'
import type { RootState } from '../../src/app/store'

function rs(state:any): RootState { return { clubs: state } as any }

test('filter should find Robotics when query=robo and category=all', () => {
  let state = reducer(undefined, upsertMany([{ id:'r', name:'Robotics', category:'technology' }, { id:'a', name:'Arts', category:'arts' }]))
  // @ts-ignore
  state = reducer(state, setQuery('robo'))
  // @ts-ignore
  state = reducer(state, setCategory('all'))
  const visible = selectVisibleClubs(rs(state))
  expect(visible.find(x=>x.id==='r')).toBeTruthy()
})
