export default function App(){ return (<main><h1 data-testid='title'>TODO: Project Title</h1><p>Starter UI placeholder.</p></main>) }
