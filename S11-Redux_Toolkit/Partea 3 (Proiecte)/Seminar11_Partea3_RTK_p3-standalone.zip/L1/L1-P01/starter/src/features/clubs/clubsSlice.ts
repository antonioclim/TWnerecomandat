import { createSlice, createEntityAdapter, createSelector } from '@reduxjs/toolkit'
import type { RootState } from '../../app/store'

export type Club = { id: string; name: string; category: string }
const adapter = createEntityAdapter<Club>({ sortComparer: (a,b)=>a.name.localeCompare(b.name) })

const initial = adapter.getInitialState({ query:'', category:'all' as 'all'|'technology'|'arts'|'sports' })

const slice = createSlice({
  name: 'clubs',
  initialState: initial,
  reducers: {
    upsertMany: adapter.upsertMany,
    removeOne: adapter.removeOne,
    setQuery(state, action:{payload:string}){ state.query = action.payload },
    setCategory(state, action:{payload:'all'|'technology'|'arts'|'sports'}){ state.category = action.payload }
  }
})
export default slice.reducer
export const { upsertMany, removeOne, setQuery, setCategory } = slice.actions

// selectors
export const clubsSelectors = adapter.getSelectors<RootState>(s=>s.clubs)
export const selectQuery = (s:RootState)=>s.clubs.query
export const selectCategory = (s:RootState)=>s.clubs.category

// TODO: implement filter logic (starter returns unfiltered list)
export const selectVisibleClubs = createSelector([clubsSelectors.selectAll], (list)=> list)
