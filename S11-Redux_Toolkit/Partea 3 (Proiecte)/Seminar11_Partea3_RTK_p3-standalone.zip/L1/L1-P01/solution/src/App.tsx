export default function App(){ return (<main><h1 data-testid='title'>Project Ready</h1><p>Solution UI placeholder.</p></main>) }
