import reducer, { upsertMany, selectVisibleClubs } from '../../src/features/clubs/clubsSlice'
import type { RootState } from '../../src/app/store'

function rs(state:any): RootState { return { clubs: state, clubsApi: { queries:{}, mutations:{}, provided:{}, subscriptions:{}, config:{reducerPath:'clubsApi'} } as any } as any }

test('selectVisibleClubs filters by query', () => {
  let s = reducer(undefined, upsertMany([{ id:'t', name:'Tech', category:'technology' },{ id:'a', name:'Arts', category:'arts' }]))
  const r = selectVisibleClubs(rs(s))
  expect(r.length).toBe(2)
})
