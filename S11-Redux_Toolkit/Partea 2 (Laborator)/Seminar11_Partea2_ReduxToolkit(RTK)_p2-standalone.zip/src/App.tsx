import React, { useEffect, useState, startTransition } from 'react'
import { Header } from './components/Header'
import { Footer } from './components/Footer'
import { SearchBox } from './components/SearchBox'
import { CategoryFilter } from './components/CategoryFilter'
import { AddClubForm } from './components/AddClubForm'
import { ClubList } from './components/ClubList'
import { useAppDispatch, useAppSelector } from './app/hooks'
import { setQuery, setCategory, selectVisibleClubs, upsertMany, fetchClubs, selectStatus, selectError } from './features/clubs/clubsSlice'

export default function App(){
  const dispatch = useAppDispatch()
  const items = useAppSelector(selectVisibleClubs)
  const status = useAppSelector(selectStatus)
  const error = useAppSelector(selectError)
  const [q, setQ] = useState('')
  const [cat, setCat] = useState<'all'|'technology'|'arts'|'sports'>('all')

  useEffect(()=>{ dispatch(setQuery(q)) }, [q, dispatch])
  useEffect(()=>{ dispatch(setCategory(cat)) }, [cat, dispatch])

  function addClub(input: { name: string; category: 'technology'|'arts'|'sports' }){
    const id = input.name.toLowerCase().replace(/\s+/g,'-')
    dispatch(upsertMany([{ id, ...input }]))
  }

  return (
    <main className="container">
      <Header title="ClubHub+ State — Redux Toolkit Lab" />
      <div className="card">
        <SearchBox value={q} onChange={(v)=>startTransition(()=>setQ(v))} />
        <CategoryFilter value={cat} onChange={setCat} />
        <button onClick={()=>dispatch(fetchClubs())} aria-label="load-btn">Load Clubs</button>
      </div>
      {status==='loading' && <p role="status">Loading…</p>}
      {status==='failed' && <p role="alert">Error: {error}</p>}
      <AddClubForm onAdd={addClub} />
      <ClubList items={items} />
      <Footer>RTK + React + TS + Vitest/Jest</Footer>
    </main>
  )
}
