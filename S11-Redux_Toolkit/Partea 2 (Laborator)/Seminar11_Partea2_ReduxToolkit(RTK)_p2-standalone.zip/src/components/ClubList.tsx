import { Club } from '../features/clubs/clubsSlice'
import { ClubCard } from './ClubCard'
export function ClubList({ items }: { items: Club[] }){
  if(items.length===0) return <p role="status">No clubs found.</p>
  return <section className="grid" aria-label="club-list">{items.map(c=><ClubCard key={c.id} club={c} />)}</section>
}