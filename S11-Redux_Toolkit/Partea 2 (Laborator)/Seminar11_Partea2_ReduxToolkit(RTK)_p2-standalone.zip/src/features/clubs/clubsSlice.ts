import { createSlice, createEntityAdapter, createAsyncThunk, createSelector } from '@reduxjs/toolkit'
import type { RootState } from '../../app/store'

export type Club = { id: string; name: string; category: string }

export const fetchClubs = createAsyncThunk<Club[]>('clubs/fetchClubs', async () => {
  const res = await fetch('/api/clubs')
  if(!res.ok) throw new Error('Network error')
  return await res.json() as Club[]
})

const clubsAdapter = createEntityAdapter<Club>({
  sortComparer: (a, b) => a.name.localeCompare(b.name)
})

const initial = clubsAdapter.getInitialState({
  status: 'idle' as 'idle'|'loading'|'succeeded'|'failed',
  error: null as string|null,
  query: '',
  category: 'all' as 'all'|'technology'|'arts'|'sports'
})

const clubsSlice = createSlice({
  name: 'clubs',
  initialState: initial,
  reducers: {
    setQuery(state, action: { payload: string }) { state.query = action.payload },
    setCategory(state, action: { payload: 'all'|'technology'|'arts'|'sports' }) { state.category = action.payload },
    upsertMany: clubsAdapter.upsertMany,
    removeOne: clubsAdapter.removeOne,
  },
  extraReducers: builder => {
    builder
      .addCase(fetchClubs.pending, (state) => { state.status = 'loading'; state.error = null })
      .addCase(fetchClubs.fulfilled, (state, action) => {
        state.status = 'succeeded'
        clubsAdapter.setAll(state, action.payload)
      })
      .addCase(fetchClubs.rejected, (state, action) => {
        state.status = 'failed'
        state.error = String(action.error.message || 'error')
      })
  }
})

export const { setQuery, setCategory, upsertMany, removeOne } = clubsSlice.actions
export default clubsSlice.reducer

// selectors
const base = (s: RootState) => s.clubs
export const clubsSelectors = clubsAdapter.getSelectors<RootState>((s) => s.clubs)
export const selectQuery = (s: RootState) => base(s).query
export const selectCategory = (s: RootState) => base(s).category
export const selectStatus = (s: RootState) => base(s).status
export const selectError = (s: RootState) => base(s).error

export const selectVisibleClubs = createSelector(
  [clubsSelectors.selectAll, selectQuery, selectCategory],
  (list, q, cat) => {
    const query = q.trim().toLowerCase()
    return list.filter(c => {
      const okQ = !query || c.name.toLowerCase().includes(query) || c.category.toLowerCase().includes(query)
      const okC = cat === 'all' || c.category === cat
      return okQ && okC
    })
  }
)
