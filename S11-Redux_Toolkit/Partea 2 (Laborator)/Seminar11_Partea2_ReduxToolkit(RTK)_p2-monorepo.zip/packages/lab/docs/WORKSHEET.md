# Worksheet — Seminar 11 / Partea 2 (Laborator RTK)
Tema: ClubHub+ State — gestionarea stării cu Redux Toolkit

## Etape & cerințe
0) Setup: Vite + TS + React + RTK; Vitest & Jest; MSW.
1) Slice `clubs` cu entityAdapter: CRUD minim, selectori auto-gen.
2) Integrare UI: Search controlat, Category filter, Add form (dispatch).
3) Selectori memoizați (Reselect): `selectVisibleClubs`.
4) Async: `fetchClubs` cu `createAsyncThunk`; spinner + error.
5) Middleware persistență (opțional): subarbore `clubs` în localStorage.
6) RTK Query (opțional): `getClubs`, `addClub` (invalidări).
7) Refactor & A11y pass; teste verzi (Vitest + Jest).

## Checklist minimal
- [ ] Rulează dev serverul și apare headerul.
- [ ] Adaugi un club și îl vezi în listă.
- [ ] Căutarea filtrează în timp real (controlled input).
- [ ] `Load` aduce datele prin thunk, apare „Tech & Coding”.
- [ ] Testele reducere/selectori/thunk/App trec în Vitest și Jest.
