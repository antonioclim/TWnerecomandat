# Seminarul 11 — Partea 2: Redux Toolkit Lab

## Rulare
```bash
npm i
npm test              # Vitest + Jest (side-by-side)
npm run dev           # http://localhost:5173
```

## Ce conține
- Redux Toolkit 2 + React 19 + TypeScript
- React-Redux, Reselect, MSW pentru API mock
- Slice `clubs` cu `createEntityAdapter`, `createAsyncThunk`, selectori memoizați
- UI integrat: Search, Category, Add form, Load via thunk
- Teste Vitest & Jest: reducer, selectors, thunk, App (RTL)
