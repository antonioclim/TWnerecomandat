import { configureStore } from '@reduxjs/toolkit'
import clubsReducer from '../features/clubs/clubsSlice'
import { clubsApi } from '../services/clubsApi'

export const store = configureStore({
  reducer: {
    clubs: clubsReducer,
    [clubsApi.reducerPath]: clubsApi.reducer,
  },
  middleware: (getDefault) => getDefault().concat(clubsApi.middleware),
  devTools: true
})

export type RootState = ReturnType<typeof store.getState>
export type AppDispatch = typeof store.dispatch
