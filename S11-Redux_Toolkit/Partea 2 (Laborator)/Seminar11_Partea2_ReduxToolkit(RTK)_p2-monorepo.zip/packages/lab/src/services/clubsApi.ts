import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react'
import type { Club } from '../features/clubs/clubsSlice'

export const clubsApi = createApi({
  reducerPath: 'clubsApi',
  baseQuery: fetchBaseQuery({ baseUrl: '/api' }),
  tagTypes: ['Clubs'],
  endpoints: builder => ({
    getClubs: builder.query<Club[], void>({
      query: () => '/clubs',
      providesTags: (result) => result
        ? [...result.map(({ id }) => ({ type: 'Clubs' as const, id })), { type: 'Clubs', id: 'LIST' }]
        : [{ type: 'Clubs', id: 'LIST' }]
    }),
    addClub: builder.mutation<Club, Partial<Club>>({
      query: (body) => ({ url: '/clubs', method: 'POST', body }),
      invalidatesTags: [{ type: 'Clubs', id: 'LIST' }]
    })
  })
})

export const { useGetClubsQuery, useAddClubMutation } = clubsApi
