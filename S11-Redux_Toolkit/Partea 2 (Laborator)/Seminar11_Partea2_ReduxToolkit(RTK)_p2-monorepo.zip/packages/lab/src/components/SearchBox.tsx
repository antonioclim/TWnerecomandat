type Props = { value: string; onChange: (v:string)=>void; placeholder?: string }
export function SearchBox({ value, onChange, placeholder }: Props){
  return (
    <label aria-label="search">
      <span>Search:</span>
      <input aria-label="search-input" value={value} placeholder={placeholder||'Search...'} onChange={e=>onChange(e.target.value)} />
    </label>
  )
}