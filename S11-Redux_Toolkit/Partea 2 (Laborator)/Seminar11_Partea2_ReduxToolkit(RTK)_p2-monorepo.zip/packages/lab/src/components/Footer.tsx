import { ReactNode } from 'react'
export function Footer({ children }: { children: ReactNode }){
  return <footer>&copy; {new Date().getFullYear()} · {children}</footer>
}