type Props = { value: 'all'|'technology'|'arts'|'sports'; onChange: (v:any)=>void }
export function CategoryFilter({ value, onChange }: Props){
  return (
    <label aria-label="category">
      <span>Category:</span>
      <select aria-label="category-select" value={value} onChange={e=>onChange(e.target.value)}>
        <option value="all">all</option>
        <option value="technology">technology</option>
        <option value="arts">arts</option>
        <option value="sports">sports</option>
      </select>
    </label>
  )
}