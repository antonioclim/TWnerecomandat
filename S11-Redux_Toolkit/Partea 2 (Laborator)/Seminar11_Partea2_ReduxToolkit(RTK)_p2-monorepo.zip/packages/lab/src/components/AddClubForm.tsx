import { useState } from 'react'
import type { Club } from '../features/clubs/clubsSlice'

export function AddClubForm({ onAdd }: { onAdd: (c: Omit<Club,'id'>)=>void }){
  const [name,setName] = useState('')
  const [category,setCategory] = useState<'technology'|'arts'|'sports'>('technology')
  function submit(e: React.FormEvent){ e.preventDefault(); if(!name.trim()) return; onAdd({ name: name.trim(), category }); setName('') }
  return (
    <form onSubmit={submit} aria-label="add-club-form" className="card">
      <label><span>Name</span><input aria-label="name-input" value={name} onChange={e=>setName(e.target.value)} /></label>
      <label><span>Category</span><select aria-label="category-select" value={category} onChange={e=>setCategory(e.target.value as any)}>
        <option value="technology">technology</option><option value="arts">arts</option><option value="sports">sports</option>
      </select></label>
      <button type="submit">Add</button>
    </form>
  )
}