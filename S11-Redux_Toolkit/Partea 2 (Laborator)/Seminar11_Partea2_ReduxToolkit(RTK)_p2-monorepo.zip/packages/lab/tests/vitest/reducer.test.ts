import reducer, { upsertMany, removeOne, setQuery, setCategory } from '../../src/features/clubs/clubsSlice'

test('upsertMany and removeOne', () => {
  const state = reducer(undefined, upsertMany([{ id:'a', name:'Alpha', category:'arts' }]))
  // @ts-ignore access entity state shape
  expect(state.entities['a']?.name).toBe('Alpha')
  const st2 = reducer(state, removeOne('a'))
  // @ts-ignore
  expect(st2.entities['a']).toBeUndefined()
})

test('setQuery and setCategory', () => {
  let state = reducer(undefined, setQuery('tech'))
  // @ts-ignore
  expect(state.query).toBe('tech')
  state = reducer(state, setCategory('technology'))
  // @ts-ignore
  expect(state.category).toBe('technology')
})
