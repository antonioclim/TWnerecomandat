import { fetchClubs } from '../../src/features/clubs/clubsSlice'
import { configureStore } from '@reduxjs/toolkit'
import clubsReducer from '../../src/features/clubs/clubsSlice'

test('fetchClubs fulfills and sets items', async () => {
  const store = configureStore({ reducer: { clubs: clubsReducer } })
  await store.dispatch<any>(fetchClubs())
  const state = store.getState().clubs as any
  expect(state.status).toBe('succeeded')
  expect(Object.keys(state.entities).length).toBeGreaterThan(0)
})
