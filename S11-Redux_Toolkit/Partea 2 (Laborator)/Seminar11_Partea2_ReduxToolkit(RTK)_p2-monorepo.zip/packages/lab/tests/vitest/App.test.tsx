import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { Provider } from 'react-redux'
import { configureStore } from '@reduxjs/toolkit'
import clubsReducer from '../../src/features/clubs/clubsSlice'
import App from '../../src/App'

function setup(){
  const store = configureStore({ reducer: { clubs: clubsReducer } })
  render(<Provider store={store}><App/></Provider>)
  return { store }
}

test('adds a club and filters', async () => {
  setup()
  const user = userEvent.setup()
  await user.type(screen.getByLabelText('name-input'), 'Robotics')
  await user.click(screen.getByRole('button', { name: /add/i }))
  expect(screen.getByText(/Robotics/i)).toBeInTheDocument()
  await user.type(screen.getByLabelText('search-input'), 'robo')
  expect(screen.getAllByLabelText('club-card').length).toBe(1)
})

test('loads clubs via thunk', async () => {
  setup()
  const user = userEvent.setup()
  await user.click(screen.getByLabelText('load-btn'))
  expect(await screen.findByText(/Tech & Coding/i)).toBeInTheDocument()
})
