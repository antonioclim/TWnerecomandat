import { http, HttpResponse } from 'msw'

export const handlers = [
  http.get('/api/clubs', async () => {
    return HttpResponse.json([
      { id: 'tech', name: 'Tech & Coding', category: 'technology' },
      { id: 'arts', name: 'Arts & Culture', category: 'arts' },
      { id: 'sport', name: 'Sports Club', category: 'sports' }
    ])
  }),
]
