import { describe, it, expect } from 'vitest';
import fs from 'node:fs'; import path from 'node:path';
const root = path.resolve(__dirname, '..','..');
const read = f => fs.readFileSync(path.join(root, f), 'utf8');
const cfg = JSON.parse(read('tests/config.json'));
const js = read('src/api/fetchClient.js') + '\n' + read('src/forms/validation.js') + '\n' + read('src/utils/storage.js') + '\n' + read('src/pages/clubsPage.js') + '\n' + read('src/pages/enrolPage.js') + '\n' + read('src/addons/advanced.js');
const html = read('public/index.html');

describe('Project patterns', () => {
  it('html contains required fragments', () => {
    (cfg.htmlAllOf || []).forEach(p => expect(html).toMatch(new RegExp(p)));
  });
  it('js contains all required patterns', () => {
    (cfg.jsAllOf || []).forEach(p => expect(js).toMatch(new RegExp(p)));
  });
  it('js contains at least one any-of pattern', () => {
    const any = cfg.jsAnyOf || []; if(any.length===0){ expect(true).toBe(true); return; }
    const ok = any.some(p => new RegExp(p).test(js)); expect(ok).toBe(true);
  });
});