import { getClubsCached } from '../services/clubs.js';

const list = document.querySelector('#clubs');
const statusEl = document.querySelector('#status');
const reloadBtn = document.querySelector('#reload');
const clearBtn = document.querySelector('#clear-cache');

function renderClubs(clubs){
  if(!list) return;
  list.innerHTML = '';
  for(const c of clubs){
    const li = document.createElement('li');
    li.textContent = `${c.name} — ${c.category}`;
    list.appendChild(li);
  }
}

async function load(){
  if(!statusEl) return;
  statusEl.textContent = 'Loading…';
  try{
    const clubs = await getClubsCached();
    renderClubs(clubs);
    statusEl.textContent = `Loaded ${clubs.length} clubs.`;
  }catch(err){
    console.error(err);
    statusEl.textContent = 'Network/server error. Try again.';
  }
}

reloadBtn?.addEventListener('click', load);
clearBtn?.addEventListener('click', () => { localStorage.clear(); statusEl.textContent = 'Cache cleared.'; });
load();