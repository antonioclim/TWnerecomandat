import { getClubsCached } from '../services/clubs.js';
import { attachEnrolForm } from '../forms/enrolController.js';

const form = document.querySelector('#enrol');
const select = document.querySelector('#club');

async function populateClubs(){
  if(!select) return;
  try{
    const clubs = await getClubsCached();
    select.innerHTML = '<option value="">— alege —</option>' + clubs.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
  }catch{ select.innerHTML = '<option value="">(eroare încărcare)</option>'; }
}

if(form){ attachEnrolForm(form); populateClubs(); }