import { formToJSON } from './validation.js';
import { jsonPost } from '../api/fetchClient.js';
import { saveDraft, restoreDraft, clearDraft } from '../utils/storage.js';

export function updateUI(form, state){
  const submitBtn = form.querySelector('#submit');
  const statusEl = form.querySelector('#form-status');
  if(state.status === 'submitting'){
    submitBtn.disabled = true; statusEl.textContent = 'Se trimite…';
  }else if(state.status === 'success'){
    submitBtn.disabled = false; statusEl.textContent = 'Înscriere trimisă cu succes.';
  }else if(state.status === 'error'){
    submitBtn.disabled = false; statusEl.textContent = (state.problem?.title) || 'Eroare de rețea/server.';
  }else{
    submitBtn.disabled = false; statusEl.textContent = '';
  }
}

export function attachEnrolForm(form){
  restoreDraft(form);
  form.addEventListener('input', () => saveDraft(form));
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const v = formToJSON(form);
    if(!v.ok){
      const first = Object.keys(v.errors)[0];
      const el = form.elements.namedItem(first);
      if(el && el.focus) el.focus();
      updateUI(form, { status: 'error', problem: { title: Object.values(v.errors).join(' ') } });
      return;
    }
    updateUI(form, { status: 'submitting' });
    try{
      const res = await jsonPost('/api/registrations', v.data, { timeoutMs: 8000, retries: 2 });
      updateUI(form, { status: 'success' });
      clearDraft();
      form.reset();
    }catch(err){
      updateUI(form, { status: 'error', problem: { title: err?.payload?.title || err?.message || 'Eroare' } });
    }
  });
}