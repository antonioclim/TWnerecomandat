export function validateEnrol(data){
  const errors = {};
  const fullName = (data.fullName||'').trim();
  const email = (data.email||'').trim();
  const club = (data.club||'').trim();
  const consent = !!(data.consent === true || data.consent === 'on' || data.consent === 'true');
  if(fullName.length < 3) errors.fullName = 'Numele trebuie să aibă cel puțin 3 caractere.';
  if(!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) errors.email = 'Email invalid.';
  if(!club) errors.club = 'Alege un club.';
  if(!consent) errors.consent = 'Este necesar consimțământul.';
  return { ok: Object.keys(errors).length===0, data: { fullName, email, club, consent }, errors };
}

export function formToJSON(form){
  const fd = new FormData(form);
  const raw = Object.fromEntries(fd.entries());
  if(!('consent' in raw)) raw.consent = false;
  return validateEnrol(raw);
}