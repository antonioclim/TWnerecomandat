import { jsonGet } from '../api/fetchClient.js';
import { lsGet, lsSet } from '../utils/storage.js';

const TTL = 5 * 60 * 1000;

export async function getClubsCached(){
  const cached = lsGet('clubs');
  if(cached){ setTimeout(()=> refreshClubs(), 0); return cached; }
  return refreshClubs();
}

export async function refreshClubs(){
  const data = await jsonGet('/api/clubs');
  lsSet('clubs', data, TTL);
  return data;
}