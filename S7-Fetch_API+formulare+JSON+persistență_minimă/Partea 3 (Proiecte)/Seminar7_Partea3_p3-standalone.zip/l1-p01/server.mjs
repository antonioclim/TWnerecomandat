import express from 'express';
import cors from 'cors';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url); const __dirname = path.dirname(__filename);
const app = express(); const PORT = process.env.PORT || 5370;

app.use(cors());
app.use(express.json());
app.use('/public', express.static(path.join(__dirname, 'public')));

const clubs = JSON.parse(fs.readFileSync(path.join(__dirname, 'tests/fixtures/clubs.json'), 'utf8'));

app.get('/api/clubs', (_req, res) => setTimeout(()=> res.json(clubs), 150));

app.post('/api/registrations', (req, res) => {
  const { fullName, email, club, consent } = req.body || {};
  if(!fullName || fullName.length < 3) return res.status(422).json({ title: 'Invalid name' });
  if(!email || !/[^@\s]+@[^@\s]+\.[^@\s]+/.test(email)) return res.status(422).json({ title: 'Invalid email' });
  if(!club) return res.status(422).json({ title: 'Club required' });
  if(!consent) return res.status(422).json({ title: 'Consent required' });
  return res.status(201).json({ id: Math.random().toString(36).slice(2), fullName, email, club, createdAt: new Date().toISOString() });
});

app.get('/', (_req, res) => res.redirect('/public/index.html'));
app.listen(PORT, () => console.log(`Server on http://localhost:${PORT}`));