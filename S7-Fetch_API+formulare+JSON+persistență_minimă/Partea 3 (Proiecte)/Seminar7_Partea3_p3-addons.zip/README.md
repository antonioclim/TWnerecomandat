# Addons (Playwright + SW demo)
- **Playwright**: `playwright.config.ts`, `tests/e2e/smoke.spec.ts`.
- **Service Worker (demo)**: `public/sw.js` caching minimal (scop educațional).