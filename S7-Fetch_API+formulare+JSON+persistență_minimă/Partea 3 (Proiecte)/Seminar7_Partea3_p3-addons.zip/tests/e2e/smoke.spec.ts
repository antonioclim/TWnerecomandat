import { test, expect } from '@playwright/test';
test('home renders list and form', async ({ page }) => {
  await page.goto('/public/index.html');
  await expect(page.locator('#clubs')).toBeVisible();
  await expect(page.locator('#enrol')).toBeVisible();
});