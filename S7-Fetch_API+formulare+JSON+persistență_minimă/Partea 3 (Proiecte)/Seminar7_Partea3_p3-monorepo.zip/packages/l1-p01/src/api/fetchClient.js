const DEFAULT_TIMEOUT = 8000;

export class HttpError extends Error{
  constructor(message, status, payload){ super(message); this.name = 'HttpError'; this.status = status; this.payload = payload; }
}

export async function fetchWithRetry(input, init = {}, { retries = 1, timeoutMs = DEFAULT_TIMEOUT } = {}){
  let attempt = 0;
  while(true){
    const ac = new AbortController();
    const to = setTimeout(()=> ac.abort(), timeoutMs);
    try{
      const res = await fetch(input, { ...init, signal: ac.signal });
      clearTimeout(to);
      if(!res.ok){
        if(res.status >= 500 && res.status < 600 && attempt < retries){ attempt++; await backoff(attempt); continue; }
        return res;
      }
      return res;
    }catch(err){
      clearTimeout(to);
      if(attempt < retries){ attempt++; await backoff(attempt); continue; }
      throw err;
    }
  }
}

function jitter(ms){ return ms * (0.8 + Math.random()*0.4); }
function sleep(ms){ return new Promise(r => setTimeout(r, ms)); }
async function backoff(attempt){ const base = Math.min(1000 * (2 ** (attempt-1)), 8000); await sleep(jitter(base)); }

async function parseJSON(res){
  const ct = res.headers.get('content-type') || '';
  if(!ct.includes('application/json')) throw new Error('Unexpected content-type');
  try{ return await res.json(); }catch{ throw new Error('Invalid JSON'); }
}

export async function jsonGet(path, options = {}){
  const res = await fetchWithRetry(path, { method: 'GET', headers: { 'Accept': 'application/json', ...(options.headers||{}) } }, options);
  if(!res.ok){
    let payload = null; try{ payload = await res.clone().json(); }catch{}
    throw new HttpError(`HTTP ${res.status}`, res.status, payload);
  }
  return parseJSON(res);
}

export async function jsonPost(path, data, options = {}){
  const res = await fetchWithRetry(path, {
    method: 'POST',
    headers: { 'Accept': 'application/json', 'Content-Type': 'application/json', ...(options.headers||{}) },
    body: JSON.stringify(data)
  }, options);
  if(!res.ok){
    let payload = null; try{ payload = await res.clone().json(); }catch{}
    throw new HttpError(`HTTP ${res.status}`, res.status, payload);
  }
  return parseJSON(res);
}