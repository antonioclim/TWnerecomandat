import './pages/clubsPage.js';
import './pages/enrolPage.js';
import './addons/advanced.js'; // schelete pentru L3 (placeholders)