# localStorage cache TTL (5 min) pentru GET
**Nivel:** L2

## Learning goals
- Folosești Fetch API pentru GET/POST JSON (antete corecte).
- Implementezi timeout + abort și policy de retry responsabilă.
- Aplici validare nativă + custom, aria‑live, focus management.
- Adaugi persistență minimă (TTL + SWR, draft autosave).

## Run
```bash
npm i
npm run dev
npm test
```
