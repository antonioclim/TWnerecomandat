# Seminarul 7 — Partea 2 (Laborator, extins)
**Fetch API + formulare + JSON + persistență minimă**

## Rulare
```bash
npm i
npm run dev        # http://localhost:5270 (redirect la /public/index.html)
npm run test:vitest
npm run test:jest
npm test
```

## Ce conține
- **Pages**: `public/index.html` (Clubs), `public/enrol.html` (Enrol)
- **API client**: `src/api/fetchClient.js` (timeout + retry + JSON helpers)
- **Services**: `src/services/clubs.js` (cache TTL + SWR)
- **Forms**: `src/forms/validation.js`, `src/forms/enrolController.js` (Constraint Validation + custom + aria-live)
- **Utils**: `src/utils/storage.js` (localStorage TTL + draft autosave)
- **Tests**: Vitest & Jest, side-by-side (`tests/unit/*`)

## Checklist scurt
- ✅ `fetch` GET/POST JSON (headers corecte)
- ✅ `AbortController` + timeout; retry pe 5xx
- ✅ Validare nativă + custom; aria-live + focus
- ✅ localStorage TTL + SWR; draft autosave
- ✅ Teste unitare (Vitest & Jest)
