const { updateUI } = require('../../src/forms/enrolController.js');

document.body.innerHTML = `<form id="enrol">
  <button id="submit" type="submit">OK</button>
  <p id="form-status" aria-live="polite"></p>
</form>`;

test('sets disabled while submitting and writes status text', () => {
  const form = document.querySelector('#enrol');
  updateUI(form, { status:'submitting' });
  expect(form.querySelector('#submit').disabled).toBe(true);
  expect(form.querySelector('#form-status').textContent).toMatch(/Se trimite/);
});