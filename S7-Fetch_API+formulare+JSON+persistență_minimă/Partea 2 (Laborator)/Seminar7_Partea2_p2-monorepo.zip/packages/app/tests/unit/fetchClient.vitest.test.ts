import { describe, it, expect, vi } from 'vitest';
import { jsonGet, jsonPost, fetchWithRetry, HttpError } from '../../src/api/fetchClient.js';

function mkResponse(body, init){ return new Response(JSON.stringify(body), { headers: { 'content-type': 'application/json' }, ...(init||{}) }); }

describe('fetchClient — retry/timeout/headers', () => {
  it('retries on 500 then succeeds', async () => {
    const spy = vi.fn()
      .mockResolvedValueOnce(mkResponse({ error: 'boom' }, { status: 500 }))
      .mockResolvedValueOnce(mkResponse({ ok: true }, { status: 200 }));
    vi.stubGlobal('fetch', spy);
    const res = await fetchWithRetry('/x', {}, { retries: 1, timeoutMs: 2000 });
    expect(spy).toHaveBeenCalledTimes(2);
    expect(res.ok).toBe(true);
  });

  it('does not retry on 400', async () => {
    const spy = vi.fn().mockResolvedValue(mkResponse({ error: 'bad' }, { status: 400 }));
    vi.stubGlobal('fetch', spy);
    const res = await fetchWithRetry('/x', {}, { retries: 3, timeoutMs: 2000 });
    expect(spy).toHaveBeenCalledTimes(1);
    expect(res.status).toBe(400);
  });

  it('jsonPost throws HttpError on 422 with payload', async () => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(mkResponse({ title: 'Invalid' }, { status: 422 })));
    await expect(jsonPost('/y', { a: 1 })).rejects.toBeInstanceOf(HttpError);
  });
});