const { jsonGet, jsonPost, fetchWithRetry, HttpError } = require('../../src/api/fetchClient.js');

function mkResponse(body, init){ return new Response(JSON.stringify(body), { headers: { 'content-type': 'application/json' }, ...(init||{}) }); }

test('retries on 500 then succeeds', async () => {
  global.fetch = jest.fn()
    .mockResolvedValueOnce(mkResponse({ error: 'boom' }, { status: 500 }))
    .mockResolvedValueOnce(mkResponse({ ok: true }, { status: 200 }));
  const res = await fetchWithRetry('/x', {}, { retries: 1, timeoutMs: 2000 });
  expect(global.fetch).toHaveBeenCalledTimes(2);
  expect(res.ok).toBe(true);
});

test('does not retry on 400', async () => {
  global.fetch = jest.fn().mockResolvedValue(mkResponse({ error: 'bad' }, { status: 400 }));
  const res = await fetchWithRetry('/x', {}, { retries: 3, timeoutMs: 2000 });
  expect(global.fetch).toHaveBeenCalledTimes(1);
  expect(res.status).toBe(400);
});

test('jsonPost throws HttpError on 422 with payload', async () => {
  global.fetch = jest.fn().mockResolvedValue(mkResponse({ title: 'Invalid' }, { status: 422 }));
  await expect(jsonPost('/y', { a: 1 })).rejects.toBeInstanceOf(HttpError);
});