const { validateEnrol } = require('../../src/forms/validation.js');
test('accepts valid data', () => {
  const r = validateEnrol({ fullName:'Ana Pop', email:'ana@uni.ro', club:'tech', consent:true });
  expect(r.ok).toBe(true);
});
test('rejects invalid email and short name', () => {
  const r = validateEnrol({ fullName:'A', email:'x', club:'', consent:false });
  expect(r.ok).toBe(false);
  expect(Object.keys(r.errors).length).toBeGreaterThanOrEqual(3);
});