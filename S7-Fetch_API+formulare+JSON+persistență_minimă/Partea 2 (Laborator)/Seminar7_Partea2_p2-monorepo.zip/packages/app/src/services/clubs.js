import { jsonGet } from '../api/fetchClient.js';
import { lsGet, lsSet } from '../utils/storage.js';

const TTL = 5 * 60 * 1000; // 5 minutes

export async function getClubsCached(){
  const cached = lsGet('clubs');
  if(cached){
    // SWR în fundal
    setTimeout(() => refreshClubs(), 0);
    return cached;
  }
  return refreshClubs();
}

export async function refreshClubs(){
  const data = await jsonGet('/api/clubs');
  lsSet('clubs', data, TTL);
  return data;
}