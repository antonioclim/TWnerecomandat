const NS = 's7:';

export function lsGet(key){
  try{
    const raw = localStorage.getItem(NS+key); if(!raw) return null;
    const { value, expiresAt } = JSON.parse(raw);
    if(expiresAt && Date.now() > expiresAt){ localStorage.removeItem(NS+key); return null; }
    return value;
  }catch{ return null; }
}

export function lsSet(key, value, ttlMs){
  try{
    const payload = { value, expiresAt: ttlMs ? Date.now()+ttlMs : null };
    localStorage.setItem(NS+key, JSON.stringify(payload));
  }catch{}
}

export function lsRemove(key){ try{ localStorage.removeItem(NS+key); }catch{} }

const DRAFT_KEY = 'draft:enrol';

export function saveDraft(form){
  const fd = new FormData(form);
  const data = Object.fromEntries(fd.entries());
  try{ localStorage.setItem(NS + DRAFT_KEY, JSON.stringify(data)); }catch{}
}
export function restoreDraft(form){
  try{
    const raw = localStorage.getItem(NS + DRAFT_KEY); if(!raw) return;
    const data = JSON.parse(raw)||{};
    for(const [k,v] of Object.entries(data)){
      const el = form.elements.namedItem(k); if(!el) continue;
      if(el instanceof RadioNodeList || el.type === 'checkbox'){ el.checked = !!v; }
      else el.value = v;
    }
  }catch{}
}
export function clearDraft(){ try{ localStorage.removeItem(NS + DRAFT_KEY); }catch{} }