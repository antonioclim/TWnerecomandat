const { lsSet, lsGet } = require('../../src/utils/storage.js');
test('localStorage TTL', async () => {
  lsSet('probe', { ok:true }, 10);
  expect(lsGet('probe')?.ok).toBe(true);
  await new Promise(r => setTimeout(r, 20));
  expect(lsGet('probe')).toBe(null);
});