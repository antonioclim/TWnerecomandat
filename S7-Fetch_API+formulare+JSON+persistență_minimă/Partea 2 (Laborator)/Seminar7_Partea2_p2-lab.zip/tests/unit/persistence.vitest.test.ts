import { describe, it, expect } from 'vitest';
import { lsSet, lsGet } from '../../src/utils/storage.js';

describe('localStorage TTL', () => {
  it('returns value before expiry, null after expiry', async () => {
    lsSet('probe', { ok:true }, 10);
    const a = lsGet('probe'); expect(a?.ok).toBe(true);
    await new Promise(r => setTimeout(r, 20));
    const b = lsGet('probe'); expect(b).toBe(null);
  });
});