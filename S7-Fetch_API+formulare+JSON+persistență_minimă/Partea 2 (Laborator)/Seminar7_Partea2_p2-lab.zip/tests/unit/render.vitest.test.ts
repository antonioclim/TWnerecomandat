import { describe, it, expect } from 'vitest';
import { updateUI } from '../../src/forms/enrolController.js';

document.body.innerHTML = `<form id="enrol">
  <button id="submit" type="submit">OK</button>
  <p id="form-status" aria-live="polite"></p>
</form>`;

const form = document.querySelector('#enrol');

describe('updateUI', () => {
  it('sets disabled while submitting and writes status text', () => {
    updateUI(form, { status:'submitting' });
    expect(form.querySelector('#submit').disabled).toBe(true);
    expect(form.querySelector('#form-status').textContent).toMatch(/Se trimite/);
  });
});