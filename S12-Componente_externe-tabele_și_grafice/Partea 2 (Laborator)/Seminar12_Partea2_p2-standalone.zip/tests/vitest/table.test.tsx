import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { DataTable } from '../../src/components/DataTable'
import type { Member } from '../../src/data/useMembersData'

const rows: Member[] = [
  { id:'1', name:'B', club:'Tech', joinedAt:'2025-01-10' },
  { id:'2', name:'A', club:'Arts', joinedAt:'2025-01-12' }
]

test('table sorts by Name', async () => {
  render(<DataTable rows={rows}/>)
  const user = userEvent.setup()
  const btn = screen.getByRole('button', { name: /sort Name/i })
  await user.click(btn) // asc
  const all = screen.getAllByRole('row')
  // row[1] first data row
  expect(all[1]).toHaveTextContent('A')
  await user.click(btn) // desc
  const all2 = screen.getAllByRole('row')
  expect(all2[1]).toHaveTextContent('B')
})
