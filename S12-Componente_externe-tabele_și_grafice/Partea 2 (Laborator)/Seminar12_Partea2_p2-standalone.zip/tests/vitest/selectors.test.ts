import { filterRows, deriveChartConfig } from '../../src/selectors/analytics'
import type { Member } from '../../src/data/useMembersData'

const rows: Member[] = [
  { id:'1', name:'Ana Pop', club:'Tech', joinedAt:'2025-01-10' },
  { id:'2', name:'Mihai Ionescu', club:'Arts', joinedAt:'2025-01-12' },
  { id:'3', name:'Elena Radu', club:'Tech', joinedAt:'2025-02-05' },
]

test('filterRows by query and club', () => {
  const v1 = filterRows(rows, 'ana', 'all')
  expect(v1.length).toBe(1)
  const v2 = filterRows(rows, '', 'Tech')
  expect(v2.length).toBe(2)
})

test('deriveChartConfig aggregates by club', () => {
  const cfg = deriveChartConfig(rows)
  expect(cfg.labels).toEqual(expect.arrayContaining(['Tech','Arts']))
  expect(cfg.datasets[0].data.reduce((a,b)=>a+b,0)).toBe(3)
})
