import type { Member } from '../data/useMembersData'

export function filterRows(rows: Member[], query: string, club: 'all'|'Tech'|'Arts'|'Sports'){
  const q = query.trim().toLowerCase()
  return rows.filter(r => {
    const okQ = !q || r.name.toLowerCase().includes(q) || r.club.toLowerCase().includes(q)
    const okC = club === 'all' || r.club === club
    return okQ && okC
  })
}

export function deriveChartConfig(rows: Member[]){
  const byClub = new Map<string, number>()
  for(const r of rows) byClub.set(r.club, (byClub.get(r.club)||0)+1)
  const labels = Array.from(byClub.keys())
  const values = Array.from(byClub.values())
  return {
    labels,
    datasets: [{ label: 'Members', data: values }]
  }
}
