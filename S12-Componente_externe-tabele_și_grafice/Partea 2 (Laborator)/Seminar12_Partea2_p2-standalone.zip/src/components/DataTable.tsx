import React from 'react'
import { useReactTable, getCoreRowModel, getSortedRowModel, getFilteredRowModel, flexRender, createColumnHelper, SortingState } from '@tanstack/react-table'
import type { Member } from '../data/useMembersData'

const h = createColumnHelper<Member>()

const columns = [
  h.accessor('name', { header: 'Name' }),
  h.accessor('club', { header: 'Club' }),
  h.accessor('joinedAt', { header: 'Joined', cell: (info)=> new Date(info.getValue()).toLocaleDateString() })
]

export function DataTable({ rows }: { rows: Member[] }){
  const [sorting, setSorting] = React.useState<SortingState>([])
  const table = useReactTable({
    data: rows,
    columns,
    state: { sorting },
    onSortingChange: setSorting,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel()
  })

  return (
    <div role="region" aria-label="members-table">
      <table className="table">
        <caption>Members — sortable columns, accessible headers.</caption>
        <thead>
          {table.getHeaderGroups().map(hg => (
            <tr key={hg.id}>
              {hg.headers.map(header => {
                const canSort = header.column.getCanSort()
                const sortDir = header.column.getIsSorted()
                const ariaSort = sortDir === 'asc' ? 'ascending' : sortDir === 'desc' ? 'descending' : 'none'
                return (
                  <th key={header.id} scope="col" aria-sort={ariaSort as any}>
                    {canSort ? (
                      <button onClick={header.column.getToggleSortingHandler()} aria-label={`sort ${String(header.column.columnDef.header)}`}>
                        {flexRender(header.column.columnDef.header, header.getContext())}
                      </button>
                    ) : flexRender(header.column.columnDef.header, header.getContext())}
                  </th>
                )
              })}
            </tr>
          ))}
        </thead>
        <tbody>
          {table.getRowModel().rows.map(row => (
            <tr key={row.id}>
              {row.getVisibleCells().map(cell => (
                <td key={cell.id}>{flexRender(cell.column.columnDef.cell, cell.getContext())}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
      <p role="status">Rows: {table.getRowModel().rows.length}</p>
    </div>
  )
}
