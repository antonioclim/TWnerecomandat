import React, { useEffect, useRef } from 'react'
import { Chart } from 'chart.js/auto'

type Dataset = { label: string; data: number[] }
type Config = { labels: string[]; datasets: Dataset[] }

export function ChartPanel({ config }: { config: Config }){
  const ref = useRef<HTMLCanvasElement>(null)
  useEffect(()=>{
    if(!ref.current) return
    const chart = new Chart(ref.current, {
      type: 'bar',
      data: { labels: config.labels, datasets: config.datasets },
      options: { animation: false, responsive: true, plugins: { legend: { display: true } } }
    })
    return () => chart.destroy()
  }, [config.labels.join(','), JSON.stringify(config.datasets)])
  return <canvas aria-label="chart" ref={ref} />
}
