import { useMemo } from 'react'
import data from './members.json'

export type Member = { id: string; name: string; club: 'Tech'|'Arts'|'Sports'; joinedAt: string }
export function useMembersData(){
  // În laboratorul real, aici ați integra RTK Query.
  const rows = useMemo(()=> (data as Member[]), [])
  return { rows }
}
