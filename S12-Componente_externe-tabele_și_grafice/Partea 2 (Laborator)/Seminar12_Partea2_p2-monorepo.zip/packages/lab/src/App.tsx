import React, { useMemo, useState } from 'react'
import { DataTable } from './components/DataTable'
import { ChartPanel } from './components/ChartPanel'
import { useMembersData } from './data/useMembersData'
import { deriveChartConfig, filterRows } from './selectors/analytics'

export default function App(){
  const { rows } = useMembersData()
  const [query, setQuery] = useState('')
  const [club, setClub] = useState<'all'|'Tech'|'Arts'|'Sports'>('all')

  const visible = useMemo(()=> filterRows(rows, query, club), [rows, query, club])
  const chart = useMemo(()=> deriveChartConfig(visible), [visible])

  return (
    <main className="container">
      <header className="card"><h1>ClubHub+ Analytics — Tabele & Grafice</h1></header>

      <section className="card controls" aria-label="controls">
        <label>Search <input aria-label="search" value={query} onChange={e=>setQuery(e.target.value)} placeholder="Type to filter..." /></label>
        <label>Club
          <select aria-label="club-filter" value={club} onChange={e=>setClub(e.target.value as any)}>
            <option value="all">all</option>
            <option value="Tech">Tech</option>
            <option value="Arts">Arts</option>
            <option value="Sports">Sports</option>
          </select>
        </label>
      </section>

      <section className="grid">
        <article className="card">
          <h2 style={{marginTop:0}}>Members</h2>
          <DataTable rows={visible} />
        </article>
        <article className="card">
          <h2 style={{marginTop:0}}>Members per club</h2>
          <ChartPanel config={chart} />
        </article>
      </section>

      <footer>Seminar 12 — laborator: TanStack Table + Chart.js (TS, Vite). Teste: Vitest & Jest.</footer>
    </main>
  )
}
