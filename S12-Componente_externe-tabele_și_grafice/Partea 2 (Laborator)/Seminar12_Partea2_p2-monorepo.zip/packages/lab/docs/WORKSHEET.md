# Worksheet — Seminar 12 / Partea 2 (Laborator Tabele & Grafice)
Tema: ClubHub+ Analytics — tabel + grafic sincronizate

## Etape & cerințe
0) Setup: Vite + TS + React; TanStack Table; Chart.js; Vitest & Jest.
1) Date: `src/data/members.json` + hook `useMembersData`.
2) Selectori puri: `filterRows(query, club)`, `deriveChartConfig(rows)`.
3) Tabel: coloane sortabile (aria-sort); status rânduri vizibile.
4) Controale: search + club filter (controlled inputs).
5) Grafic: folosește config derivat; fără animații (determinism).
6) Sincronizare: schimbarea filtrelor actualizează tabel + grafic.
7) Teste: selectors (unit), tabel (RTL), grafic (mock Chart.js).

## Checklist minimal
- [ ] `npm test` rulează Vitest + Jest cu succes.
- [ ] Sortarea funcționează (asc/desc) și `aria-sort` e corect.
- [ ] Filtrarea după query/club modifică nr. rânduri vizibile.
- [ ] Graficul este construit cu `labels`/`datasets` corecte.
