# Seminarul 12 — Partea 2: Tabele & Grafice — Laborator

## Rulare
```bash
npm i
npm test              # Vitest + Jest (side-by-side)
npm run dev           # http://localhost:5173
```

## Conținut
- React + TypeScript + Vite
- TanStack Table (sorting/filtering/pagination minimal)
- Chart.js (bar chart) cu wrapper `ChartPanel` (fără animații în teste)
- Selectori puri (`filterRows`, `deriveChartConfig`)
- Teste duale: Vitest & Jest (RTL pentru tabel, mock pentru Chart.js)
