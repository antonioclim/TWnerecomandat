import { render } from '@testing-library/react'
import { ChartPanel } from '../../src/components/ChartPanel'

vi.mock('chart.js/auto', () => {
  return {
    Chart: vi.fn().mockImplementation(() => ({ destroy: vi.fn() }))
  }
})

test('ChartPanel constructs chart with labels/datasets', () => {
  const { container } = render(<ChartPanel config={{ labels:['Tech','Arts'], datasets:[{ label:'Members', data:[2,1] }] }} />)
  const canvas = container.querySelector('canvas')
  expect(canvas).toBeInTheDocument()
})
