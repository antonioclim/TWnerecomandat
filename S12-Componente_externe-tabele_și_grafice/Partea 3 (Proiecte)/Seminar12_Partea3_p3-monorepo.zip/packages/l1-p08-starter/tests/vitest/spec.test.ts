import { formatTooltip } from '../../src/lib/lib'
test('formatTooltip',()=>{expect(formatTooltip(1234.5,'en-GB')).toBe('1,234.5')})
