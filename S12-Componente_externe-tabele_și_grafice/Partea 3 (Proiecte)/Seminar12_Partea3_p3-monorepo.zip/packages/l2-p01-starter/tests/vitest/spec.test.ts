import { fetchMembers } from '../../src/lib/lib'
;(global as any).fetch = jest.fn().mockResolvedValue({ ok:true, json: async()=> [{id:'1',name:'Ana',club:'Tech',joinedAt:'2025-01-01'}] })
test('fetchMembers', async ()=>{ const r=await fetchMembers('/api'); expect(r.length).toBe(1) })
