import { visibleColumns } from '../../src/lib/lib'
test('visibleColumns grouping proxy',()=>{const v=visibleColumns(['a','b','c'],{a:true,b:false,c:true}); expect(v).toEqual(['a','c'])})
