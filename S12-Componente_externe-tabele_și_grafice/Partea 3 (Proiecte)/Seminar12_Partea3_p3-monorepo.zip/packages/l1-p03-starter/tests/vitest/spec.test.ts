import { paginate } from '../../src/lib/lib'
const rows=Array.from({length:10},(_,i)=>({id:String(i),name:'N'+i,club:'Tech',joinedAt:'2025-01-01'}))
test('paginate',()=>{expect(paginate(rows,1,3).map(r=>r.id)).toEqual(['3','4','5'])})
