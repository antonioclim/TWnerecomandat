import { oneWaySyncChart, filterByClub } from '../../src/lib/lib'
test('oneWaySyncChart',()=>{const rows=[{id:'1',name:'Ana',club:'Tech',joinedAt:'2025-01-01'},{id:'2',name:'B',club:'Arts',joinedAt:'2025-01-01'}]; const tech=filterByClub(rows,'Tech'); const cfg:any=oneWaySyncChart(tech); expect(cfg.labels).toEqual(['Tech'])})
