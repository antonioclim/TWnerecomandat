import { configShape } from '../../src/lib/lib'
test('export png contract',()=>{expect(configShape({labels:['A'],datasets:[{label:'x',data:[1]}]})).toBe(true)})
