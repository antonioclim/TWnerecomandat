import { rollups } from '../../src/lib/lib'
test('rollups',()=>{const rows=[{id:'1',name:'A',club:'Tech',joinedAt:'2025-01-01'},{id:'2',name:'B',club:'Arts',joinedAt:'2025-01-01'},{id:'3',name:'C',club:'Tech',joinedAt:'2025-01-01'}]; const m=rollups(rows,r=>r.club); expect(m.get('Tech')).toBe(2)})
