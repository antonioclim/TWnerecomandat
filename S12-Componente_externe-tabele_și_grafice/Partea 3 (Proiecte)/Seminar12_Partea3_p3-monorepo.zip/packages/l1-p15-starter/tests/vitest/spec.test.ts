import { configShape } from '../../src/lib/lib'
test('config shape',()=>{expect(configShape({labels:[],datasets:[]})).toBe(true)})
