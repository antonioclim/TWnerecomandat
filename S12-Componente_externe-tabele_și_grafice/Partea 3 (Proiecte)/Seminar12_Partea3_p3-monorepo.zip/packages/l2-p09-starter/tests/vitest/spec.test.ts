import { drillDown } from '../../src/lib/lib'
test('drillDown',()=>{const rows=[{id:'1',name:'A',club:'Tech',joinedAt:'2025-01-01'},{id:'2',name:'B',club:'Arts',joinedAt:'2025-01-01'}]; expect(drillDown(rows,'Tech').length).toBe(1)})
