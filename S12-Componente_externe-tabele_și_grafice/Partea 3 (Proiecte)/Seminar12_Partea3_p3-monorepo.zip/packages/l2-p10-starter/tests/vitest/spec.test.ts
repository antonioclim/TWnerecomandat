import { dualAxisConfig } from '../../src/lib/lib'
test('dualAxisConfig',()=>{const c:any=dualAxisConfig(['A','B'],[1,2],[3,4]); expect(c.datasets.length).toBe(2); expect(c.options.scales.y2.position).toBe('right')})
