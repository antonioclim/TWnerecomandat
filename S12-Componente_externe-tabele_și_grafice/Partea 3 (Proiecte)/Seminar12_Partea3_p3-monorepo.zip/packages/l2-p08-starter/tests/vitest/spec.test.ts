import { crossfilter } from '../../src/lib/lib'
test('linked views crossfilter',()=>{const rows=[{id:'1',name:'A',club:'Tech',joinedAt:'2025-01-01'},{id:'2',name:'B',club:'Arts',joinedAt:'2025-01-01'}]; expect(crossfilter(new Set(['2']),rows).length).toBe(1)})
