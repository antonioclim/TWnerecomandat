import { buildQuery } from '../../src/lib/lib'
test('buildQuery',()=>{const q=buildQuery('/members',2,50); expect(q).toContain('page=2'); expect(q).toContain('size=50')})
