import { visibleWindow } from '../../src/lib/lib'
test('visibleWindow',()=>{const rs=Array.from({length:5},(_,i)=>({id:String(i),name:'N'+i,club:'Tech',joinedAt:'2025-01-01'})); expect(visibleWindow(rs,1,3).length).toBe(2)})
