export default function App(){return(<main><header className='card'><h1>Project Starter</h1></header><section className='card'><p>Complete the TODOs and make tests pass.</p></section></main>)}
