import { sortByName } from '../../src/lib/lib'
const rows=[{id:'1',name:'B',club:'Tech',joinedAt:'2025-01-01'},{id:'2',name:'A',club:'Arts',joinedAt:'2025-01-02'}]
test('sortByName asc/desc',()=>{expect(sortByName(rows,'asc')[0].name).toBe('A');expect(sortByName(rows,'desc')[0].name).toBe('B')})
