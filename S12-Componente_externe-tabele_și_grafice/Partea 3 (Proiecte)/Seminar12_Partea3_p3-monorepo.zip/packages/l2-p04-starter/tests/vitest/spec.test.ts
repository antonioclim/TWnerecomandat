import { applyEdit } from '../../src/lib/lib'
test('applyEdit',()=>{const r=[{id:'1',name:'Ana',club:'Tech',joinedAt:'2025-01-01'}]; expect(applyEdit(r,'1',{name:'Ana Maria'})[0].name).toBe('Ana Maria')})
