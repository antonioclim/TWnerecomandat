import { toggleSelection } from '../../src/lib/lib'
test('toggleSelection',()=>{const s=new Set<string>();const s1=toggleSelection(s,'1');expect(s1.has('1')).toBe(true);const s2=toggleSelection(s1,'1');expect(s2.has('1')).toBe(false)})
