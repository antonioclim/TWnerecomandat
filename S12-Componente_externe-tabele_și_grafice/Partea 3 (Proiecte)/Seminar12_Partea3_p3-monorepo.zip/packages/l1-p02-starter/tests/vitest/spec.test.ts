import { filterByQuery } from '../../src/lib/lib'
const rows=[{id:'1',name:'Ana',club:'Tech',joinedAt:'2025-01-01'}]
test('filterByQuery',()=>{expect(filterByQuery(rows,'na').length).toBe(1);expect(filterByQuery(rows,'xx').length).toBe(0)})
