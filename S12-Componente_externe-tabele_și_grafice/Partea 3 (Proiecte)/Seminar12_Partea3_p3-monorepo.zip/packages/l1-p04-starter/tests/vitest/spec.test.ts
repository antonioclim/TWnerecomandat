import { visibleColumns } from '../../src/lib/lib'
test('visibleColumns',()=>{const cols=['name','club','joinedAt']; const vis={name:true,club:false,joinedAt:true}; expect(visibleColumns(cols,vis)).toEqual(['name','joinedAt'])})
