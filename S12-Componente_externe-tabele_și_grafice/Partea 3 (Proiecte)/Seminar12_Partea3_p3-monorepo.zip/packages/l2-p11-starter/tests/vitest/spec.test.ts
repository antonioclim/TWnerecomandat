import { markThresholds } from '../../src/lib/lib'
test('markThresholds',()=>{const out:any[]=markThresholds([1,5,10],5); expect(out[0].alert).toBe(false); expect(out[2].alert).toBe(true)})
