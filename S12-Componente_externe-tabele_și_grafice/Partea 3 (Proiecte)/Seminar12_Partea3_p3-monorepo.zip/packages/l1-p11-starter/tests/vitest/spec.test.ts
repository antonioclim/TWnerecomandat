import { legendToggle } from '../../src/lib/lib'
test('legendToggle',()=>{const c={A:false}; const n=legendToggle(c,'A'); expect(n.A).toBe(true)})
