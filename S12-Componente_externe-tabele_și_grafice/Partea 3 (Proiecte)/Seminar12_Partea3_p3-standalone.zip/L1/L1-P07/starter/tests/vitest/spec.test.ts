import { visibleColumnsWindow } from '../../src/lib/lib'
test('visibleColumnsWindow',()=>{expect(visibleColumnsWindow(['a','b','c','d'],1,3)).toEqual(['b','c'])})
