import { chartConfigFromRows } from '../../src/lib/lib'
test('type line respected',()=>{const c:any=chartConfigFromRows([], 'line'); expect(c.type).toBe('line')})
