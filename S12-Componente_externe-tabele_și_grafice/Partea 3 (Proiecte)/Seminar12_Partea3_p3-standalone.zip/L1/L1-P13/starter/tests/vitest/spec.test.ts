import { palette } from '../../src/lib/lib'
test('palette',()=>{expect(palette('dark').length).toBeGreaterThanOrEqual(3)})
