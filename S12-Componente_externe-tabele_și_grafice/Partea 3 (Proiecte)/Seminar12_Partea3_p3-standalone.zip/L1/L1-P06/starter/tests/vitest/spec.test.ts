import { toCsv } from '../../src/lib/lib'
test('toCsv',()=>{const rows=[{id:'1',name:'Ana',club:'Tech',joinedAt:'2025-01-01'}]; expect(toCsv(rows).split('\n').length).toBe(2)})
