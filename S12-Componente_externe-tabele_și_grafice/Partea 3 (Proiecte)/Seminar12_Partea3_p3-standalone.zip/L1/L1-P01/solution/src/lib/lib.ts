export type Member = { id: string; name: string; club: 'Tech'|'Arts'|'Sports'; joinedAt: string }
export function sortByName(rows: Member[], dir: 'asc'|'desc'){ return [...rows].sort((a,b)=> dir==='asc' ? a.name.localeCompare(b.name) : b.name.localeCompare(a.name)) }
export function filterByQuery(rows: Member[], q: string){ const qq=q.trim().toLowerCase(); return rows.filter(r=> !qq || r.name.toLowerCase().includes(qq) || r.club.toLowerCase().includes(qq)) }
export function filterByClub(rows: Member[], club: 'all'|'Tech'|'Arts'|'Sports'){ return rows.filter(r=> club==='all' || r.club===club) }
export function paginate(rows: Member[], pageIndex: number, pageSize: number){ const s=pageIndex*pageSize,e=s+pageSize; return rows.slice(s,e) }
export function visibleColumns(cols: string[], visibility: Record<string, boolean>){ return cols.filter(c=> visibility[c]!==false) }
export function toggleSelection(sel: Set<string>, id: string){ const n=new Set(sel); n.has(id)?n.delete(id):n.add(id); return n }
export function toCsv(rows: Member[]){ const head='id,name,club,joinedAt'; const lines=rows.map(r=>`${r.id},${r.name},${r.club},${r.joinedAt}`); return [head,...lines].join('\n') }
export function chartConfigFromRows(rows: Member[], type: 'bar'|'line'='bar'){ const m=new Map<string,number>(); for(const r of rows)m.set(r.club,(m.get(r.club)||0)+1; return {labels:[...m.keys()], datasets:[{label:'Members', data:[...m.values()]}], type} }
export function legendToggle(hidden: Record<string, boolean>, label: string){ const n={...hidden}; n[label]=!n[label]; return n }
export function formatTooltip(n: number, locale='ro-RO'){ return new Intl.NumberFormat(locale).format(n) }
export function palette(theme:'light'|'dark'){ return theme==='light' ? ['#1f77b4','#ff7f0e','#2ca02c'] : ['#93c5fd','#fdba74','#86efac'] }
export function oneWaySyncChart(rows: Member[]){ return chartConfigFromRows(rows,'bar') }
export function groupBy<T, K extends string|number>(items: T[], key: (t:T)=>K){ const m=new Map<K,T[]>(); for(const it of items){ const k=key(it); const a=m.get(k)||[]; a.push(it); m.set(k,a) } return m }
export async function fetchMembers(url: string){ const res = await fetch(url); if(!res.ok) throw new Error('net'); return await res.json() as Member[] }
export function buildQuery(base: string, pageIndex:number, pageSize:number){ const u=new URL(base, 'http://x'); u.searchParams.set('page', String(pageIndex)); u.searchParams.set('size', String(pageSize)); return u.pathname+u.search }
export function applyEdit(rows: Member[], id: string, patch: Partial<Member>){ return rows.map(r=> r.id===id?{...r,...patch}:r) }
export function visibleWindow(rows: Member[], start:number, end:number){ return rows.slice(start,end) }
export function drillDown(rows: Member[], club: 'Tech'|'Arts'|'Sports'){ return rows.filter(r=> r.club===club) }
export function dualAxisConfig(labels:string[], a:number[], b:number[]){ return { labels, datasets:[{label:'A', data:a, yAxisID:'y1'},{label:'B', data:b, yAxisID:'y2'}], options:{ scales:{ y1:{type:'linear',position:'left'}, y2:{type:'linear',position:'right'} } } } }
export function markThresholds(values:number[], t:number){ return values.map(v=>({v,alert:v>=t})) }
export function intlFormat(n:number, locale='ro-RO'){ return new Intl.NumberFormat(locale).format(n) }
export function themePalette(vars:{[k:string]:string}){ return Object.values(vars) }
export function configShape(cfg:any){ return !!(cfg && Array.isArray(cfg.labels) && Array.isArray(cfg.datasets)) }
export function crossfilter(ids:Set<string>, rows:Member[]){ return rows.filter(r=> ids.has(r.id)) }
export function visibleColumnsWindow(cols:string[], start:number, end:number){ return cols.slice(start,end) }
export function cursorMerge(current:Member[], incoming:Member[], cursor:string){ const seen=new Set(current.map(x=>x.id)); return current.concat(incoming.filter(x=>!seen.has(x.id))) }
export function rollups(rows:Member[], key:(m:Member)=>string){ const m=new Map<string,number>(); for(const r of rows){ const k=key(r); m.set(k,(m.get(k)||0)+1) } return m }
export function vegaLiteSpec(labels:string[], values:number[]){ return { data:{ values: labels.map((l,i)=>({category:l,value:values[i]||0})) }, mark:'bar', encoding:{ x:{field:'category',type:'nominal'}, y:{field:'value',type:'quantitative'} } } }
export function customAxesSpec(xLabel:string,yLabel:string){ return { axes:[{orient:'bottom',label:xLabel},{orient:'left',label:yLabel}] } }
export function applyBrushRange(rows:Member[], start:string, end:string){ const s=new Date(start).getTime(), e=new Date(end).getTime(); return rows.filter(r=>{ const t=new Date(r.joinedAt).getTime(); return t>=s && t<=e }) }
export function annotate(values:number[], notes:string[]){ return values.map((v,i)=>({v, note:notes[i]||''})) }
export function realtimeMerge(arr:number[], newVal:number, max=5){ const a=[...arr,newVal]; return a.slice(-max) }
export function snapshotConfig(cfg:any, data:any){ return {cfg, data} }
export function printCss(){ return '@media print { table{page-break-inside:avoid} }' }
export function downsample(values:number[], step:number){ return values.filter((_,i)=> i%step===0) }
export function serializeConfig(obj:any){ return JSON.stringify(obj) }
export function sanitizeCsv(s:string){ return s.replace(/^[=+\-@]/,'\t$&') }
export function withinBudget(metrics:{renderMs:number,updateMs:number}, limits:{renderMs:number,updateMs:number}){ return metrics.renderMs<=limits.renderMs && metrics.updateMs<=limits.updateMs }
