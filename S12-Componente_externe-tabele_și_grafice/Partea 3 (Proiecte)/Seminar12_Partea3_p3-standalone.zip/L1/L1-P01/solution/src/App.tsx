export default function App(){return(<main><header className='card'><h1>Project Ready</h1></header><section className='card'><p>All tests are green.</p></section></main>)}
