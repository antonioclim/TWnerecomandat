import React, { useEffect, useRef } from 'react'
import { Chart } from 'chart.js/auto'
type Cfg = { labels:string[], datasets:{label:string, data:number[]}[] }
export function ChartPanel({ cfg }:{ cfg: Cfg }){
  const ref=useRef<HTMLCanvasElement>(null)
  useEffect(()=>{ if(!ref.current) return; const chart = new Chart(ref.current,{type:'bar',data:{labels:cfg.labels,datasets:cfg.datasets},options:{animation:false,responsive:true}}); return ()=>chart.destroy() },[JSON.stringify(cfg)])
  return <canvas ref={ref} aria-label='chart'/>
}
