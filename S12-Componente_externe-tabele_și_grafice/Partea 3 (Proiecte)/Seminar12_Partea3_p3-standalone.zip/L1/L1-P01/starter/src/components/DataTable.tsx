import React from 'react'
import { useReactTable, getCoreRowModel, getSortedRowModel, flexRender, createColumnHelper, SortingState } from '@tanstack/react-table'
import type { Member } from '../lib/lib'
const h = createColumnHelper<Member>()
const columns = [ h.accessor('name',{header:'Name'}), h.accessor('club',{header:'Club'}), h.accessor('joinedAt',{header:'Joined', cell:(i)=> new Date(i.getValue()).toLocaleDateString() }) ]
export function DataTable({ rows }:{ rows: Member[] }){
  const [sorting,setSorting]=React.useState<SortingState>([])
  const table = useReactTable({ data:rows, columns, state:{sorting}, onSortingChange:setSorting, getCoreRowModel:getCoreRowModel(), getSortedRowModel:getSortedRowModel() })
  return (<table><caption>Members</caption><thead>{table.getHeaderGroups().map(hg=> (<tr key={hg.id}>{hg.headers.map(hd=>{
    const dir=hd.column.getIsSorted(); const aria = dir==='asc'?'ascending':dir==='desc'?'descending':'none'
    return (<th key={hd.id} scope='col' aria-sort={aria as any}><button onClick={hd.column.getToggleSortingHandler()}>{flexRender(hd.column.columnDef.header, hd.getContext())}</button></th>)
  })}</tr>))}</thead><tbody>{table.getRowModel().rows.map(r=> (<tr key={r.id}>{r.getVisibleCells().map(c=> (<td key={c.id}>{flexRender(c.column.columnDef.cell,c.getContext())}</td>))}</tr>))}</tbody></table>)
}
