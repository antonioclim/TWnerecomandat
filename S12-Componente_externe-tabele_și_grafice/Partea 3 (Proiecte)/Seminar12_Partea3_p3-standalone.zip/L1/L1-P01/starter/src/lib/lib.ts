export type Member = { id: string; name: string; club: 'Tech'|'Arts'|'Sports'; joinedAt: string }
export function sortByName(rows: Member[], dir: 'asc'|'desc'){ return rows }
export function filterByQuery(rows: Member[], q: string){ return rows }
export function filterByClub(rows: Member[], club: 'all'|'Tech'|'Arts'|'Sports'){ return rows }
export function paginate(rows: Member[], pageIndex: number, pageSize: number){ return rows }
export function visibleColumns(cols: string[], visibility: Record<string, boolean>){ return cols }
export function toggleSelection(sel: Set<string>, id: string){ return sel }
export function toCsv(rows: Member[]){ return '' }
export function chartConfigFromRows(rows: Member[], type: 'bar'|'line'='bar'){ return { labels: [], datasets: [], type } }
export function legendToggle(hidden: Record<string, boolean>, label: string){ return hidden }
export function formatTooltip(n: number, locale='ro-RO'){ return String(n) }
export function palette(theme:'light'|'dark'){ return ['#000'] }
export function oneWaySyncChart(rows: Member[]){ return chartConfigFromRows(rows,'bar') }
export function groupBy<T, K extends string|number>(items: T[], key: (t:T)=>K){ return new Map<K,T[]>() }
export async function fetchMembers(url: string){ return [] as Member[] }
export function buildQuery(base: string, pageIndex:number, pageSize:number){ return base }
export function applyEdit(rows: Member[], id: string, patch: Partial<Member>){ return rows }
export function visibleWindow(rows: Member[], start:number, end:number){ return rows }
export function drillDown(rows: Member[], club: 'Tech'|'Arts'|'Sports'){ return rows }
export function dualAxisConfig(labels:string[], a:number[], b:number[]){ return {labels, datasets:[]} }
export function markThresholds(values:number[], t:number){ return values }
export function intlFormat(n:number, locale='ro-RO'){ return String(n) }
export function themePalette(vars:{[k:string]:string}){ return Object.values(vars) }
export function configShape(cfg:any){ return !!cfg }
export function crossfilter(ids:Set<string>, rows:Member[]){ return rows }
export function visibleColumnsWindow(cols:string[], start:number, end:number){ return cols }
export function cursorMerge(current:Member[], incoming:Member[], cursor:string){ return [...current] }
export function rollups(rows:Member[], key:(m:Member)=>string){ return new Map<string,number>() }
export function vegaLiteSpec(labels:string[], values:number[]){ return { data:{}, mark:'bar', encoding:{} } }
export function customAxesSpec(xLabel:string,yLabel:string){ return { axes:[] as any[] } }
export function applyBrushRange(rows:Member[], start:string, end:string){ return rows }
export function annotate(values:number[], notes:string[]){ return values.map((v,i)=>({v, note:notes[i]||''})) }
export function realtimeMerge(arr:number[], newVal:number, max=5){ const a=[...arr,newVal]; return a.slice(-max) }
export function snapshotConfig(cfg:any, data:any){ return {cfg, data} }
export function printCss(){ return '@media print { table{page-break-inside:avoid} }' }
export function downsample(values:number[], step:number){ return values.filter((_,i)=> i%step===0) }
export function serializeConfig(obj:any){ return JSON.stringify(obj) }
export function sanitizeCsv(s:string){ return s.replace(/^[=+\-@]/,'\t$&') }
export function withinBudget(metrics:{renderMs:number,updateMs:number}, limits:{renderMs:number,updateMs:number}){ return false }
