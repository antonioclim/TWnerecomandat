import { chartConfigFromRows } from '../../src/lib/lib'
test('chartConfigFromRows',()=>{const rows=[{id:'1',name:'Ana',club:'Tech',joinedAt:'2025-01-01'}]; const c:any=chartConfigFromRows(rows,'bar'); expect(Array.isArray(c.labels)).toBe(true); expect(Array.isArray(c.datasets)).toBe(true)})
