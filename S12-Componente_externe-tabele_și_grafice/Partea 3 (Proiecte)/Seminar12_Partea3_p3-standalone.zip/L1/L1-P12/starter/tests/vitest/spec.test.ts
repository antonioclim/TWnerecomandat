import { intlFormat } from '../../src/lib/lib'
test('intlFormat',()=>{expect(intlFormat(1234.56,'ro-RO')).toBe('1.234,56'); expect(intlFormat(1234.56,'en-GB')).toBe('1,234.56')})
