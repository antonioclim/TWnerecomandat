# L3-P02 — Column Virtualization (wide)

**Nivel:** L3
**Learning goals:**
- Înțelegerea conceptelor-cheie pentru Column Virtualization (wide).
- Aplicarea funcțiilor pure pentru tabel/grafic și scrierea de teste.
- Integrarea cu React (compilație) fără dependențe inutile.

## Cerințe
1. Rulează `npm test` în `starter/` — unele teste vor PICA (funcții TODO).
2. Completează implementările din `src/lib/lib.ts` până devin VERZI.
3. Compară cu `solution/` pentru a înțelege diferențele.

## Rulare
```bash
npm i
npm test
npm run dev
```

## AI‑assist (VSL) — prompts
- „Implement function `{functionName}` that ... and write Jest/Vitest tests for edge cases.”
- „Refactor `lib.ts` to remove duplication and ensure pure functions.”
