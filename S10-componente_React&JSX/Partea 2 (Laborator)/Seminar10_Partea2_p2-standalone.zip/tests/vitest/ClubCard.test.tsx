import { render, screen } from '@testing-library/react'
import { ClubCard } from '../../src/components/ClubCard'

test('ClubCard renders name and category', () => {
  render(<ClubCard club={{ id:'x', name:'Debate Club', category:'arts' }} />)
  expect(screen.getByText(/debate club/i)).toBeInTheDocument()
  expect(screen.getByText(/category:/i)).toBeInTheDocument()
})
