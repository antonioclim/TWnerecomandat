import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import App from '../../src/App'

test('renders header and initial clubs', async () => {
  render(<App />)
  expect(screen.getByRole('heading', { name: /clubhub/i })).toBeInTheDocument()
  expect(screen.getAllByLabelText('club-card').length).toBeGreaterThan(0)
})

test('filters by query and adds a new club', async () => {
  render(<App />)
  const user = userEvent.setup()
  await user.type(screen.getByLabelText('search-input'), 'tech')
  expect(screen.getAllByLabelText('club-card').length).toBe(1)
  await user.clear(screen.getByLabelText('search-input'))
  // add a new club
  await user.type(screen.getByLabelText('name-input'), 'Chess Club')
  await user.click(screen.getByRole('button', { name: /add/i }))
  expect(screen.getByText(/chess club/i)).toBeInTheDocument()
})
