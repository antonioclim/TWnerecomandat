import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { AddClubForm } from '../../src/components/AddClubForm'

test('AddClubForm submits and clears name', async () => {
  const calls: any[] = []
  render(<AddClubForm onAdd={(c)=>calls.push(c)} />)
  const user = userEvent.setup()
  await user.type(screen.getByLabelText('name-input'), 'Robotics')
  await user.click(screen.getByRole('button', { name: /add/i }))
  expect(calls[0]).toEqual({ name: 'Robotics', category: 'technology' })
})
