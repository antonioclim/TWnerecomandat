# Worksheet — Seminar 10 / Partea 2 (Laborator)
Tema: ClubHub (React + JSX)

## Cerință pe etape
0) Setup (Vite + TS) și test "smoke".
1) Componente & JSX (Header/Footer/ClubCard).
2) State & Events (SearchBox controlat + filtrare listă).
3) Lists & keys (ClubList cu `key` stabil).
4) Controlled forms (AddClubForm) + validare minimă.
5) Composition & children (Card/Stack — opțional).
6) Performance primer (startTransition pentru filtrare grea — opțional).
7) Refactoring + a11y pass.

## Checklist minimal
- [ ] Rulează dev server și vezi headerul.
- [ ] Există cel puțin 3 cluburi inițiale randate.
- [ ] Căutarea filtrează lista în timp real.
- [ ] Formularul adaugă corect un club nou.
- [ ] Fiecare item din listă are `key` stabil.
- [ ] Testele Vitest **și** Jest sunt verzi.
