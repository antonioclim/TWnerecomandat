import { Club } from '../types'
import { ClubCard } from './ClubCard'

export function ClubList({ items }: { items: Club[] }){
  if(items.length === 0){
    return <p role="status">No clubs found.</p>
  }
  return (
    <section className="grid" aria-label="club-list">
      {items.map(club => <ClubCard key={club.id} club={club} />)}
    </section>
  )
}