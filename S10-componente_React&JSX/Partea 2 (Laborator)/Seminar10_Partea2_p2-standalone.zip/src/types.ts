export interface Club {
  id: string
  name: string
  category: string
}
