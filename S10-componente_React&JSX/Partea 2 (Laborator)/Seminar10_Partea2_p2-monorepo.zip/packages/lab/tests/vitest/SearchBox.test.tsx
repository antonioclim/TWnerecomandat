import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { SearchBox } from '../../src/components/SearchBox'

test('SearchBox is controlled', async () => {
  let val = ''
  const onChange = (v:string)=> val = v
  render(<SearchBox value={val} onChange={onChange} />)
  const user = userEvent.setup()
  await user.type(screen.getByLabelText('search-input'), 'abc')
  expect(val).toBe('abc')
})
