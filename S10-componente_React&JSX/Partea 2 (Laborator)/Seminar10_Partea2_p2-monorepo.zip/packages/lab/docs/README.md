# Seminar 10 — Partea 2: React Lab (Componente & JSX)

## Rulare
```bash
npm i
npm run dev           # http://localhost:5173
npm test              # Vitest + Jest (side-by-side)
npm run test:vitest   # doar Vitest
npm run test:jest     # doar Jest
```

## Ce conține
- React 19 + Vite + TypeScript
- Teste @testing-library/react & @testing-library/jest-dom
- Vitest și Jest configurate în paralel (JSDOM)
- Componente: Header, Footer, SearchBox (controlled), ClubCard, ClubList, AddClubForm
- Hook: useFilteredClubs
