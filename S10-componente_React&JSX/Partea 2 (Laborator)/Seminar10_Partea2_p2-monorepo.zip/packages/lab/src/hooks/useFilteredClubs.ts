import { useMemo } from 'react'
import type { Club } from '../types'

export function useFilteredClubs(clubs: Club[], query: string){
  return useMemo(() => {
    const q = query.trim().toLowerCase()
    if(!q) return clubs
    return clubs.filter(c =>
      c.name.toLowerCase().includes(q) || c.category.toLowerCase().includes(q)
    )
  }, [clubs, query])
}
