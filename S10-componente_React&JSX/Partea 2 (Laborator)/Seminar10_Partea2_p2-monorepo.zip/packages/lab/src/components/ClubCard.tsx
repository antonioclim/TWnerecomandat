import { Club } from '../types'
export function ClubCard({ club }: { club: Club }){
  return (
    <article className="card" aria-label="club-card">
      <h3>{club.name}</h3>
      <p><strong>Category:</strong> {club.category}</p>
    </article>
  )
}