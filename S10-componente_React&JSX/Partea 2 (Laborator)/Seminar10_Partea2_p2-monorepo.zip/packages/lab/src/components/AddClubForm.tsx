import { useState } from 'react'

type Props = { onAdd: (club: { name: string; category: string }) => void }

export function AddClubForm({ onAdd }: Props){
  const [name, setName] = useState('')
  const [category, setCategory] = useState('technology')

  function submit(e: React.FormEvent){
    e.preventDefault()
    if(!name.trim()) return
    onAdd({ name: name.trim(), category })
    setName('')
  }

  return (
    <form onSubmit={submit} aria-label="add-club-form">
      <label>
        <span>Name</span>
        <input aria-label="name-input" value={name} onChange={e => setName(e.target.value)} />
      </label>
      <label>
        <span>Category</span>
        <select aria-label="category-select" value={category} onChange={e => setCategory(e.target.value)}>
          <option value="technology">technology</option>
          <option value="arts">arts</option>
          <option value="sports">sports</option>
        </select>
      </label>
      <button type="submit">Add</button>
    </form>
  )
}