import React, { useMemo, useState, startTransition } from 'react'
import { Club } from './types'
import { Header } from './components/Header'
import { Footer } from './components/Footer'
import { SearchBox } from './components/SearchBox'
import { ClubList } from './components/ClubList'
import { AddClubForm } from './components/AddClubForm'
import { useFilteredClubs } from './hooks/useFilteredClubs'

const initialClubs: Club[] = [
  { id: 'tech', name: 'Tech & Coding', category: 'technology' },
  { id: 'arts', name: 'Arts & Culture', category: 'arts' },
  { id: 'sport', name: 'Sports Club', category: 'sports' }
]

export default function App(){
  const [query, setQuery] = useState('')
  const [clubs, setClubs] = useState<Club[]>(initialClubs)

  const filtered = useFilteredClubs(clubs, query)

  function addClub(input: Omit<Club, 'id'>){
    const id = input.name.toLowerCase().replace(/\s+/g,'-')
    setClubs(prev => [...prev, { id, ...input }])
  }

  function onSearchChange(q: string){
    // folosim startTransition pentru a marca update-ul ca necritic (exercițiu didactic)
    startTransition(() => setQuery(q))
  }

  return (
    <div className="container stack">
      <Header title="ClubHub — React + JSX Lab" />
      <SearchBox value={query} onChange={onSearchChange} placeholder="Search clubs..." />
      <AddClubForm onAdd={addClub} />
      <ClubList items={filtered} />
      <Footer>Built with React 19 + Vite • Lab S10/P2</Footer>
    </div>
  )
}
