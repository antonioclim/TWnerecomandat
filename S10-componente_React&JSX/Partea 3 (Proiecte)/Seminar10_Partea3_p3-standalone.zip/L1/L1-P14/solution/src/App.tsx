import React, { useState, startTransition } from 'react'

export default function App(){ 
  const [query, setQuery] = useState('')
  return (
    <main className="container">
      <h1 data-testid="title">Testing RTL: Queries by Role</h1>
      <label aria-label="search">
        <span>Search:</span>
        <input aria-label="search-input" value={query} onChange={e => startTransition(() => setQuery(e.target.value))} />
      </label>
      <p className="card">Solution skeleton — query length: {query.length}</p>
    </main>
  )
}
