# L1-P14 — Testing RTL: Queries by Role

**Nivel:** L1  
**Tema:** Testing RTL: Queries by Role — specificație: implementați comportamentul descris și treceți testele RTL (Vitest & Jest).

## Cerințe
1. Afișează un titlu (`<h1 data-testid="title">`) cu textul exact: **Testing RTL: Queries by Role**.
2. Adaugă un `input` controlat pentru căutare (cu `aria-label="search-input"`).
3. Păstrează structura de bază în `App.tsx` (poți adăuga componente după necesități).

## Criterii de acceptare (teste)
- Testele Vitest & Jest verifică existența titlului și a `search-input`.
- În **starter** testele pot trece parțial (titlu TODO); în **solution** trec complet.

## Pași recomandați
- Rulează: `npm i`, apoi `npm test`, apoi `npm run dev`.
- Completează titlul și transformă `input` în controlled (`value` + `onChange`).

## AI‑assist (VSL) — exemple de prompts
- „Create a minimal React component with an `<h1 data-testid='title'>` set to 'Testing RTL: Queries by Role'.”
- „Add a controlled `<input aria-label='search-input'>` with a state hook and a test.”

## Soluție (sumar)
Soluție orientativă pentru Testing RTL: Queries by Role: implementare minimă care satisface testele (render <h1 data-testid='title'>Testing RTL: Queries by Role</h1> + comportamentul cerut).
