import React from 'react'

export default function App(){ 
  return (
    <main className="container">
      <h1 data-testid="title">TODO: Replace with project title</h1>
      <p className="card">Starter skeleton for project: Error Boundary (concept & stub)</p>
    </main>
  )
}
