import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import App from '../../src/App'

test('renders project title', () => {
  render(<App />)
  expect(screen.getByTestId('title')).toBeInTheDocument()
})

test('has a controlled search input (solution will pass)', async () => {
  render(<App />)
  const user = userEvent.setup()
  const input = screen.getByLabelText('search-input')
  await user.type(input, 'abc')
  expect(input).toBeInTheDocument()
})
