# Theming extins — palete și aliasuri

**Nivel:** L3

## Obiective de învățare
- Să aplici selec­tori moderni și să menții specificitatea redusă.

## Rulare
```bash
npm i
npm run dev
npm test
```
