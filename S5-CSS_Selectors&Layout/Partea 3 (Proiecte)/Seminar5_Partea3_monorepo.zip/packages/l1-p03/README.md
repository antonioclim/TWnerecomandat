# Form minimal — :required/:optional și :placeholder-shown

**Nivel:** L1

## Obiective de învățare
- Să stilizezi stările native (`:invalid/:valid`, `:placeholder-shown`).
- Să evidențiezi grupul cu erori (`:has()`).

## Rulare
```bash
npm i
npm run dev
npm test
```
