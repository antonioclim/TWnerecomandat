# Grid 3×3 responsiv — 3→2→1

**Nivel:** L2

## Obiective de învățare
- Să definești un **grid 3×3** responsiv.
- Să folosești `gap` și `grid-template-columns`.

## Rulare
```bash
npm i
npm run dev
npm test
```
