const fs = require('node:fs'); const path = require('node:path');
const root = path.resolve(__dirname, '..','..');

function read(file){ return fs.readFileSync(path.join(root, file), 'utf8'); }
function re(pattern){ return new RegExp(pattern); }

test('HTML must contain required fragments', () => {
  const cfg = JSON.parse(read('tests/config.json'));
  const html = read('public/index.html');
  (cfg.htmlAllOf || []).forEach(p => expect(html).toMatch(re(p)));
});

test('CSS must contain all-of patterns', () => {
  const cfg = JSON.parse(read('tests/config.json'));
  const css = read('styles.css');
  (cfg.cssAllOf || []).forEach(p => expect(css).toMatch(re(p)));
});

test('CSS must contain at least one any-of pattern (if defined)', () => {
  const cfg = JSON.parse(read('tests/config.json'));
  const css = read('styles.css');
  const any = cfg.cssAnyOf || [];
  if(any.length === 0){ expect(true).toBe(true); return; }
  const ok = any.some(p => re(p).test(css));
  expect(ok).toBe(true);
});
