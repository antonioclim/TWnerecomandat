# Design tokens pack — tematici light/dark

**Nivel:** L3

## Obiective de învățare
- Să definești **CSS custom properties** pentru tematici.
- Să aplici light/dark theme.

## Rulare
```bash
npm i
npm run dev
npm test
```
