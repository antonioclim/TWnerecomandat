# Focus vizibil universal — linkuri, butoane, inputuri

**Nivel:** L1

## Obiective de învățare
- Să aplici **:focus-visible** consecvent pe elemente interactive.
- Să menții specificitatea scăzută cu `:where()`.

## Rulare
```bash
npm i
npm run dev
npm test
```
