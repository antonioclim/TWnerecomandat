# Form states matrix — combinarea stărilor

**Nivel:** L3

## Obiective de învățare
- Să stilizezi stările native (`:invalid/:valid`, `:placeholder-shown`).
- Să evidențiezi grupul cu erori (`:has()`).

## Rulare
```bash
npm i
npm run dev
npm test
```
