# Grid areas complex — pagina „Club details”

**Nivel:** L3

## Obiective de învățare
- Să definești un **grid 3×3** responsiv.
- Să folosești `gap` și `grid-template-columns`.
- Să mapezi layoutul cu **grid-template-areas**.

## Rulare
```bash
npm i
npm run dev
npm test
```
