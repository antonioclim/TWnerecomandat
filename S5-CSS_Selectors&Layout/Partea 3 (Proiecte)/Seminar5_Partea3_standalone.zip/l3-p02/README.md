# Container queries (inline-size) — layout adaptiv

**Nivel:** L3

## Obiective de învățare
- Să utilizezi **container queries** (inline-size).

## Rulare
```bash
npm i
npm run dev
npm test
```
