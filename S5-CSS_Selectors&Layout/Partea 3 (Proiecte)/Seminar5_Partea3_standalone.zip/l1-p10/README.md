# Grupuri cu :focus-within (form groups)

**Nivel:** L1

## Obiective de învățare
- Să aplici **:focus-visible** consecvent pe elemente interactive.
- Să menții specificitatea scăzută cu `:where()`.
- Să stilizezi stările native (`:invalid/:valid`, `:placeholder-shown`).
- Să evidențiezi grupul cu erori (`:has()`).

## Rulare
```bash
npm i
npm run dev
npm test
```
