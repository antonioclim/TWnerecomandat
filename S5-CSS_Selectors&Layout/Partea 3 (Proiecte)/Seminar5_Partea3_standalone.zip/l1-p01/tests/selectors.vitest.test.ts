import { describe, it, expect } from 'vitest';
import fs from 'node:fs'; import path from 'node:path';

const root = path.resolve(__dirname, '..','..');

function read(file){ return fs.readFileSync(path.join(root, file), 'utf8'); }
function re(pattern){ return new RegExp(pattern); }

describe('CSS selectors/layout checks', () => {
  const cfg = JSON.parse(read('tests/config.json'));
  const css = read('styles.css');
  const html = read('public/index.html');

  it('HTML must contain required fragments', () => {
    (cfg.htmlAllOf || []).forEach(p => expect(html).toMatch(re(p)));
  });

  it('CSS must contain all-of patterns', () => {
    (cfg.cssAllOf || []).forEach(p => expect(css).toMatch(re(p)));
  });

  it('CSS must contain at least one any-of pattern (if defined)', () => {
    const any = cfg.cssAnyOf || [];
    if(any.length === 0){ expect(true).toBe(true); return; }
    const ok = any.some(p => re(p).test(css));
    expect(ok).toBe(true);
  });
});
