const fs = require('node:fs');
const path = require('node:path');
const { JSDOM } = require('jsdom');

const root = path.resolve(__dirname, '..', '..');

test('forms.css include :focus-visible, :has(), :invalid', () => {
  const css = fs.readFileSync(path.join(root, 'styles', 'forms.css'), 'utf8');
  expect(css).toMatch(/:focus-visible/);
  expect(css).toMatch(/:has\(/);
  expect(css).toMatch(/:invalid/);
});

test('layout.css include grid 3×3', () => {
  const css = fs.readFileSync(path.join(root, 'styles', 'layout.css'), 'utf8');
  expect(css).toMatch(/display:\s*grid/);
  expect(css).toMatch(/grid-template-columns:\s*repeat\(3,\s*1fr\)/);
});

test('index.html are formular cu required', () => {
  const html = fs.readFileSync(path.join(root, 'public', 'index.html'), 'utf8');
  const dom = new JSDOM(html);
  const doc = dom.window.document;
  expect(doc.querySelector('form#join-form[novalidate]')).toBeTruthy();
  expect(doc.querySelectorAll('#join-form [required]').length).toBeGreaterThanOrEqual(3);
});
