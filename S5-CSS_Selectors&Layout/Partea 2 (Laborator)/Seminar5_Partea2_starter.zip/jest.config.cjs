module.exports = {
  testEnvironment: 'jsdom'
};