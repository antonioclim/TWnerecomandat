import { qs, qsa, on } from './utils/dom.js';

const form = qs('#join-form');
const errorsRegion = qs('.errors', form);

function validateField(el){
  const errorEl = el.id ? form.querySelector(`#err-${el.id}`) : null;
  if(!el.checkValidity()){
    if(errorEl){ errorEl.textContent = el.validationMessage; }
    return false;
  } else {
    if(errorEl){ errorEl.textContent = ''; }
    return true;
  }
}

if(form){
  // live validation on blur / input (lightweight)
  qsa('input, select, textarea', form).forEach(el => {
    on(el, 'blur', () => validateField(el));
    on(el, 'input', () => { if(!el.matches(':placeholder-shown')) validateField(el); });
  });

  on(form, 'submit', (e) => {
    e.preventDefault();
    const fields = qsa('input, select, textarea', form);
    const invalid = fields.filter(f => !validateField(f));
    if(invalid.length){
      errorsRegion.textContent = `Verificați câmpurile marcate (${invalid.length}).`;
      invalid[0].focus();
      return;
    }
    errorsRegion.textContent = 'Trimis! Vă contactăm curând.';
    form.reset();
  });
}
