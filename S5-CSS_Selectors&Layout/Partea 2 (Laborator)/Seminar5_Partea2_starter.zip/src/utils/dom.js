export const qs = (sel, root=document) => root.querySelector(sel);
export const qsa = (sel, root=document) => [...root.querySelectorAll(sel)];
export function on(target, type, handler, opts={}){
  const { signal, capture=false, once=false, passive=false } = opts;
  target.addEventListener(type, handler, { capture, once, passive, signal });
  return () => target.removeEventListener(type, handler, { capture });
}
export function delegate(root, type, selector, handler, opts={}){
  const proxy = (e) => {
    const el = e.target.closest(selector);
    if(el && root.contains(el)) handler(e, el);
  };
  return on(root, type, proxy, opts);
}
