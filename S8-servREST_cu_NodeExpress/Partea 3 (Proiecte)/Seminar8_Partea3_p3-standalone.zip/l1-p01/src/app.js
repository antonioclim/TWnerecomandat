const express = require('express');
const cors = require('cors');
const { correlationId } = require('./middlewares/correlationId');
const { requestLogger } = require('./middlewares/logger');
const { errorHandler } = require('./middlewares/errors');
const { notFound } = require('./middlewares/notFound');
const healthRoutes = require('./routes/health.routes');

// TODO: students will extend with /api/clubs and /api/registrations routers as required by each project.
// HINTS: ETag, If-None-Match, application/problem+json, Idempotency-Key are supported by the starter helpers.

const app = express();
app.use(correlationId);
app.use(express.json({ limit: '256kb' }));
app.use(cors({ origin: [/^http:\/\/localhost:\d+$/], credentials: false }));
app.use(requestLogger);

app.use('/ping', healthRoutes);

// 404 & error mapping (RFC7807)
app.use(notFound);
app.use(errorHandler);

module.exports = app;