function requestLogger(req, res, next){
  const t0 = Date.now();
  res.on('finish', () => {
    const rec = { ts:new Date().toISOString(), cid:req.correlationId, method:req.method, url:req.originalUrl, status:res.statusCode, durMs: Date.now()-t0 };
    try{ console.log(JSON.stringify(rec)); }catch{}
  });
  next();
}
module.exports = { requestLogger };