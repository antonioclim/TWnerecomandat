const { randomUUID } = require('node:crypto');
function correlationId(req, res, next){
  const incoming = req.get('X-Correlation-Id');
  const cid = incoming && /^[A-Za-z0-9-]{8,}$/.test(incoming) ? incoming : randomUUID();
  res.setHeader('X-Correlation-Id', cid);
  req.correlationId = cid;
  next();
}
module.exports = { correlationId };