const fs = require('node:fs');
const path = require('node:path');

function allFiles(dir){
  let files = [];
  for(const entry of fs.readdirSync(dir,{withFileTypes:true})){
    const p = path.join(dir, entry.name);
    if(entry.isDirectory()) files = files.concat(allFiles(p));
    else if(/\.(js|ts|cjs|mjs|json|md)$/i.test(entry.name)) files.push(p);
  }
  return files;
}
function readAll(dir){
  const files = allFiles(dir);
  let buf = '';
  for(const f of files){
    try{ buf += '\n\n' + fs.readFileSync(f, 'utf-8'); }catch{}
  }
  return buf;
}

test('smoke & spec patterns', () => {
  const cfg = JSON.parse(fs.readFileSync(path.join(__dirname,'../config.json'),'utf-8'));
  const content = readAll(path.join(__dirname,'../../'));
  for(const ptn of cfg.smokePatterns||[]){
    expect(content.includes(ptn)).toBe(true);
  }
  for(const ptn of cfg.specPatterns||[]){
    expect(content.includes(ptn)).toBe(true);
  }
});