import { describe, it, expect } from 'vitest';
import request from 'supertest';
import { createRequire } from 'module';
const require = createRequire(import.meta.url);
const app = require('../../src/app.js');

describe('HTTP smoke', () => {
  it('GET /ping => pong', async () => {
    const res = await request(app).get('/ping').expect(200);
    expect(res.text).toContain('pong');
  });
});