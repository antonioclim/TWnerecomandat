# `PATCH /api/clubs/:id` — update parțial
**Nivel:** L1

## Learning goals
- Exersezi proiectarea/consumul de rute REST corecte (Node/Express).
- Aplici validări (input) și maparea erorilor la `application/problem+json` (RFC 7807).
- Consolidezi semantica HTTP: coduri 2xx/4xx/5xx, ETag/304, CORS, problem+json.

## Run
```bash
npm i
npm run dev            # API on http://localhost:5480
npm test               # Vitest + Jest (patterns + smoke HTTP)
```

## Hints
- Caută în `tests/config.json` lista de `specPatterns` pe care trebuie să le acoperi.
- `src/errors/problem.js` și `src/middlewares/errors.js` sunt deja pre‑cablate pentru `problem+json`.
- Completează rutele necesare în `src/app.js` (conectează routere specifice dacă alegi să le creezi).
