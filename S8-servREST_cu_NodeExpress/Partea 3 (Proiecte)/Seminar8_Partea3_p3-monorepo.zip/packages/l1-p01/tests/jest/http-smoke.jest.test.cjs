const request = require('supertest');
const app = require('../../src/app.js');
test('GET /ping => pong', async () => {
  const res = await request(app).get('/ping').expect(200);
  expect(res.text).toContain('pong');
});