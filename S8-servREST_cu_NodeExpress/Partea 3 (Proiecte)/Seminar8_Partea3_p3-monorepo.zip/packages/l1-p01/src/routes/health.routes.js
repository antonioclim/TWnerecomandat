const { Router } = require('express');
const r = Router();
r.get('/', (_req, res) => res.type('text/plain').send('pong'));
module.exports = r;