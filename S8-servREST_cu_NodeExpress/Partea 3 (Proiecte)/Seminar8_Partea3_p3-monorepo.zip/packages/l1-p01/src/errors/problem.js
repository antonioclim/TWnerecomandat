// RFC 7807 helpers (application/problem+json)
function problem({ type, title, status, detail, instance, errors, extras }){
  const obj = { type, title, status, detail };
  if(instance) obj.instance = instance;
  if(errors) obj.errors = errors;
  if(extras && typeof extras === 'object') Object.assign(obj, extras);
  return obj;
}

function toProblem(err, { instance } = {}){
  if(err && typeof err.status === 'number'){
    return problem({ type: err.type||'about:blank', title: err.title||err.message||'HTTP error', status: err.status, detail: err.detail, instance, errors: err.errors });
  }
  if(err && err.name === 'ValidationError'){
    return problem({ type:'https://example.edu/problems/validation', title:'Validation failed', status:422, detail:'One or more fields are invalid.', instance, errors: err.errors||{} });
  }
  return problem({ type:'about:blank', title:'Internal Server Error', status:500, detail: process.env.NODE_ENV==='production'? undefined : (err && err.stack) });
}

function badRequest(detail, extras){ const e = new Error('Bad Request'); e.status = 400; e.detail = detail; if(extras) e.errors = extras; return e; }
function unprocessable(errors){ const e = new Error('Unprocessable Content'); e.status = 422; e.name='ValidationError'; e.errors = errors || {}; return e; }
function conflict(detail){ const e = new Error('Conflict'); e.status = 409; e.detail = detail; return e; }

module.exports = { problem, toProblem, badRequest, unprocessable, conflict };