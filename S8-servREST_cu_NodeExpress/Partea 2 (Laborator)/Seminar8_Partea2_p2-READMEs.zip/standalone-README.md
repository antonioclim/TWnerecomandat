# Seminar 8 — REST cu Node/Express (standalone)
## Run
```bash
npm i
npm run dev        # API on http://localhost:5380
npm test           # Vitest + Jest
```
## Endpoints
- `GET /ping` → `pong`
- `GET /api/clubs` (`?page&limit&category&sort=name,-createdAt`)
- `GET /api/clubs/:id` (ETag + `If-None-Match` → 304)
- `POST /api/clubs` (201 + `Location`), `PATCH /api/clubs/:id`, `DELETE /api/clubs/:id`
- `GET /api/registrations?club=…`, `POST /api/registrations` (Idempotency-Key)
## Tests
- `tests/vitest/*.test.ts` și `tests/jest/*.test.cjs` (aceleași scenarii).
