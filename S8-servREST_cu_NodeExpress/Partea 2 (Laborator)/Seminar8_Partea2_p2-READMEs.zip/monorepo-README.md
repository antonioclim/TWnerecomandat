# Monorepo PNPM

Vezi pachetul `packages/api`.
