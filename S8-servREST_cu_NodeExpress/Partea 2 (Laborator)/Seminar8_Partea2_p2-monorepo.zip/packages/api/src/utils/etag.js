const crypto = require('node:crypto');
function calcEtag(obj){
  const json = JSON.stringify(obj);
  const hash = crypto.createHash('sha1').update(json).digest('base64');
  return `W/"${hash}"`;
}
module.exports = { calcEtag };