function parseIntOr(value, d){ const n = parseInt(value, 10); return Number.isFinite(n) && n>0 ? n : d; }
function parsePageLimit(q){ return { page: parseIntOr(q.page, 1), limit: parseIntOr(q.limit, 10) }; }
function applyPagination(items, page, limit){
  const total = items.length;
  const start = (page-1)*limit;
  const end = start + limit;
  const sliced = items.slice(start, end);
  return { items: sliced, page, limit, total };
}
function parseSort(sortStr){
  if(!sortStr) return [];
  return String(sortStr).split(',').map(s => s.trim()).filter(Boolean).map(s => ({ key: s.replace(/^-/, ''), dir: s.startsWith('-') ? -1 : 1 }));
}
function applySort(items, sortKeys){
  if(!sortKeys || sortKeys.length===0) return items;
  const arr = items.slice();
  arr.sort((a,b) => {
    for(const {key, dir} of sortKeys){
      const av = a[key], bv = b[key];
      if(av < bv) return -1*dir;
      if(av > bv) return 1*dir;
    }
    return 0;
  });
  return arr;
}
module.exports = { parsePageLimit, applyPagination, parseSort, applySort };