const { listClubs, getClub, createClub, patchClub, deleteClub } = require('../services/clubs.service');
const { calcEtag } = require('../utils/etag');

function list(req, res){
  const { page=1, limit=10, category, sort } = req.query;
  const pageN = parseInt(page,10)||1, limitN = parseInt(limit,10)||10;
  const data = listClubs({ page: pageN, limit: limitN, category, sort });
  res.setHeader('Cache-Control','no-store');
  res.json(data);
}

function getOne(req, res){
  const c = getClub(req.params.id);
  if(!c) return res.status(404).json({ type:'about:blank', title:'Not Found', status:404 });
  const etag = calcEtag(c);
  const inm = req.get('If-None-Match');
  if(inm && inm === etag){ return res.status(304).end(); }
  res.setHeader('ETag', etag);
  res.json(c);
}

function create(req, res){
  const c = createClub(req.validated);
  res.status(201).location(`/api/clubs/${c.id}`).json(c);
}

function patchOne(req, res){
  const c = patchClub(req.params.id, req.validated);
  res.json(c);
}

function remove(req, res){
  deleteClub(req.params.id);
  res.status(204).end();
}

module.exports = { list, getOne, create, patchOne, remove };