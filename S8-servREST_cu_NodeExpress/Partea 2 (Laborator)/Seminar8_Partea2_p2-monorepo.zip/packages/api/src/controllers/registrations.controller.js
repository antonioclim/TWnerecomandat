const { listRegistrations, createRegistration } = require('../services/registrations.service');

function list(req, res){
  const { club } = req.query;
  const items = listRegistrations({ club });
  res.json({ items, total: items.length });
}

function create(req, res){
  const idemKey = req.get('Idempotency-Key');
  const r = createRegistration(req.validated, idemKey);
  res.status(201).location(`/api/registrations/${r.id}`).json(r);
}

module.exports = { list, create };