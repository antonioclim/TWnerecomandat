const { Router } = require('express');
const ctrl = require('../controllers/clubs.controller');
const { validateBody } = require('../middlewares/validate');
const { validateCreateClub, validatePatchClub } = require('../schemas/club.schema');

const r = Router();
r.get('/', ctrl.list);
r.get('/:id', ctrl.getOne);
r.post('/', validateBody(validateCreateClub), ctrl.create);
r.patch('/:id', validateBody(validatePatchClub), ctrl.patchOne);
r.delete('/:id', ctrl.remove);

module.exports = r;