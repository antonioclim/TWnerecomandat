function validateRegistration(body){
  const errors = {};
  const fullName = (body && body.fullName || '').trim();
  const email = (body && body.email || '').trim();
  const club = (body && body.club || '').trim();
  const consent = !!(body && (body.consent === true || body.consent === 'true' || body.consent === 'on'));

  if(fullName.length < 3) errors.fullName = 'Full name must have at least 3 chars';
  if(!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) errors.email = 'Invalid email';
  if(!club) errors.club = 'Club is required';
  if(!consent) errors.consent = 'Consent is required';

  const data = { fullName, email, club, consent };
  return { ok: Object.keys(errors).length===0, data, errors };
}
module.exports = { validateRegistration };