function validateCreateClub(body){
  const errors = {};
  const name = (body && body.name || '').trim();
  const category = (body && body.category || '').trim();
  const id = (body && body.id || '').trim();

  if(name.length < 3) errors.name = 'Name must have at least 3 chars';
  const allowed = ['technology','communication','arts','science','sports'];
  if(!allowed.includes(category)) errors.category = 'Invalid category';

  const res = { name, category };
  if(id){ if(!/^[a-z0-9-]{2,}$/.test(id)) errors.id = 'Invalid id format'; else res.id = id; }

  return { ok: Object.keys(errors).length===0, data: res, errors };
}

function validatePatchClub(body){
  const errors = {};
  const patch = {};
  if('name' in body){
    const v = String(body.name).trim();
    if(v.length < 3) errors.name = 'Name must have at least 3 chars';
    else patch.name = v;
  }
  if('category' in body){
    const v = String(body.category).trim();
    const allowed = ['technology','communication','arts','science','sports'];
    if(!allowed.includes(v)) errors.category = 'Invalid category';
    else patch.category = v;
  }
  return { ok: Object.keys(errors).length===0, data: patch, errors };
}

module.exports = { validateCreateClub, validatePatchClub };