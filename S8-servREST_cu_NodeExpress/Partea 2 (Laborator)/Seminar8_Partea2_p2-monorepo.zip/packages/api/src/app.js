const express = require('express');
const cors = require('cors');

// middlewares
const { correlationId } = require('./middlewares/correlationId');
const { requestLogger } = require('./middlewares/logger');
const { errorHandler } = require('./middlewares/errors');
const { notFound } = require('./middlewares/notFound');

// routes
const clubsRoutes = require('./routes/clubs.routes');
const regsRoutes = require('./routes/registrations.routes');
const healthRoutes = require('./routes/health.routes');

const app = express();

// base middlewares
app.use(correlationId);
app.use(express.json({ limit: '256kb' }));
app.use(cors({ origin: [/^http:\/\/localhost:\d+$/], credentials: false }));
app.use(requestLogger);

// mount routes
app.use('/ping', healthRoutes);
app.use('/api/clubs', clubsRoutes);
app.use('/api/registrations', regsRoutes);

// 404 & error
app.use(notFound);
app.use(errorHandler);

module.exports = app;