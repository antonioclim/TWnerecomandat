const { validateCreateClub } = require('../../src/schemas/club.schema');
const { validateRegistration } = require('../../src/schemas/registration.schema');
const { toProblem, unprocessable } = require('../../src/errors/problem');

test('validateCreateClub ok', () => {
  const r = validateCreateClub({ name:'Robotics', category:'technology' });
  expect(r.ok).toBe(true);
});

test('validateRegistration invalid email', () => {
  const r = validateRegistration({ fullName:'Ana', email:'x', club:'tech', consent:true });
  expect(r.ok).toBe(false);
  expect(r.errors).toHaveProperty('email');
});

test('problem serializer 422', () => {
  const err = unprocessable({ email:'invalid' });
  const p = toProblem(err, { instance:'/api/registrations' });
  expect(p.status).toBe(422);
  expect(p.errors).toHaveProperty('email');
});