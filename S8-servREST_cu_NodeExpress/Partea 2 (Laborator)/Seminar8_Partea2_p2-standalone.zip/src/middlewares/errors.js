const { toProblem } = require('../errors/problem');
function errorHandler(err, req, res, _next){
  const prob = toProblem(err, { instance: req.originalUrl });
  res.status(prob.status || 500).type('application/problem+json').send(prob);
}
module.exports = { errorHandler };