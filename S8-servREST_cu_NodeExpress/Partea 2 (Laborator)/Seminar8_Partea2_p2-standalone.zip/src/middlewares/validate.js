const { unprocessable, badRequest } = require('../errors/problem');
function validateBody(validator){
  return (req, _res, next) => {
    if(!req.is('application/json')) return next(badRequest('Expected application/json'));
    const verdict = validator(req.body || {});
    if(!verdict.ok) return next(unprocessable(verdict.errors));
    req.validated = verdict.data;
    next();
  };
}
module.exports = { validateBody };