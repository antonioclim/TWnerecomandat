function requestLogger(req, res, next){
  const start = process.hrtime.bigint();
  res.on('finish', () => {
    const end = process.hrtime.bigint();
    const ms = Number(end - start) / 1e6;
    const rec = {
      ts: new Date().toISOString(),
      cid: req.correlationId,
      method: req.method,
      url: req.originalUrl,
      status: res.statusCode,
      durMs: Math.round(ms)
    };
    try{ console.log(JSON.stringify(rec)); }catch{}
  });
  next();
}
module.exports = { requestLogger };