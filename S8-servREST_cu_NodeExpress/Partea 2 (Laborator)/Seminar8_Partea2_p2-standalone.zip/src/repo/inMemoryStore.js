const { randomUUID } = require('node:crypto');

const db = {
  clubs: [
    { id: 'tech', name: 'Tech & Coding', category: 'technology', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
    { id: 'debate', name: 'Debate & Rhetoric', category: 'communication', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
    { id: 'arts', name: 'Arts & Culture', category: 'arts', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() }
  ],
  registrations: [],
  idempotency: new Map() // key -> response object
};

function genId(){ return randomUUID(); }

module.exports = { db, genId };