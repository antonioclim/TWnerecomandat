const { Router } = require('express');
const ctrl = require('../controllers/registrations.controller');
const { validateBody } = require('../middlewares/validate');
const { validateRegistration } = require('../schemas/registration.schema');

const r = Router();
r.get('/', ctrl.list);
r.post('/', validateBody(validateRegistration), ctrl.create);

module.exports = r;