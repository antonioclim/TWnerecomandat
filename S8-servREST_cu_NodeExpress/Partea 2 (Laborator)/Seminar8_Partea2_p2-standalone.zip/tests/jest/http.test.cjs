const request = require('supertest');
const app = require('../../src/app.js');

test('GET /api/clubs returns list', async () => {
  const res = await request(app).get('/api/clubs').expect(200);
  expect(res.body).toHaveProperty('items');
});

test('ETag flow', async () => {
  const first = await request(app).get('/api/clubs/tech').expect(200);
  expect(first.headers).toHaveProperty('etag');
  const etag = first.headers.etag;
  await request(app).get('/api/clubs/tech').set('If-None-Match', etag).expect(304);
});

test('POST /api/clubs invalid → 422', async () => {
  await request(app).post('/api/clubs').set('Content-Type','application/json')
    .send({ name:'a', category:'x' }).expect(422);
});