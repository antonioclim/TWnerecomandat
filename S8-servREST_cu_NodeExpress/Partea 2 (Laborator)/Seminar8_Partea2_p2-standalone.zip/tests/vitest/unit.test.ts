import { describe, it, expect } from 'vitest';
import { validateCreateClub } from '../../src/schemas/club.schema';
import { validateRegistration } from '../../src/schemas/registration.schema';
import { toProblem, unprocessable } from '../../src/errors/problem';

describe('validators', () => {
  it('validateCreateClub ok', () => {
    const r = validateCreateClub({ name:'Robotics', category:'technology' });
    expect(r.ok).toBe(true);
  });
  it('validateRegistration invalid email', () => {
    const r = validateRegistration({ fullName:'Ana', email:'x', club:'tech', consent:true });
    expect(r.ok).toBe(false);
    expect(r.errors).toHaveProperty('email');
  });
});

describe('problem serializer', () => {
  it('422 serializes to problem+json format', () => {
    const err = unprocessable({ email:'invalid' });
    const p = toProblem(err, { instance:'/api/registrations' });
    expect(p.status).toBe(422);
    expect(p.errors).toHaveProperty('email');
  });
});