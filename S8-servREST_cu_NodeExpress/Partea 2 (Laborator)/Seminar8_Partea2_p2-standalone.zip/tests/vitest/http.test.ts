import { describe, it, expect } from 'vitest';
import request from 'supertest';
import { createRequire } from 'module';
const require = createRequire(import.meta.url);
const app = require('../../src/app.js');

describe('HTTP — clubs', () => {
  it('GET /api/clubs returns paginated list', async () => {
    const res = await request(app).get('/api/clubs').expect(200);
    expect(res.body).toHaveProperty('items');
  });
  it('GET /api/clubs/:id returns 200 with ETag', async () => {
    const res = await request(app).get('/api/clubs/tech').expect(200);
    expect(res.headers).toHaveProperty('etag');
  });
  it('GET /api/clubs/:id with If-None-Match returns 304', async () => {
    const first = await request(app).get('/api/clubs/tech').expect(200);
    const etag = first.headers.etag;
    await request(app).get('/api/clubs/tech').set('If-None-Match', etag).expect(304);
  });
  it('POST /api/clubs creates (201)', async () => {
    const res = await request(app).post('/api/clubs').set('Content-Type','application/json')
      .send({ name:'Media Lab', category:'arts', id:'media' }).expect(201);
    expect(res.headers).toHaveProperty('location');
  });
  it('POST /api/clubs invalid → 422', async () => {
    await request(app).post('/api/clubs').set('Content-Type','application/json')
      .send({ name:'a', category:'x' }).expect(422);
  });
});

describe('HTTP — registrations', () => {
  it('POST /api/registrations creates (201) and is idempotent with key', async () => {
    const key = 'abc-123';
    const body = { fullName:'Ana Pop', email:'ana@uni.ro', club:'tech', consent:true };
    const r1 = await request(app).post('/api/registrations').set('Content-Type','application/json').set('Idempotency-Key', key).send(body).expect(201);
    const r2 = await request(app).post('/api/registrations').set('Content-Type','application/json').set('Idempotency-Key', key).send(body).expect(201);
    expect(r1.body.id).toEqual(r2.body.id);
  });
  it('GET /api/registrations?club=tech filters', async () => {
    const res = await request(app).get('/api/registrations?club=tech').expect(200);
    expect(Array.isArray(res.body.items)).toBe(true);
  });
});